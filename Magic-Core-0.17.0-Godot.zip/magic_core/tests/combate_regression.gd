extends SceneTree
## Run with an isolated user directory. Pass -- 30fps to change the rendering limit.

const ROOM := "res://scenes/world/test_world.tscn"
const Strike := preload("res://characters/player/sword_strike.gd")
const Controller := preload("res://characters/player/combat_controller.gd")

var actor: CharacterBody2D
var target: Area2D
var figure: Node2D
var hud: Control
var wheel: Control


func _initialize() -> void:
	_run.call_deferred()
	create_timer(35.0).timeout.connect(func() -> void: quit(1))


func _run() -> void:
	var prefs := root.get_node("Preferences")
	prefs.values.fps = 30 if OS.get_cmdline_user_args().has("30fps") else 60
	prefs.values.hud_size = 150
	prefs.apply()
	await _room()
	_check_windows()
	_check_flow()
	await _combo(1.0)
	await _room()
	await _combo(-1.0)
	await _room()
	await _interruption()
	await _room()
	await _held_or_early_press()
	await _room()
	await _walking_entry()
	await _room()
	await _moving_and_keyboard()
	print("PASS: combos espelhados, três contatos, reinício, interrupção, tecla e multitoque com HUD a 150%.")
	prefs.stop_audio()
	await create_timer(0.12).timeout
	quit()


func _room() -> void:
	assert(change_scene_to_file(ROOM) == OK)
	await process_frame
	await process_frame
	actor = current_scene.get_node("Personagem")
	target = current_scene.get_node("Alvo")
	figure = actor.get_node("Visual")
	hud = current_scene.get_node("Interface/Comandos")
	wheel = current_scene.get_node("Interface/Arsenal")
	await _ticks(5)
	_tap(1, &"attack")
	assert(wheel.visible and actor.strike_progress() < 0.0)
	_touch(2, wheel._center + Vector2(145, 0) * wheel._unit, true)
	_touch(2, wheel._center + Vector2(145, 0) * wheel._unit, false)
	_tap(1, &"attack")
	await _ticks(5)
	assert(actor.strike_progress() < 0.0 and actor.weapon_progress < 1.0)
	await _ticks(52)
	assert(actor.can_attack())


func _check_windows() -> void:
	var profiles: Array[Strike] = actor.sword_combo.duplicate()
	for index in range(profiles.size()):
		var profile := profiles[index]
		assert(0.0 < profile.active_start and profile.active_start < profile.active_end and profile.active_end < 1.0)
		assert(0.0 < profile.chain_open and profile.chain_open < profile.chain_close and profile.chain_close < 1.0)
		assert(profile.wrist_keys[0].x == 0.0 and profile.wrist_keys[-1].x == 1.0)
		for sample in range(1, profile.wrist_keys.size()):
			assert(profile.wrist_keys[sample].x > profile.wrist_keys[sample - 1].x)
	# Demonstrate that the controller uses the Inspector values, including both boundaries.
	profiles[0] = profiles[0].duplicate()
	profiles[0].chain_open = 0.63
	profiles[0].chain_close = 0.81
	for progress: float in [0.30, 0.629, 0.631, 0.809, 0.811]:
		var controller := Controller.new()
		controller.request(profiles)
		assert(controller.begin_pending(profiles))
		controller.advance(progress * profiles[0].duration)
		assert(controller.link_open(profiles) == (progress > 0.63 and progress < 0.81))
		controller.request(profiles)
		controller.finish()
		assert(controller.begin_pending(profiles) == (progress >= 0.629 and progress < 0.81))
	print("PASS: janela configurável, toque perto da abertura entra na fila e entradas fora do limite expiram.")


func _check_flow() -> void:
	var profiles: Array[Strike] = actor.sword_combo
	var normal := _link_time(profiles, 0.0, 0.5)
	var centered := _link_time(profiles, 1.0, 0.5)
	var late := _link_time(profiles, 1.0, 0.97)
	assert(centered < normal and centered < late and normal - centered <= 4)
	print("PASS: Fluxo reduz passos da recuperação no centro da janela. Sem Fluxo / centro / borda: ",
		normal, " / ", centered, " / ", late)


func _link_time(profiles: Array[Strike], power: float, timing: float) -> int:
	var controller := Controller.new()
	controller.request(profiles)
	assert(controller.begin_pending(profiles))
	var profile := profiles[0]
	var mark := lerpf(profile.chain_open, profile.chain_close, timing)
	controller.advance(mark * profile.duration, power)
	controller.request(profiles)
	var frames := 0
	while controller.progress() < 1.0:
		controller.advance(1.0 / 60.0, power)
		frames += 1
	var outgoing := controller.carry()
	controller.finish()
	assert(controller.begin_pending(profiles) and controller.current == profiles[1])
	assert(is_equal_approx(controller.carry(), outgoing))
	return ceili(mark * profile.duration * 60.0) + frames


func _combo(side: float) -> void:
	await _aim(side)
	var second_shape := target.get_node("Forma").duplicate() as CollisionShape2D
	second_shape.position.x += 5.0
	target.add_child(second_shape)
	var second_target := target.duplicate() as Area2D
	second_target.position.x += 7.0 * side
	current_scene.add_child(second_target)
	await _ticks(2)
	_tap(1, &"attack")
	var started: Array[String] = []
	var hit_counts := [0, 0, 0]
	var other_counts := [0, 0, 0]
	var before: int = target.health
	var before_other: int = second_target.health
	var requested := false
	var numbered := -1
	var current: Strike
	var first_tip_y := [0.0, 0.0, 0.0]
	var final_tip_y := [0.0, 0.0, 0.0]
	var window_shown := [false, false, false]
	var carried_pose := false
	var hand_before: Vector2 = figure.pose.grip
	for tick in range(110):
		await _ticks(1)
		var profile: Strike = actor.current_strike()
		if profile == null:
			continue
		var progress: float = actor.strike_progress()
		if profile != current:
			current = profile
			started.append(profile.resource_name)
			numbered += 1
			assert(numbered < 3)
			assert(hand_before.distance_to(figure.pose.grip) < 9.0)
			requested = false
		_check_mounts()
		if numbered > 0 and progress < 0.18:
			carried_pose = carried_pose or figure.pose._flow_support > 0.27
		assert(figure.transform.x.x == side)
		assert(figure.blade_tip().y < -0.55)
		hand_before = figure.pose.grip
		if progress >= profile.active_start and progress <= profile.active_end:
			var y: float = figure.blade_tip().y
			if is_zero_approx(first_tip_y[numbered]):
				first_tip_y[numbered] = y
			final_tip_y[numbered] = y
		if target.health < before:
			assert(progress >= profile.active_start and progress <= profile.active_end + 0.06)
			hit_counts[numbered] += before - target.health
		if second_target.health < before_other:
			other_counts[numbered] += before_other - second_target.health
		before = target.health
		before_other = second_target.health
		window_shown[numbered] = window_shown[numbered] or hud._link_open
		if not requested and progress >= profile.chain_open + 0.13:
			requested = true
			_tap(1, &"attack")
			_tap(2, &"attack")
	assert(started == ["Corte horizontal", "Corte ascendente", "Corte descendente"], str(started))
	assert(window_shown == [true, true, false])
	assert(carried_pose and figure.pose._flow_support < 0.15)
	assert(hit_counts == [1, 1, 1] and other_counts == [1, 1, 1])
	assert(actor.strike_progress() < 0.0 and target.health == 0 and second_target.health == 0)
	assert(absf(final_tip_y[0] - first_tip_y[0]) < 55.0)
	assert(final_tip_y[1] - first_tip_y[1] < -65.0)
	assert(final_tip_y[2] - first_tip_y[2] > 65.0)
	_tap(1, &"attack")
	await _ticks(1)
	assert(actor.current_strike() == actor.sword_combo[0])
	print("PASS: lado ", side, " | PV por golpe: ", hit_counts, " | alturas da ponta, início e fim da janela: ", first_tip_y, " → ", final_tip_y)


func _interruption() -> void:
	await _aim(1.0)
	_tap(1, &"attack")
	await _ticks(3)
	assert(actor.strike_progress() > 0.0 and target.health == 3)
	_tap(1, &"arsenal")
	assert(not wheel.visible and not actor.can_attack())
	var hit_behind_wheel := false
	var before: int = target.health
	for i in range(30):
		await _ticks(1)
		if target.health < before:
			hit_behind_wheel = wheel.visible
			before = target.health
	assert(wheel.visible and actor.strike_progress() < 0.0)
	assert(target.health == 2 and not hit_behind_wheel)
	_touch(2, wheel._center, true)
	_touch(2, wheel._center, false)
	_tap(1, &"attack")
	await _ticks(16)
	var profile: Strike = actor.current_strike()
	assert(profile == actor.sword_combo[0] and actor.strike_progress() > profile.chain_open)
	_tap(1, &"attack")
	_tap(1, &"arsenal")
	_tap(2, &"attack")
	_key_j(true)
	await _ticks(3)
	_key_j(false)
	assert(not wheel.visible and not actor.can_attack())
	await _ticks(36)
	assert(wheel.visible and actor.strike_progress() < 0.0 and target.health == 1)
	_touch(2, wheel._center, true)
	_touch(2, wheel._center, false)
	await _ticks(20)
	assert(actor.strike_progress() < 0.0)
	print("PASS: Arsenal abre ao final, cancela entrada enfileirada e bloqueia ataque até mostrar a roda.")


func _held_or_early_press() -> void:
	await _aim(1.0)
	_touch(1, _point(&"attack"), true)
	await _ticks(6)
	_tap(2, &"attack")
	await _ticks(55)
	assert(target.health == 2 and actor.strike_progress() < 0.0)
	_touch(1, _point(&"attack"), false)
	_tap(1, &"attack")
	await _ticks(16)
	_tap(1, &"attack")
	await _ticks(40)
	assert(target.health == 0 and actor.strike_progress() < 0.0)
	print("PASS: segurar não repete, toque cedo expira e combo com dois toques termina no segundo golpe.")


func _walking_entry() -> void:
	actor.position.x = 415.0
	actor.reset_physics_interpolation()
	_touch(0, _point(&"right"), true)
	await _ticks(27)
	assert(is_equal_approx(actor.velocity.x, actor.walk_speed))
	actor.position.x = target.position.x - 103.0
	actor.reset_physics_interpolation()
	_tap(1, &"attack")
	await _ticks(2)
	assert(actor._strike_entry_speed > actor.walk_speed * 0.99)
	assert(actor.velocity.x > actor.walk_speed * 0.60)
	_check_mounts()
	await _ticks(31)
	assert(target.health == 2 and actor.strike_progress() < 0.0)
	await _ticks(9)
	assert(is_equal_approx(actor.velocity.x, actor.walk_speed))
	_touch(0, _point(&"right"), false)
	print("PASS: ataque mantém o impulso da caminhada na entrada e devolve a passada ao terminar.")


func _moving_and_keyboard() -> void:
	actor.position.x = 425.0
	actor.reset_physics_interpolation()
	_tap(2, &"run")
	_touch(0, _point(&"right"), true)
	await _ticks(43)
	assert(is_equal_approx(actor.velocity.x, actor.run_speed))
	actor.position.x = target.position.x - 105.0
	actor.reset_physics_interpolation()
	_key_j(true)
	await _ticks(10)
	_key_j(false)
	var profile: Strike = actor.current_strike()
	assert(profile == actor.sword_combo[0])
	assert(is_equal_approx(actor.velocity.x, actor.walk_speed * profile.ground_speed_scale))
	await _ticks(8)
	assert(target.health == 2)
	var direction := InputEventScreenDrag.new()
	direction.index = 0
	direction.position = _point(&"left")
	root.push_input(direction, true)
	await _ticks(3)
	assert(actor.strike_progress() >= 0.0 and figure.transform.x.x == 1.0)
	await _ticks(53)
	assert(actor.velocity.x < -0.99 * actor.run_speed and figure.transform.x.x == -1.0)
	_tap(1, &"jump")
	await _ticks(4)
	_tap(1, &"attack")
	await _ticks(9)
	assert(not actor.is_on_floor() and actor.current_strike() == actor.sword_combo[0])
	assert(is_equal_approx(actor.velocity.x, -actor.air_speed))
	_check_mounts()
	_touch(0, _point(&"left"), false)
	await _ticks(65)
	assert(actor.is_on_floor() and actor.strike_progress() < 0.0)
	print("PASS: ataque de corrida e no ar, orientação durante o golpe, corrida e giro após recuperar.")


func _aim(side: float) -> void:
	actor.position.x = target.position.x - 83.0 * side
	actor.reset_physics_interpolation()
	var key := &"right" if side > 0.0 else &"left"
	_touch(0, _point(key), true)
	await _ticks(1)
	_touch(0, _point(key), false)
	await _ticks(7)
	assert(figure.transform.x.x == side)


func _check_mounts() -> void:
	var pose = figure.pose
	var belt := figure.get_node("Cintura") as Marker2D
	var grip := figure.get_node("Empunhadura") as Marker2D
	assert(belt.position.distance_to(pose.hip) < 5.30)
	assert(grip.global_position.distance_to(figure.to_global(pose.front_hand)) < 0.004)
	assert(pose.front_elbow.is_finite() and pose.rear_knee.is_finite())
	if actor.is_on_floor():
		assert((pose.mouth + pose.axis * 56.0).y < -0.8)


func _key_j(pressed: bool) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = KEY_J
	event.pressed = pressed
	Input.parse_input_event(event)


func _point(key: StringName) -> Vector2:
	return hud._origin + hud.centers[key] * hud._unit


func _tap(index: int, key: StringName) -> void:
	var point := _point(key)
	_touch(index, point, true)
	_touch(index, point, false)


func _touch(index: int, point: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = point
	event.pressed = pressed
	root.push_input(event, true)


func _ticks(count: int) -> void:
	for i in range(count):
		await physics_frame
