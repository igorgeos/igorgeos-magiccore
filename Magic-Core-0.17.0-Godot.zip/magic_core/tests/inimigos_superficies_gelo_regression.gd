extends SceneTree

const Foe := preload("res://scenes/forest/foe.gd")
const DT := 1.0 / 60.0


func _initialize() -> void:
	run.call_deferred()
	create_timer(18.0).timeout.connect(func(): quit(2))


func run() -> void:
	var campaign = root.get_node("Campaign")
	assert(campaign.start(1) == OK)
	for id in ["mata1", "mata2", "mata3", "mata4", "mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage() == OK)
	assert(campaign.open_chapter("gelo") == OK)
	await enter(campaign, "gelo1")
	await check_watch(current_scene)
	assert(campaign.finish_stage() == OK)
	await enter(campaign, "gelo2")
	await check_colossus(current_scene)
	assert(campaign.finish_stage() == OK)
	await enter(campaign, "gelo3")
	await check_sovereign(current_scene)
	root.get_node("Preferences").stop_audio()
	current_scene.queue_free()
	await process_frame
	quit()


func frames(count: int) -> void:
	for index in count:
		await physics_frame


func enter(campaign, id: String) -> void:
	assert(campaign.enter_stage(id))
	assert(change_scene_to_file(campaign.stage_data(id).scene) == OK)
	await scene_changed
	await frames(5)
	for foe in current_scene.foes:
		foe.suspend(true)
	current_scene._player.set_physics_process(false)


func settle(world, foe, x: float) -> void:
	foe.change(Foe.State.ALERT, 25.0)
	foe.velocity = Vector2.ZERO
	foe.position = Vector2(x, world.surface_at(x) - 1.0)
	foe.suspend(false)
	await frames(6)
	foe.suspend(true)
	assert(foe.is_on_floor(), "Inimigo precisa estar apoiado no chão antes do teste.")


func check_watch(world) -> void:
	var watch = world.foes[0]
	await settle(world, watch, 788.0)
	assert(world.is_slick_surface_at(watch.position))
	watch.change(Foe.State.PURSUE)
	watch.side = -1.0
	watch.velocity.x = 108.0
	watch._target_speed = -120.0
	for step in 7:
		watch._steer_horizontally(DT)
		watch.rig.tick(DT, watch.velocity.x * DT)
	assert(watch._balance_time > 0.0 and watch.balance_correction < -0.5)
	var sliding_speed: float = watch.velocity.x
	assert(sliding_speed > 28.0, "Vigia corrige o equilíbrio e conserva parte da inércia.")
	for step in 40:
		watch._steer_horizontally(DT)
	assert(watch.velocity.x < -100.0 and is_zero_approx(watch.balance_correction))

	await settle(world, watch, 720.0)
	assert(not world.is_slick_surface_at(watch.position))
	watch.change(Foe.State.PURSUE)
	watch.velocity.x = 108.0
	watch._target_speed = -120.0
	for step in 7:
		watch._steer_horizontally(DT)
	assert(watch._balance_time == 0.0 and watch.velocity.x < sliding_speed - 15.0)
	print("PASS Vigia: corrige a passada e freia para recuperar apoio no gelo liso, mantém a resposta normal fora dele.")


func check_colossus(world) -> void:
	var boss = world.foes[1]
	var pillar = world._memories.structures["ColunaDoGuincho"]
	assert(pillar.required_impacts > 1 and pillar.impacts_taken == 0)
	await settle(world, boss, 1630.0)
	for expected in range(1, pillar.required_impacts + 1):
		boss.attack = Foe.Move.STOMP
		boss.spent = false
		boss.change(Foe.State.STRIKE, 0.76)
		boss.rig.tick(DT, 0.0)
		boss.apply_attack()
		assert(pillar.impacts_taken == expected - 1, "A preparação ainda não atingiu o gelo.")
		boss.age = boss.LANDING + DT
		boss.rig.tick(DT, 0.0)
		for tick in 8:
			boss.apply_attack()
			boss.age += DT
		assert(pillar.impacts_taken == expected, "O mesmo impacto do colosso registra exatamente uma rachadura.")
	assert(pillar.broken)
	assert(boss.react_to_ice_debris(-1.0) and boss.state == Foe.State.HURT and boss.velocity.x < 0.0)
	assert(not boss.react_to_ice_debris(-1.0), "Em desequilíbrio, não repete a reação.")
	print("PASS Colosso: apenas a batida aterrissada incrementa a memória e várias batidas destroem a coluna.")


func measure_charge(world, boss, x: float, icy: bool) -> float:
	await settle(world, boss, x)
	assert(world.is_slick_surface_at(boss.position) == icy)
	var distance := 177.0
	world.life.current = world.life.capacity
	world.life.invulnerability = 0.0
	world._move_hero(Vector2(x + distance, world.surface_at(x + distance)))
	boss._prepare(Foe.Move.CHARGE, 1.0, 0.82)
	assert(boss.ice_charge == icy and boss.time >= (0.93 if icy else 0.81))
	boss.time = 0.0
	boss._choose_action(Vector2(distance, 0.0))
	assert(boss.state == Foe.State.STRIKE)
	var start_x: float = boss.position.x
	boss.suspend(false)
	await frames(25)
	boss.suspend(true)
	if icy:
		assert(world.life.current < world.life.capacity,
			"O deslizamento tem alcance efetivo contra o jogador. Avanço %.1f, posição do alvo %s, estado %s, idade %.2f." %
			[boss.position.x - start_x, world._player.position, boss.state, boss.age])
	else:
		assert(world.life.current == world.life.capacity, "O mesmo alcance não existe na pedra.")
	return boss.position.x - start_x


func check_sovereign(world) -> void:
	var boss = world._boss
	var stable := await measure_charge(world, boss, 2255.0, false)
	var slide := await measure_charge(world, boss, 2125.0, true)
	assert(stable > 34.0 and slide > stable + 45.0)
	assert(boss._recovery_time() > 1.12)
	print("PASS Soberano: gelo dá alcance real (%.1f px contra %.1f px), com aviso e recuperação maiores." % [slide, stable])
