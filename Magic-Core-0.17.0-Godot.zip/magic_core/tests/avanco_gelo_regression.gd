extends SceneTree
## Execute com XDG_DATA_HOME isolado.

const ATLAS := "res://scenes/atlas/atlas.tscn"


func _initialize() -> void:
	run.call_deferred()
	create_timer(35.0).timeout.connect(func(): quit(1))


func run() -> void:
	var campaign = root.get_node("Campaign")
	var preferences = root.get_node("Preferences")
	assert(not campaign.has_saved(), "Use um diretório de dados de teste vazio.")
	preferences.values.reduced_motion = true
	preferences.apply()
	assert(campaign.start(1) == OK)
	for id in ["mata1", "mata2", "mata3", "mata4", "mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage() == OK)
	assert(campaign.open_chapter("gelo") == OK)
	assert(campaign.enter_stage("gelo1"))
	assert(change_scene_to_file(campaign.stage_data("gelo1").scene) == OK)
	await scene_changed
	var porto := current_scene
	for objective in porto.route.tasks:
		assert(porto.progress.record(objective[0], objective[1]))

	# A confirmação visual e a troca de fase devem esperar pelo save.
	campaign.active_slot = 0
	porto._register_victory()
	assert(porto.ended and not porto.won)
	assert(not "gelo1" in campaign.read_slot(1).completed)
	assert(result_button(porto, "Próxima fase") == null)
	var save_again := result_button(porto, "Salvar novamente")
	assert(save_again != null)
	campaign.active_slot = 1
	save_again.pressed.emit()
	assert(porto.won and campaign.read_slot(1).completed.has("gelo1"))
	assert(result_button(porto, "Próxima fase") != null)
	assert(campaign.stage == "gelo1")
	await scene_changed
	assert(current_scene.stage_id == "gelo2" and campaign.stage == "gelo2")
	assert(campaign.read_slot(1).completed.has("gelo1"))
	assert(not campaign.read_slot(1).completed.has("gelo2"))

	# O mapa mantém a escolha do jogador se a saída ocorrer antes do temporizador.
	var passo := current_scene
	for objective in passo.route.tasks:
		assert(passo.progress.record(objective[0], objective[1]))
	passo._register_victory()
	assert(campaign.read_slot(1).completed.has("gelo2"))
	result_button(passo, "Voltar ao mapa").pressed.emit()
	await scene_changed
	await create_timer(5.4).timeout
	assert(current_scene.scene_file_path == ATLAS and current_scene.map_open)
	print("PASS: falha de save permite nova tentativa, avanço espera a gravação e o mapa interrompe a troca automática.")
	quit()


func result_button(stage: Node, caption: String) -> Button:
	for button: Button in stage._hud.find_children("*", "Button", true, false):
		if button.text == caption:
			return button
	return null
