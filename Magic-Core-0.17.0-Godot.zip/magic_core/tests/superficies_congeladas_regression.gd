extends SceneTree

const SURFACE := preload("res://scenes/gelo/superficies_congeladas.gd")
const PORT := "res://scenes/gelo/porto_das_geadas.tscn"
const TRAINING := "res://scenes/world/test_world.tscn"


func _initialize() -> void:
	run.call_deferred()
	create_timer(18.0).timeout.connect(func(): quit(2))


func frames(count: int) -> void:
	for tick in count:
		await physics_frame


func run() -> void:
	var campaign = root.get_node("Campaign")
	var preferences = root.get_node("Preferences")
	preferences.values.reduced_motion = false
	preferences.apply()
	assert(campaign.start(1, true) == OK)
	for id in ["mata1", "mata2", "mata3", "mata4", "mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage() == OK)
	assert(campaign.open_chapter("gelo") == OK and campaign.enter_stage("gelo1"))
	assert(change_scene_to_file(PORT) == OK)
	await frames(6)
	var world = current_scene
	var player = world._player
	assert(world.surface_material_at(ground(world, 270)) == SURFACE.Kind.SNOW)
	assert(world.surface_material_at(ground(world, 412)) == SURFACE.Kind.SMOOTH_ICE)
	assert(world.surface_material_at(ground(world, 620)) == SURFACE.Kind.FROZEN_ROCK)
	assert(world.surface_material_at(Vector2(1100, 562)) == SURFACE.Kind.FRAGILE_ICE)
	assert(world.surface_material_at(Vector2(1100, 432)) == SURFACE.Kind.STABLE_DECK)
	assert(world.surface_material_at(Vector2(1220, 554)) == SURFACE.Kind.SMOOTH_ICE)
	assert(world.surface_material_at(Vector2(390, 469)) == SURFACE.Kind.FROZEN_ROCK)
	assert(world.surface_material_at(Vector2(390, 525)) == SURFACE.Kind.NONE)
	assert(world.surface_material_at(Vector2(1095, 633)) == SURFACE.Kind.NONE)

	world._move_hero(ground(world, 238))
	player.touch_axis = 1.0
	await frames(23)
	assert(not world._surfaces._tracks.is_empty(), "A neve deve registrar os passos do Andarilho.")
	var on_snow: float = world._surfaces._tracks[-1].origin.x
	world._move_hero(ground(world, 388))
	await frames(24)
	assert(player.slippery_ground and world._surfaces._tracks[-1].origin.x == on_snow)
	world._move_hero(ground(world, 620))
	player.touch_axis = 0.0
	await frames(12)
	assert(not player.slippery_ground and is_zero_approx(player._ground_slip))

	var slab = world.brittle_ice[0]
	world._move_hero(Vector2(1100, 562))
	await frames(6)
	assert(player.is_on_floor() and slab.state == slab.State.CRACKING)
	await frames(52)
	assert(slab.state == slab.State.BROKEN and slab.collision.disabled)
	assert(world.surface_material_at(Vector2(1100, 562)) == SURFACE.Kind.NONE)
	world._move_hero(ground(world, 270))
	await frames(198)
	assert(slab.state == slab.State.SOLID and not slab.collision.disabled)
	assert(world.surface_material_at(Vector2(1100, 562)) == SURFACE.Kind.FRAGILE_ICE)
	print("PASS: quatro superfícies locais, distinção por altura, pegadas só na neve, quebra e recongelamento.")

	assert(change_scene_to_file(TRAINING) == OK)
	await frames(10)
	player = current_scene.get_node("Personagem")
	assert(not player.slippery_ground and is_zero_approx(player._ground_slip))
	assert(current_scene.get_node_or_null("SuperficiesCongeladas") == null)
	print("PASS: a mudança de piso fica no Capítulo 2 e não acompanha o personagem para outras cenas.")
	quit()


func ground(world: Node2D, x: float) -> Vector2:
	return Vector2(x, world.surface_at(x))
