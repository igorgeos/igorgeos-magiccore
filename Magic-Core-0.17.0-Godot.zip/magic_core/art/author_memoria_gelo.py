"""Create the three Memória do Gelo meshes and their in-game 2.5D sprites.

Run from any directory:
    blender -b -t 8 --python-exit-code 2 --python art/author_memoria_gelo.py

Output defaults to assets/gelo. Use -- /absolute/staging/path to stage the
assets elsewhere. Models face Blender -Y (Godot +Z), with origin at the base.
"""

import math
import random
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector


STEMS = ("selo_memoria", "coluna_memoria", "trava_memoria")
TAU = math.tau


def surface(name, rgb, roughness, metallic=0.0, emission=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = (*rgb, 1.0)
    shader = mat.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = mat.diffuse_color
    shader.inputs["Roughness"].default_value = roughness
    shader.inputs["Metallic"].default_value = metallic
    if emission:
        shader.inputs["Emission Color"].default_value = (*rgb, 1.0)
        shader.inputs["Emission Strength"].default_value = emission
    return mat


class Geometry:
    """Accumulate meshes by construction part, retaining material slots."""

    def __init__(self, name, materials):
        self.name = name
        self.materials = materials
        self.vertices = []
        self.faces = []
        self.slots = []

    def append(self, vertices, faces, slots):
        start = len(self.vertices)
        self.vertices.extend(vertices)
        self.faces.extend(tuple(start + i for i in face) for face in faces)
        self.slots.extend(slots)

    def build(self):
        data = bpy.data.meshes.new(self.name)
        data.from_pydata(self.vertices, [], self.faces)
        data.validate()
        data.update()
        for material in self.materials:
            data.materials.append(material)
        uv = data.uv_layers.new(name="UV")
        for face, slot in zip(data.polygons, self.slots):
            face.material_index = slot
            # Face-local projection gives every facet a useful UV basis, including vertical cuts.
            drop = max(range(3), key=lambda axis: abs(face.normal[axis]))
            u, v = (axis for axis in range(3) if axis != drop)
            for index in face.loop_indices:
                co = data.vertices[data.loops[index].vertex_index].co
                uv.data[index].uv = (co[u] * 0.45 + 0.5, co[v] * 0.45)
        obj = bpy.data.objects.new(self.name, data)
        bpy.context.collection.objects.link(obj)
        return obj


def prism(geometry, points, rows, slot, rng, facet=0.0, triangular=False):
    """Loft an irregular, closed profile. Rows ascend from ground to top."""
    vertices = []
    for z, x, y, rx, ry in rows:
        for xx, yy in points:
            vertices.append((x + xx * rx, y + yy * ry, z + rng.uniform(-facet, facet)))
    length = len(points)
    faces = [tuple(range(length - 1, -1, -1))]
    slots = [slot(0, 0)]
    for row in range(len(rows) - 1):
        for col in range(length):
            a = row * length + col
            b = row * length + (col + 1) % length
            c = b + length
            d = a + length
            if triangular:
                faces.extend(((a, b, d), (b, c, d)))
                slots.extend((slot(row, col), slot(row, col)))
            else:
                faces.append((a, b, c, d))
                slots.append(slot(row, col))
    faces.append(tuple(range(len(vertices) - length, len(vertices))))
    slots.append(slot(len(rows) - 1, 0))
    geometry.append(vertices, faces, slots)


def ring(sides, phase=0.0):
    return [(math.cos(TAU * i / sides + phase), math.sin(TAU * i / sides + phase))
            for i in range(sides)]


def ridge(geometry, path, widths, slot):
    """A small raised detail in the front plane, with bevel rather than a decal."""
    vertices = []
    for i, ((x, y, z), width) in enumerate(zip(path, widths)):
        before = Vector(path[max(i - 1, 0)])
        after = Vector(path[min(i + 1, len(path) - 1)])
        axis = (after - before).normalized()
        normal = Vector((axis.z, 0, -axis.x)).normalized() * width
        vertices.extend(((x + normal.x, y, z + normal.z),
                         (x, y - width * 0.65, z),
                         (x - normal.x, y, z - normal.z)))
    faces = []
    for i in range(len(path) - 1):
        a = i * 3
        faces.extend(((a, a + 3, a + 4, a + 1), (a + 1, a + 4, a + 5, a + 2)))
    geometry.append(vertices, faces, [slot] * len(faces))


def palette():
    return [
        surface("Gelo profundo", (0.054, 0.145, 0.217), 0.34, 0.035),
        surface("Gelo denso", (0.144, 0.342, 0.453), 0.29, 0.055),
        surface("Gelo claro", (0.244, 0.499, 0.587), 0.29, 0.045),
        surface("Aresta glaciar", (0.379, 0.612, 0.687), 0.32, 0.04, 0.06),
        surface("Geada antiga", (0.608, 0.738, 0.764), 0.81),
        surface("Ardósia profunda", (0.086, 0.110, 0.124), 0.83),
        surface("Face de ardósia", (0.153, 0.187, 0.199), 0.79),
        surface("Ferro antigo", (0.239, 0.173, 0.111), 0.48, 0.68),
        surface("Latão gasto", (0.458, 0.332, 0.189), 0.42, 0.62),
        surface("Ar preenchido de gelo", (0.102, 0.327, 0.413), 0.41, 0.0, 0.24),
    ]


def seal(materials, rng):
    body = Geometry("Massa estratificada do selo", materials)
    edges = Geometry("Crostas e bordas do selo", materials)
    profile = [(-0.87, -0.71), (-0.37, -1.0), (0.18, -0.94), (0.76, -0.83),
               (1.0, -0.27), (0.87, 0.48), (0.45, 0.80), (-0.50, 0.75),
               (-0.97, 0.42), (-1.0, -0.20)]
    rows = [(0.025, 0.0, 0.01, 0.51, 0.26),
            (0.18, -0.01, 0.0, 0.55, 0.27),
            (0.55, 0.032, 0.014, 0.50, 0.28),
            (1.02, -0.008, -0.012, 0.46, 0.23),
            (1.39, -0.055, 0.038, 0.41, 0.22),
            (1.69, -0.087, 0.065, 0.35, 0.18),
            (1.99, -0.071, 0.072, 0.27, 0.16),
            (2.10, -0.11, 0.070, 0.19, 0.13)]
    cut = (1, 2, 1, 2, 0, 0, 1, 1, 2, 1)
    prism(body, profile, rows, lambda row, col: 4 if row == 7 else cut[col], rng, 0.045, True)

    for side, base_x, peak, tilt, width, depth in (
        (-1.0, -0.44, 1.72, 0.09, 0.22, 0.18),
        (1.0, 0.39, 1.83, -0.115, 0.27, 0.20),
        (1.0, 0.26, 1.31, 0.12, 0.21, 0.18),
        (-1.0, -0.51, 0.85, -0.11, 0.14, 0.14),
    ):
        prism(body, ring(6, -math.pi / 7),
              [(0.024, base_x * 0.91, -0.03, width, depth),
               (peak * 0.35, base_x, -0.094, width * 0.87, depth),
               (peak * 0.76, base_x + tilt * 0.76, -0.04, width * 0.61, depth * 0.86),
               (peak, base_x + tilt, -0.010, 0.015, 0.013)],
              lambda row, col: (2, 3, 2, 1, 0, 1)[col] if row < 3 else 3, rng, 0.019, True)
        ridge(edges, [(base_x + side * 0.04, -0.16, peak * 0.26),
                      (base_x + tilt * 0.62, -0.195, peak * 0.64),
                      (base_x + tilt * 0.82, -0.14, peak * 0.89)],
              [0.012, 0.017, 0.004], 3)

    # Flecks align mostly along layers, distinct from the dynamic, branching impact cracks.
    for i in range(24):
        x = rng.uniform(-0.33, 0.29)
        z = 0.21 + (i % 6) * 0.274 + rng.uniform(-0.038, 0.025)
        y = -0.25 + 0.14 * abs(x)
        length = rng.uniform(0.035, 0.11)
        ridge(edges, [(x - length, y + 0.015, z + 0.013), (x, y - 0.008, z),
                      (x + length * 0.35, y, z - 0.004)],
              [0.001, rng.uniform(0.005, 0.011), 0.002], 3 if i % 4 else 4)
    return [body.build(), edges.build()]


def column(materials, rng):
    trunk = Geometry("Pilar de gelo sobre ardósia", materials)
    rime = Geometry("Cristais pendentes e branco de geada", materials)
    profile = ring(9, -0.26)
    table = [
        (0.036, 0, 0.015, 0.51, 0.32),
        (0.13, -0.016, 0.014, 0.49, 0.31),
        (0.29, -0.032, 0.014, 0.37, 0.23),
        (0.49, 0.021, 0.03, 0.34, 0.21),
        (0.74, 0.048, -0.018, 0.31, 0.22),
        (1.02, 0.023, 0.01, 0.29, 0.21),
        (1.29, 0.018, 0.02, 0.33, 0.22),
        (1.55, -0.05, 0.051, 0.30, 0.20),
        (1.80, -0.088, 0.068, 0.26, 0.20),
        (2.09, -0.11, 0.07, 0.17, 0.12),
        (2.34, -0.168, 0.063, 0.03, 0.045),
    ]
    cuts = (0, 1, 1, 2, 1, 2, 1, 2, 3)
    prism(trunk, profile, table,
          lambda row, col: ((6 if row != 1 else 5) if (col + row) % 3 else 1)
          if row < 4 else cuts[col], rng, 0.052, True)
    for ax, pos_y, z0, z1, r, lean in (
        (-0.29, -0.16, 0.03, 1.09, 0.15, -0.05),
        (0.33, -0.12, 0.02, 1.29, 0.17, 0.048),
        (0.24, 0.00, 0.67, 1.89, 0.20, 0.11),
        (-0.29, -0.066, 1.09, 1.93, 0.17, 0.058),
        (0.035, -0.104, 1.42, 2.24, 0.16, 0.039),
        (-0.37, -0.06, 0.02, 0.48, 0.18, -0.04),
    ):
        prism(rime, ring(6, -0.71),
              [(z0, ax, pos_y, r * 0.78, r * 0.61),
               (z0 + (z1 - z0) * 0.44, ax + lean * 0.38, pos_y, r, r * 0.68),
               (z0 + (z1 - z0) * 0.78, ax + lean * 0.62, pos_y * 0.99, r * 0.49, r * 0.55),
               (z1, ax + lean, pos_y * 0.88, 0.008, 0.013)],
              lambda row, col: (2, 3, 2, 1, 0, 2)[col], rng, 0.017, True)
    for i in range(13):
        x = rng.uniform(-0.13, 0.19)
        z = rng.uniform(0.39, 1.78)
        length = rng.uniform(0.045, 0.19)
        ridge(rime, [(x, -0.201, z), (x - 0.017, -0.205, z + length * 0.52),
                     (x - 0.041, -0.187, z + length)], [0.002, 0.006, 0.002],
              3 if i % 3 else 4)
    return [trunk.build(), rime.build()]


def lock(materials, rng):
    foundation = Geometry("Pedra e ferragem da trava antiga", materials)
    crust = Geometry("Camada de gelo do guincho", materials)
    profile = [(-1.0, -0.76), (-0.72, -1.0), (0.68, -1.0), (1.0, -0.76),
               (1.0, 0.70), (0.67, 1.0), (-0.73, 1.0), (-1.0, 0.74)]
    prism(foundation, profile,
          [(0.018, 0, 0, 0.56, 0.34), (0.11, 0, 0, 0.55, 0.34),
           (0.17, 0, 0.009, 0.45, 0.29), (0.77, 0, 0.013, 0.45, 0.26),
           (0.85, 0, 0.01, 0.53, 0.30), (0.91, 0, 0.014, 0.51, 0.28)],
          lambda row, col: (6, 5, 6, 5, 6, 5, 6, 5)[col] if row < 5 else 4, rng, 0.014)
    # Metal buckle and vertical tongue remain identifiable behind the ice rim.
    outer = ring(8, math.pi / 8)
    vertices = []
    for y, radius in ((-0.267, 0.225), (-0.296, 0.225),
                      (-0.298, 0.155), (-0.272, 0.155)):
        for x, z in outer:
            vertices.append((x * radius, y, 0.50 + z * radius))
    faces = []
    for row in range(4):
        faces.extend((row * 8 + i, row * 8 + (i + 1) % 8,
                      (row + 1) % 4 * 8 + (i + 1) % 8, (row + 1) % 4 * 8 + i)
                     for i in range(8))
    foundation.append(vertices, faces, [7, 8, 8, 7, 7, 8, 8, 7] * 4)
    ridge(foundation, [(0, -0.300, 0.37), (0.001, -0.320, 0.49), (0.0, -0.329, 0.64)],
          [0.024, 0.048, 0.031], 8)
    for x in (-0.34, 0.34):
        ridge(foundation, [(x, -0.264, 0.19), (x, -0.272, 0.50), (x, -0.254, 0.77)],
              [0.021, 0.039, 0.022], 7)
    for x, y, z0, z1, radius, lean in (
        (-0.48, -0.16, 0.02, 1.13, 0.22, 0.08),
        (0.40, -0.16, 0.04, 1.07, 0.21, -0.026),
        (-0.26, -0.06, 0.65, 1.16, 0.21, -0.16),
        (0.20, -0.079, 0.70, 1.18, 0.19, 0.105),
        (0.44, -0.28, 0.013, 0.59, 0.14, -0.043),
        (-0.38, -0.29, 0.013, 0.67, 0.16, -0.083),
        (0.03, -0.29, 0.013, 0.25, 0.18, 0.067),
    ):
        prism(crust, ring(6),
              [(z0, x, y, radius * 0.93, radius * 0.70),
               (z0 + (z1 - z0) * 0.43, x + lean * 0.45, y, radius, radius * 0.74),
               (z0 + (z1 - z0) * 0.72, x + lean * 0.67, y, radius * 0.69, radius * 0.58),
               (z1, x + lean, y + 0.06, 0.012, 0.019)],
              lambda row, col: (2, 1, 0, 2, 3, 2)[col] if row < 3 else 4, rng, 0.018, True)
    return [foundation.build(), crust.build()]


def look_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def render(actors, stem, output):
    scene = bpy.context.scene
    coords = [obj.matrix_world @ v.co for obj in actors for v in obj.data.vertices]
    height = max(v.z for v in coords) - min(v.z for v in coords)
    width = max(v.x for v in coords) - min(v.x for v in coords)
    center = (0, -0.005, height * 0.51)
    camera = bpy.data.cameras.new("Prévia ortográfica")
    eye = bpy.data.objects.new("Prévia ortográfica", camera)
    bpy.context.collection.objects.link(eye)
    eye.location = (height * 0.62, -height * 3.28, height * 0.82)
    look_at(eye, center)
    camera.type = "ORTHO"
    # In AUTO mode the orthographic scale describes the widest image dimension.
    camera.ortho_scale = max(height * 1.10, width * 1.19)
    scene.camera = eye

    world = bpy.data.worlds.new("Céu invernal")
    world.use_nodes = True
    world.node_tree.nodes.get("Background").inputs[0].default_value = (0.334, 0.405, 0.499, 1)
    world.node_tree.nodes.get("Background").inputs[1].default_value = 0.43
    scene.world = world
    for name, loc, gain, size, color in (
        ("Luz de neve", (-2.9, -3.5, 4.2), 580, 2.6, (0.84, 0.92, 1.0)),
        ("Luz de recorte", (2.3, 1.7, 3.45), 460, 2.8, (0.49, 0.77, 1.0)),
        ("Rebote de pedra", (2.1, -2.05, 1.35), 145, 2.0, (0.74, 0.85, 1.0)),
    ):
        light = bpy.data.lights.new(name, "AREA")
        light.energy = gain * (height / 2.0) ** 2
        light.shape = "DISK"
        light.size = size * (height / 2.0)
        light.color = color
        obj = bpy.data.objects.new(name, light)
        bpy.context.collection.objects.link(obj)
        obj.location = Vector(loc) * (height / 2.0)
        look_at(obj, center)

    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.render.film_transparent = True
    scene.view_settings.look = "AgX - Medium High Contrast"
    # Render enough extra width for the angled camera.
    scene.render.resolution_x = max(228, min(440, round(410 * width / height * 1.22)))
    scene.render.resolution_y = 410
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.image_settings.compression = 65
    scene.render.filepath = str(output / (stem + ".png"))
    bpy.ops.render.render()
    # Crop transparent margins before downsizing. Preserve a thin guard band around
    # the silhouettes for linear filtering in the platform game's 2D renderer.
    source = bpy.data.images.get("Render Result")
    source.save_render(scene.render.filepath)
    sprite = bpy.data.images.load(scene.render.filepath, check_existing=False)
    width, height = sprite.size
    buffer = np.empty(width * height * 4, dtype=np.float32)
    sprite.pixels.foreach_get(buffer)
    pixels = buffer.reshape(height, width, 4)
    rows, columns = np.nonzero(pixels[:, :, 3] >= 0.04)
    start_x, end_x = max(0, columns.min() - 4), min(width, columns.max() + 5)
    start_y, end_y = max(0, rows.min() - 4), min(height, rows.max() + 5)
    cropped = np.ascontiguousarray(pixels[start_y:end_y, start_x:end_x, :])
    height, width, _ = cropped.shape
    final = bpy.data.images.new(stem, width=width, height=height, alpha=True)
    final.colorspace_settings.name = sprite.colorspace_settings.name
    final.pixels.foreach_set(cropped.ravel())
    ratio = min(160 / width, 216 / height)
    final.scale(round(width * ratio), round(height * ratio))
    final.filepath_raw = scene.render.filepath
    final.file_format = "PNG"
    final.save()


def main():
    trailing = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    output = Path(trailing[0]).resolve() if trailing else Path(__file__).resolve().parent.parent / "assets/gelo"
    output.mkdir(parents=True, exist_ok=True)
    for stem, build, seed in zip(STEMS, (seal, column, lock), (16367, 19087, 9846)):
        bpy.ops.wm.read_factory_settings(use_empty=True)
        actors = build(palette(), random.Random(seed))
        bpy.ops.export_scene.gltf(filepath=str(output / (stem + ".glb")), export_format="GLB",
                                  export_yup=True, export_animations=False,
                                  export_cameras=False, export_lights=False)
        print(f"{stem}: {sum(len(obj.data.polygons) for obj in actors)} faces", flush=True)
        render(actors, stem, output)


if __name__ == "__main__":
    main()
