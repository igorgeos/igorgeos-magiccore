"""Build the Andarilho's articulated GLB with Blender in background mode."""
import math
import sys

import bpy
from mathutils import Vector

bpy.ops.wm.read_factory_settings(use_empty=True)


def material(name, color, metal=0.0, roughness=0.65):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = True
    shader = mat.node_tree.nodes["Principled BSDF"]
    shader.inputs["Base Color"].default_value = mat.diffuse_color
    shader.inputs["Metallic"].default_value = metal
    shader.inputs["Roughness"].default_value = roughness
    return mat


cloth = material("Verde pinho", (.035, .096, .085))
fold = material("Dobra do tecido", (.063, .155, .131))
lining = material("Forro oxidado", (.182, .067, .031))
scarf = material("Lenço de ferrugem", (.29, .083, .043))
leather = material("Couro castanho", (.117, .065, .041))
dark = material("Couro escuro", (.052, .031, .028))
skin = material("Pele", (.40, .239, .154))
shadow = material("Interior do capuz", (.022, .020, .019))
steel = material("Aço de vigia", (.24, .31, .35), .55, .33)
edge = material("Fio polido", (.54, .62, .65), .66, .28)
brass = material("Latão antigo", (.39, .217, .076), .45, .38)


def coordinates(point):
    x, y, z = point
    return x, -z, y


def mesh(parent, name, vertices, faces, materials, slots=None, smooth=True):
    data = bpy.data.meshes.new(name)
    data.from_pydata([coordinates(v) for v in vertices], [], faces)
    data.update()
    for mat in materials:
        data.materials.append(mat)
    for polygon in data.polygons:
        polygon.use_smooth = smooth
        if slots is not None:
            polygon.material_index = slots[polygon.index]
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.parent = parent
    return obj


def socket(name):
    node = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(node)
    return node


def loft(part, name, rings, mat, sides=12, alternate=None):
    vertices = []
    for y, x, z, rx, rz in rings:
        for i in range(sides):
            a = math.tau * i / sides
            vertices.append((x + rx * math.cos(a), y, z + rz * math.sin(a)))
    faces = [tuple(range(sides))]
    slots = [0]
    for row in range(len(rings) - 1):
        for i in range(sides):
            a = row * sides + i
            b = row * sides + (i + 1) % sides
            faces.append((a, a + sides, b + sides, b))
            slots.append(int(alternate is not None and i % 4 == 2))
    faces.append(tuple(reversed(range(len(vertices) - sides, len(vertices)))))
    slots.append(0)
    return mesh(part, name, vertices, [tuple(reversed(face)) for face in faces],
                [mat, alternate] if alternate else [mat], slots)


def rounded(part, name, center, size, mat):
    x, y, z = center
    rx, ry, rz = size
    sections = []
    for row in range(9):
        a = math.pi * row / 8
        r = max(.015, math.sin(a))
        sections.append((y + ry * math.cos(a), x, z, rx * r, rz * r))
    return loft(part, name, sections, mat, 12)


def band(part, name, start, end, thickness, mat):
    a, b = Vector(start), Vector(end)
    side = Vector((-(b-a).y, (b-a).x, 0)).normalized() * thickness
    vertices = [a-side, b-side, b+side, a+side]
    return mesh(part, name, vertices, [(0, 1, 2, 3)], [mat], smooth=False)


torso = socket("torso")
loft(torso, "Gibao", [(37,-2,0,4,4),(33,0,0,8,13),(25,0,0,10,14.6),
                      (14,0,0,9,11.3),(5,0,0,7.3,10),(-5,-1,0,8.2,12),(-11,-1,0,8,12)], leather, alternate=dark)
loft(torso, "Cinto", [(4,0,0,7.9,10.9),(1,0,0,8.5,11.3),(-2,0,0,8.5,11.3)], dark)
rounded(torso, "Fivela", (7,1,7.2), (2.5,2.2,1.8), brass)
band(torso, "Bandoleira próxima", (-4,29,15.0), (5,9,13.0), 1.45, dark)
band(torso, "Costura da bandoleira", (-5,28,15.1), (4,8,13.1), .35, brass)
band(torso, "Bandoleira distante", (-4,30,-14.6), (5,5,-10.7), 1.0, dark)
rounded(torso, "Bolsa", (-6,-2,11), (5.7,6.7,3.3), leather)
rounded(torso, "Fecho da bolsa", (-4,-1,14), (1.25,1.25,.8), brass)

head = socket("head")
loft(head, "Capuz", [(24,-3,0,1,1),(21,-3,0,5.4,6.8),(17,-2,0,8,10),
                     (12,-2,0,9.6,10.9),(5,-3,0,7.7,8.4),(-2,-2,0,5,6.1)], cloth, alternate=fold)
rounded(head, "Sombra sob o capuz", (3,10,0), (6.3,8.1,7.2), shadow)
rounded(head, "Rosto", (6.5,8.6,0), (4.1,6.8,5.6), skin)
rounded(head, "Nariz", (10,9.5,0), (2.1,2.45,1.6), skin)
rounded(head, "Lenço", (5.3,4.1,0), (6.0,2.6,6.5), scarf)
rounded(head, "Beiral do capuz", (4,15.1,0), (6.5,2.6,7.9), cloth)
for sign in (-1,1):
    rounded(head, "Olho", (9.5,10.6,3.3*sign), (1.1,.65,1.0), shadow)

for name, side in (("near", 1), ("far", -1)):
    arm = socket("upper_" + name)
    loft(arm, "Manga", [(3,0,0,4.1,4.1),(0,0,0,5.5,5.1),
                       (-10,0,0,4.8,4),(-17,0,0,3.7,3.6)], cloth, alternate=fold)
    loft(arm, "Ombreira", [(4,-1,side*1.3,3.2,3.1),(2,-.7,side*2.4,6.2,4.9),
                          (-2,-.4,side*2.9,6.6,4.8),(-6,-.6,side*2.9,4.8,3.8)], steel, 9, edge)
    rounded(arm, "Rebite do ombro", (1,-1,side*7.3), (.85,.85,.55), brass)
    forearm = socket("fore_" + name)
    loft(forearm, "Braçadeira", [(2,0,0,3.5,3.6),(-3,0,0,4.1,3.85),
                              (-12,0,0,3.3,3.1),(-18,0,0,2.65,2.9)], leather)
    rounded(forearm, "Placa do antebraço", (-.6,-7,side*2.4), (3.5,6.4,2.05), steel)
    glove = socket("hand_" + name)
    rounded(glove, "Luva", (.25,-1.1,0), (3.5,4.4,3.1), dark)
    rounded(glove, "Nó da luva", (1.1,-1.45,side*1.7), (2.15,2.05,1.7), leather)
    thigh = socket("thigh_" + name)
    loft(thigh, "Calça", [(3,0,0,6.3,6.15),(-5,0,0,6.6,5.8),(-21,0,0,5.3,4.7),
                        (-29,0,0,4.6,4.5)], dark)
    shin = socket("shin_" + name)
    loft(shin, "Perneira", [(3,0,0,4.6,4.5),(-2,0,0,5,4.7),(-13,-.5,0,4.8,4.2),
                          (-26,0,0,3.65,3.7),(-30,0,0,3.5,3.6)], leather)
    rounded(shin, "Joelho de aço", (2.7,-1,1.25*side), (4.3,5.5,4.6), steel)
    for y in (-11, -18):
        loft(shin, "Fita da perneira", [(y+.7,-.4,0,4.85,4.3),(y-.7,-.4,0,4.78,4.25)], dark)
    boot = socket("boot_" + name)
    loft(boot, "Bota", [(4,0,0,3.4,3.8),(1,0,0,4.65,4.25),
                       (-2,3.5,0,8.1,4.45),(-5,4.4,0,9.15,4.65),(-6,4.4,0,8.9,4.65)], dark)
    rounded(boot, "Biqueira", (10,-3.7,0), (3.8,2.15,4.1), leather)

mantle = socket("mantle")
rounded(mantle, "Gola do manto", (-2.4,-1,0), (9,5,15), cloth)
for sign in (-1,1):
    rounded(mantle, "Fíbula do manto", (5.9,-3,sign*10.5), (1.9,2.25,1.8), brass)
cape = socket("cape")
vertices, faces, slots = [], [], []
columns, rows = 16, 18
for row in range(rows + 1):
    t = row / rows
    for col in range(columns + 1):
        s = col / columns * 2 - 1
        y = -54 * t + t**6 * (3.5 * math.sin(col * 1.38) + 2.5 * abs(s))
        x = -4 - 11 * t - 5.8 * (1 - s*s) + 2.4 * math.cos(s*9 + t*1.2) - 4.3*s*t
        vertices.append((x, y, s * (12.3 + 4.4 * t)))
        if row < rows and col < columns:
            a = row * (columns + 1) + col
            face = (a, a + 1, a + columns + 2, a + columns + 1)
            faces.append(face)
            slots.append(2 if col in (0, columns - 1) else int(col in (1, 6, 11, 15)))
fabric = mesh(cape, "Tecido ondulante", vertices, faces, [cloth, fold, lining], slots)
fabric.shape_key_add(name="Basis")
for name, offset in (("Arrasto", 0), ("Ondulação", math.pi / 2)):
    morph = fabric.shape_key_add(name=name)
    for index, point in enumerate(morph.data):
        t = (index // (columns + 1)) / rows
        s = (index % (columns + 1)) / columns
        if offset == 0:
            point.co.x -= 23 * t*t
            point.co.z += 13 * t*t
        else:
            point.co.x += 5.2 * t*t * math.sin(t*5.5 + s*6.0)
            point.co.z += 3.5 * t*t * math.cos(t*5.5 + s*6.0)

sheath = socket("sheath")
loft(sheath, "Corpo da bainha", [(1,0,0,2.8,2.5),(-3,0,0,2.7,2.5),
                               (-43,0,0,2.35,1.85),(-54,0,0,1.35,1.45)], dark)
for y in (0, -16, -50):
    loft(sheath, "Aro da bainha", [(y+1.2,0,0,2.9,2.75),(y-1.3,0,0,2.9,2.75)], brass)
sword = socket("sword")
loft(sword, "Cabo", [(7.5,0,0,2.05,1.9),(5,0,0,1.7,1.7),(-4.8,0,0,1.7,1.7)], dark)
rounded(sword, "Pomo", (0,7.1,0), (2.5,1.7,2), brass)
rounded(sword, "Guarda", (0,-5,0), (6.3,1.5,2.2), brass)
blade = socket("blade")
blade.parent = sword
blade.location.z = -5
loft(blade, "Lâmina forjada", [(0,0,0,3.6,1.3),(-4,0,0,3.8,1.24),
                             (-36,0,0,3.2,.84),(-47,0,0,2.35,.55),(-54.5,0,0,.05,.05)], steel, 8, edge)

for pivot in [obj for obj in bpy.context.scene.objects if obj.type == "EMPTY"]:
    parts = [item for item in pivot.children if item.type == "MESH"]
    if len(parts) < 2:
        continue
    bpy.ops.object.select_all(action="DESELECT")
    for item in parts:
        item.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

bpy.ops.export_scene.gltf(filepath=sys.argv[sys.argv.index("--") + 1], export_format="GLB",
                         export_animations=False, export_yup=True)
