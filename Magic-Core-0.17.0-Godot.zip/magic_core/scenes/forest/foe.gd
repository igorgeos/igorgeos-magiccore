extends CharacterBody2D

signal fallen(foe)
signal contact(damage: int, push: float)
signal vitality(value: int)

const Receiver := preload("res://scenes/forest/foe_receiver.gd")
const Rig := preload("res://scenes/forest/rig/creature_motion.gd")
const Impact := preload("res://systems/combat/ancestral_impact.gd")
const SIGHT := [284.0, 239.0, 505.0]
const PACE := [84.0, 55.0, 71.0]
const WINDUP := [0.46, 0.77, 0.88]
const RECOVERY := [0.50, 0.96, 1.14]
const WAVE_SPEED := 360.0
const WAVE_DURATION := 0.55

enum State { PATROL, OBSERVE, ALERT, PURSUE, WINDUP, STRIKE, RECOVER, HURT, DEAD }
enum Move { RAKE, STOMP, CHARGE }
var state := State.PATROL
var kind := 0
var hero: CharacterBody2D
var receiver := Receiver.new()
var rig: Rig
var height := 145.0
var home := 0.0
var side := -1.0
var time := 0.0
var age := 0.0
var memory := 0.0
@export var memory_duration := 3.2
var last_seen := 0.0
var sight_clock := 0.0
var spotted := false
var attack := Move.RAKE
var count := 0
var spent := false
var angry := false
var armor := 0.0
var wave_origin := Vector2.ZERO
var follow_charge := false
var sight_multiplier := 1.0
var territory := Vector2(-INF, INF)
var _scan_clock := 0.0
var _patrol_side := -1.0
var _target_speed := 0.0
var _ray := PhysicsRayQueryParameters2D.new()
var _contact_shape := CapsuleShape2D.new()
var _wave_shape := RectangleShape2D.new()
var _hero_hull: CollisionShape2D
var _last_grip := Vector2.ZERO
var _last_tip := Vector2.ZERO
var _sweep_started := false


func _ready() -> void:
	home = position.x
	_hero_hull = hero.get_node("Colisao")
	height = _body_height()
	collision_layer = 0
	collision_mask = 1
	floor_snap_length = 8.0
	_ray.collision_mask = 1
	_wave_shape.size = Vector2(43, 26)
	var hull := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(_body_width(), height * 0.64)
	hull.shape = box
	hull.position.y = -box.size.y * 0.5
	add_child(hull)

	receiver.collision_layer = 4
	receiver.collision_mask = 0
	_configure_receiver()
	var hurt := CollisionShape2D.new()
	var target := RectangleShape2D.new()
	target.size = Vector2(_hurtbox_width(), height * 0.88)
	hurt.shape = target
	hurt.position.y = -target.size.y * 0.5
	receiver.add_child(hurt)
	add_child(receiver)
	rig = _make_rig()
	add_child(rig)
	rig.setup(self)


func _make_rig() -> Rig:
	return Rig.new()


func _body_height() -> float:
	return [148.0, 159.0, 226.0][kind]


func _body_width() -> float:
	return 30.0


func _hurtbox_width() -> float:
	return [45.0, 58.0, 84.0][kind]


func _configure_receiver() -> void:
	receiver.max_health = [3, 6, 19][kind]
	receiver.impact_resistance = [0.18, 0.65, 1.25][kind]


func _recovery_time() -> float:
	return RECOVERY[kind]


func vulnerable() -> bool:
	return state != State.DEAD and armor <= 0.0


func struck(hit: Impact) -> void:
	rig.impact(hit.direction, hit.strength)
	vitality.emit(receiver.health)
	if receiver.health == 0:
		velocity = Vector2.ZERO
		change(State.DEAD, 0.73)
		return
	armor = 0.105
	velocity.x = hit.direction.x * hit.strength * 131.0
	memory = memory_duration
	last_seen = hero.position.x
	var fury := kind == 2 and receiver.health <= 9
	if fury and not angry:
		count = 0
	angry = fury
	if kind != 2 or state not in [State.WINDUP, State.STRIKE]:
		change(State.HURT, 0.19 if kind == 0 else 0.16)


func suspend(paused: bool) -> void:
	set_physics_process(not paused)
	receiver.set_physics_process(not paused and state != State.DEAD)


func change(next: State, duration := 0.0) -> void:
	state = next
	time = duration
	age = 0.0
	if next == State.STRIKE:
		_sweep_started = false


func ray(a: Vector2, b: Vector2) -> bool:
	_ray.from = a
	_ray.to = b
	return not get_world_2d().direct_space_state.intersect_ray(_ray).is_empty()


func step_toward(goal: float, speed: float) -> bool:
	goal = clampf(goal, territory.x, territory.y)
	if absf(goal - position.x) < 6:
		return false
	var heading := signf(goal - position.x)
	var edge := position + Vector2(heading * 23.0, -24)
	if not ray(edge, edge + Vector2(0, 63)) or ray(edge, edge + Vector2(heading * 12, 0)):
		return false
	_target_speed = heading * speed
	side = heading
	return true


func _physics_process(dt: float) -> void:
	if state != State.DEAD and absf(hero.position.x - position.x) > 920 and is_on_floor() and memory <= 0.0:
		return
	age += dt
	time -= dt
	armor = maxf(armor - dt, 0.0)
	if state == State.DEAD:
		rig.tick(dt, 0.0)
		queue_redraw()
		if time <= 0.0:
			set_physics_process(false)
			fallen.emit(self)
			queue_free()
		return

	var separation := hero.position - position
	_update_awareness(separation, dt)
	_target_speed = 0.0
	_choose_action(separation)
	_steer_horizontally(dt)
	velocity.y = minf(velocity.y + dt * 1650.0, 740.0)
	move_and_slide()
	rig.tick(dt, get_position_delta().x)
	if state == State.STRIKE:
		if attack == Move.STOMP and age <= 0.0:
			var hands: Vector2 = rig.to_global((rig.pose[8] + rig.pose[12]) * 0.5)
			wave_origin = Vector2(hands.x, global_position.y)
		apply_attack()
		if time <= 0.0:
			follow_charge = angry and attack == Move.STOMP
			change(State.RECOVER, 0.55 if follow_charge else _recovery_time())
	queue_redraw()


func _steer_horizontally(dt: float) -> void:
	var braking := 740.0 if state != State.HURT else 375.0
	velocity.x = move_toward(velocity.x, _target_speed, braking * dt)


func _update_awareness(separation: Vector2, dt: float) -> void:
	sight_clock -= dt
	if sight_clock <= 0.0:
		sight_clock = 0.13
		var distance: float = SIGHT[kind] * sight_multiplier
		# A sprint carries through the mist. Stone and earth still block sight.
		if absf(hero.get_real_velocity().x) > 208.0:
			distance += 62.0
		spotted = absf(separation.x) < distance and absf(separation.y) < 172.0 and not ray(
			position - Vector2(0, height * 0.48), hero.position - Vector2(0, 62)
		)
	if spotted:
		memory = memory_duration
		last_seen = hero.position.x
		_scan_clock = 0.0
	else:
		memory = maxf(memory - dt, 0.0)
		_scan_clock += dt


func _choose_action(separation: Vector2) -> void:
	match state:
		State.PATROL:
			if spotted:
				side = 1.0 if separation.x >= 0 else -1.0
				change(State.OBSERVE, [0.24, 0.39, 0.32][kind])
			elif kind == 0 and not step_toward(home + _patrol_side * 72.0, 32.0):
				_patrol_side *= -1.0
		State.OBSERVE:
			if time <= 0.0:
				change(State.ALERT, [0.28, 0.33, 0.58][kind])
		State.ALERT, State.HURT:
			if time <= 0.0:
				change(State.PURSUE)
		State.PURSUE:
			_pursue(separation)
		State.WINDUP:
			if time <= 0.0:
				change(State.STRIKE, WAVE_DURATION if attack == Move.STOMP else (0.52 if attack == Move.CHARGE else 0.23))
		State.STRIKE:
			if attack == Move.CHARGE and age < 0.44:
				step_toward(position.x + side * 92.0, 318.0)
		State.RECOVER:
			if kind == 0 and age < 0.26:
				var facing_before := side
				step_toward(position.x - side * 38, 51.0)
				side = facing_before
			if time <= 0.0:
				if follow_charge and spotted and absf(separation.x) < 292.0:
					_prepare(Move.CHARGE, separation.x, 0.69)
				else:
					follow_charge = false
					change(State.PURSUE)


func _pursue(separation: Vector2) -> void:
	if memory <= 0.0:
		if not step_toward(home, 43.0):
			change(State.PATROL)
		return
	if not spotted:
		if not step_toward(last_seen, PACE[kind] * 0.75):
			# Scan at the last known location before returning to the patrol.
			side = -1.0 if fposmod(_scan_clock, 1.24) < 0.62 else 1.0
		return

	var distance := absf(separation.x)
	if absf(separation.y) < 115.0:
		if kind == 2 and distance < 276.0:
			var pattern := [Move.RAKE, Move.STOMP, Move.RAKE, Move.CHARGE]
			if angry:
				pattern = [Move.STOMP, Move.RAKE, Move.CHARGE]
			var selected: Move = pattern[count % pattern.size()]
			if distance <= [134.0, 174.0, 263.0][selected]:
				var warning: float = [0.87, 1.01, 0.91][selected]
				_prepare(selected, separation.x, warning)
				return
		elif kind < 2 and distance <= [74.0, 91.0][kind]:
			_prepare(Move.RAKE, separation.x, WINDUP[kind])
			return
	step_toward(last_seen, PACE[kind])


func _prepare(move: Move, direction: float, duration: float) -> void:
	attack = move
	side = 1.0 if direction >= 0.0 else -1.0
	spent = false
	follow_charge = false
	count += 1
	change(State.WINDUP, duration)


func _wave_at(direction: float) -> Vector2:
	return wave_origin + Vector2(direction * age * WAVE_SPEED, -15)


func apply_attack() -> void:
	if spent:
		return
	if attack == Move.STOMP:
		for direction in [-1.0, 1.0]:
			var point := _wave_at(direction)
			if _wave_shape.collide(Transform2D(0.0, point), _hero_hull.shape, _hero_hull.global_transform):
				_hit(point, direction, 19, 220.0)
		return

	var start: Vector2 = rig.to_global(rig.pose[7])
	var end: Vector2 = rig.to_global(rig.pose[8])
	var radius: float = [10.0, 15.0, 16.0][kind]
	var damage: int = [12, 20, 22][kind]
	var push: float = [120.0, 205.0, 235.0][kind]
	if attack == Move.CHARGE:
		start = rig.to_global(rig.pose[5])
		end = rig.to_global(rig.pose[6])
		radius = 30.0
		damage = 25
		push = 283.0
	else:
		start = rig.to_global(rig.pose[6]).lerp(start, 0.60)
	# Both samples use the same joints that deform the visible enemy.
	if _sweep_started and _touches_hero(_last_grip.lerp(start, 0.5), _last_tip.lerp(end, 0.5), radius):
		_hit(start, side, damage, push)
	if not spent and _touches_hero(start, end, radius):
		_hit(start, side, damage, push)
	_last_grip = start
	_last_tip = end
	_sweep_started = true


func _touches_hero(start: Vector2, end: Vector2, radius: float) -> bool:
	var axis := end - start
	_contact_shape.radius = radius
	_contact_shape.height = axis.length() + radius * 2.0
	return _contact_shape.collide(
		Transform2D(axis.angle() - PI * 0.5, (start + end) * 0.5), _hero_hull.shape, _hero_hull.global_transform
	)


func _hit(point: Vector2, direction: float, damage: int, push: float) -> void:
	if spent or ray(point, _hero_hull.global_position):
		return
	spent = true
	contact.emit(damage, push * direction)


func _draw() -> void:
	if state == State.WINDUP:
		var fade := smoothstep(0.04, 0.27, age)
		var tint := Color(0.80, 0.62, 0.38, fade * 0.78)
		var spread: float = [84.0, 103.0, 139.0][kind]
		if attack == Move.STOMP:
			spread = WAVE_SPEED * WAVE_DURATION
		if attack == Move.CHARGE:
			spread = 202.0
		var first := -spread if attack == Move.STOMP or side < 0.0 else 0.0
		var last := spread if attack == Move.STOMP or side > 0.0 else 0.0
		draw_line(Vector2(first, -3), Vector2(last, -3), tint, 2.5, true)
	if state == State.STRIKE and attack == Move.STOMP:
		var fade := 1.0 - smoothstep(0.34, WAVE_DURATION, age)
		for direction in [-1.0, 1.0]:
			var spot := to_local(_wave_at(direction)) + Vector2(0, 13)
			var crest := spot + Vector2(direction * 5, -24)
			draw_polyline(PackedVector2Array([spot + Vector2(-22, 1), crest, spot + Vector2(22, 1)]),
				Color(0.82, 0.71, 0.49, fade), 3.0, true)
