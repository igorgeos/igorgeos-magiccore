extends Node2D

enum Kind { NONE, SNOW, SMOOTH_ICE, FRAGILE_ICE, FROZEN_ROCK, STABLE_DECK }

const FLOOR_MARGIN := 6.0
const TRACK_LIFETIME := 1.1
const MAX_TRACKS := 14

class Deck:
	var span: Rect2
	var kind: Kind
	var collision: CollisionShape2D

	func _init(bounds: Rect2, material: Kind, shape: CollisionShape2D) -> void:
		span = bounds
		kind = material
		collision = shape

class Footprint:
	var origin: Vector2
	var direction: float
	var end_time: float

	func _init(point: Vector2, facing: float, expires: float) -> void:
		origin = point
		direction = facing
		end_time = expires

var _ice_bands: PackedVector2Array
var _rock_bands: PackedVector2Array
var _decks: Array[Deck] = []
var _tracks: Array[Footprint] = []
var _clock := 0.0
var _step_distance := 0.0
var _previous_foot := Vector2.ZERO
var _following := false
var _show_tracks := true


func setup(ground_height: Callable, scenery: Node2D, ice_bands: Array, rock_bands: Array) -> void:
	_ice_bands = PackedVector2Array(ice_bands)
	_rock_bands = PackedVector2Array(rock_bands)
	for band in _ice_bands:
		scenery.gloss(_sample_band(band, ground_height))
	for band in _rock_bands:
		var top := _sample_band(band, ground_height)
		_paint_rock_band(top, scenery.texture("rock"))


func register_deck(span: Rect2, material: String, collision: CollisionShape2D) -> void:
	var kind := Kind.STABLE_DECK
	match material:
		"ice": kind = Kind.SMOOTH_ICE
		"brittle": kind = Kind.FRAGILE_ICE
		"stone": kind = Kind.FROZEN_ROCK
	_decks.append(Deck.new(span, kind, collision))


func at(feet: Vector2, ground_height: float) -> Kind:
	var gap := absf(feet.y - ground_height)
	var nearest := gap if gap <= FLOOR_MARGIN else INF
	var kind := _ground_kind(feet.x) if nearest != INF else Kind.NONE
	for deck in _decks:
		if not is_instance_valid(deck.collision) or deck.collision.disabled:
			continue
		if feet.x < deck.span.position.x or feet.x > deck.span.end.x:
			continue
		var deck_gap := absf(feet.y - deck.span.position.y)
		if deck_gap <= FLOOR_MARGIN and deck_gap < nearest:
			nearest = deck_gap
			kind = deck.kind
	return kind


func reset_steps() -> void:
	_following = false
	_step_distance = 0.0


func advance_steps(delta: float, feet: Vector2, kind: Kind, grounded: bool, speed: float, reduced_motion: bool) -> void:
	_clock += delta
	var had_tracks := not _tracks.is_empty()
	_show_tracks = not reduced_motion
	if not _show_tracks:
		_tracks.clear()
	while not _tracks.is_empty() and _tracks[0].end_time <= _clock:
		_tracks.pop_front()
	if not grounded or kind != Kind.SNOW or absf(speed) < 25.0 or not _show_tracks:
		reset_steps()
	else:
		if _following:
			_step_distance += absf(feet.x - _previous_foot.x)
			var stride := lerpf(25.0, 40.0, smoothstep(140.0, 265.0, absf(speed)))
			if _step_distance >= stride:
				_step_distance = fmod(_step_distance, stride)
				if _tracks.size() >= MAX_TRACKS:
					_tracks.pop_front()
				var direction := signf(speed)
				_tracks.append(Footprint.new(feet - Vector2(direction * 4.0, 0.0), direction, _clock + TRACK_LIFETIME))
		_following = true
		_previous_foot = feet
	if had_tracks or not _tracks.is_empty():
		queue_redraw()


func _ground_kind(x: float) -> Kind:
	for band in _ice_bands:
		if x >= band.x and x <= band.y:
			return Kind.SMOOTH_ICE
	for band in _rock_bands:
		if x >= band.x and x <= band.y:
			return Kind.FROZEN_ROCK
	return Kind.SNOW


func _sample_band(band: Vector2, ground_height: Callable) -> PackedVector2Array:
	var points := PackedVector2Array()
	var divisions := maxi(2, ceili((band.y - band.x) / 12.0))
	for i in divisions + 1:
		var x := lerpf(band.x, band.y, float(i) / divisions)
		var y: float = ground_height.call(x)
		if is_finite(y):
			points.append(Vector2(x, y))
	return points


func _paint_rock_band(top: PackedVector2Array, texture: Texture2D) -> void:
	if top.size() < 2:
		return
	var face := Polygon2D.new()
	var outline := top.duplicate()
	for i in range(top.size() - 1, -1, -1):
		var rim := 7.0 + 4.0 * cos(top[i].x * 0.13)
		outline.append(top[i] + Vector2(0.0, rim))
	face.polygon = outline
	face.color = Color("#a9bac9")
	face.texture = texture
	face.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	var uv := PackedVector2Array()
	for point in outline:
		uv.append(point * 0.8)
	face.uv = uv
	add_child(face)
	var rim := Line2D.new()
	rim.points = top
	rim.width = 1.2
	rim.default_color = Color("#bfd4e4")
	rim.antialiased = true
	add_child(rim)


func _draw() -> void:
	if not _show_tracks:
		return
	for step in _tracks:
		var alpha := clampf((step.end_time - _clock) / TRACK_LIFETIME, 0.0, 1.0)
		var point := step.origin
		draw_line(point + Vector2(-3.5 * step.direction, 1.4), point + Vector2(3.0 * step.direction, 1.4),
			Color(0.31, 0.41, 0.50, 0.47 * alpha), 2.2, true)
		draw_line(point + Vector2(-3.0 * step.direction, 2.8), point + Vector2(3.0 * step.direction, 2.8),
			Color(0.89, 0.96, 0.99, 0.53 * alpha), 1.0, true)
