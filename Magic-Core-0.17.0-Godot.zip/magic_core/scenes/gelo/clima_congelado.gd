extends Node2D
## Atmosfera atrás dos elementos jogáveis. A rajada visual e sonora usa o mesmo
## vento local que empurra o personagem na travessia, sem mudar sua física.

const MIST := preload("res://assets/forest/cerracao.webp")
const FLAKES := [12, 28, 44]
const MIST_BANDS := [2, 3, 4]
const PAINT_INTERVAL := [1.0 / 16.0, 1.0 / 20.0, 1.0 / 24.0]
const REACTION_TIME := 0.42
const MAX_REACTIONS := 6

var wind_mix := 0.0
var _wind := 0.0
var _wind_travel := 0.0
var _clock := 0.0
var _paint_in := 0.0
var _center := 0.0
var _painted_center := 0.0
var _view_width := 1280.0
var _route_width := 1280.0
var _art := ""
var _quality := 2
var _still := false
var _contrast := false
var _storm := 0.0
var _impact_points := PackedVector2Array()
var _impact_times := PackedFloat32Array()
var _fine_flakes := PackedVector2Array()
var _near_flakes := PackedVector2Array()
var _streaks := PackedVector2Array()


func setup(art: String, route_width: float) -> void:
	_art = art
	_route_width = route_width
	apply_preferences()


func set_view(center: float, visible_width: float) -> void:
	if not is_equal_approx(_view_width, visible_width) or (_still and absf(center - _painted_center) > 96.0):
		queue_redraw()
	_center = center
	_view_width = visible_width


func apply_preferences() -> void:
	_quality = clampi(int(Preferences.values.visual_quality), 0, 2)
	_still = Preferences.values.reduced_motion
	_contrast = Preferences.values.high_contrast
	queue_redraw()


func advance(delta: float, local_gust: float) -> void:
	_clock += delta
	if _art == "passo":
		var interval := fposmod(_clock, 12.0)
		_storm = smoothstep(6.0, 7.8, interval) * (1.0 - smoothstep(9.0, 11.8, interval))
	var breeze := -11.0 if _art == "passo" else -5.0
	var target_wind := breeze - _storm * 25.0 + clampf(local_gust, -80.0, 80.0)
	_wind = lerpf(_wind, target_wind, 1.0 - exp(-delta * 4.0))
	_wind_travel += _wind * delta
	var gust_gain := clampf(absf(local_gust) / 62.0, 0.0, 1.0)
	var gain_target := maxf(gust_gain, _storm * 0.58)
	wind_mix = lerpf(wind_mix, gain_target, 1.0 - exp(-delta * 2.2))

	var removed := false
	for i in range(_impact_times.size() - 1, -1, -1):
		_impact_times[i] += delta
		if _impact_times[i] >= REACTION_TIME:
			_impact_times.remove_at(i)
			_impact_points.remove_at(i)
			removed = true
	# With reduced motion, only a settled mist or brief stationary chips are drawn.
	if _still and _impact_points.is_empty() and not removed:
		return
	_paint_in -= delta
	if _paint_in <= 0.0 or removed:
		_paint_in = float(PAINT_INTERVAL[_quality])
		queue_redraw()


func ice_reaction(point: Vector2) -> void:
	if not _visible_x(point.x, 65.0):
		return
	if _impact_points.size() == MAX_REACTIONS:
		_impact_points.remove_at(0)
		_impact_times.remove_at(0)
	_impact_points.append(point)
	_impact_times.append(0.0)
	queue_redraw()


func _visible_x(x: float, margin: float) -> bool:
	return absf(x - _center) <= _view_width * 0.5 + margin


func _draw() -> void:
	_painted_center = _center
	_paint_mist()
	if not _still:
		_paint_flakes()
		if _quality > 0:
			_paint_wind()
	_paint_ice_reactions()


func _paint_mist() -> void:
	var span := _route_width + 540.0
	var travel := 0.0 if _still else _clock * -4.0 + _wind_travel * 0.26
	var bands: int = MIST_BANDS[_quality]
	var density := (0.26 if _contrast else 0.62) * (0.24 + (0.0 if _still else _storm * 0.10))
	for i in bands:
		var x := fposmod(float(i) * span / bands + 270.0 + travel, span) - 270.0
		if not _visible_x(x, 320.0):
			continue
		var y := 297.0 + (i % 3) * 65.0
		draw_texture_rect(MIST, Rect2(x - 318.0, y, 636.0, 99.0), false,
			Color(0.72, 0.85, 0.94, density))


func _paint_flakes() -> void:
	_fine_flakes.clear()
	_near_flakes.clear()
	var count: int = FLAKES[_quality]
	var span := maxf(_route_width, _view_width) + 208.0
	for i in count:
		var offset := fposmod(i * 163.7 + 107.0, span)
		var drift := sin(0.9 * _clock + i * 1.87) * 9.0
		var x := fposmod(offset + _wind_travel + drift, span) - 104.0
		if not _visible_x(x, 25.0):
			continue
		var y := fposmod(i * 57.41 + _clock * (13.0 + (i % 7) * 2.8), 693.0)
		var point := Vector2(x, y)
		var close := i % 5 == 0 and _quality > 0
		var half := Vector2(clampf(_wind * 0.035, -2.5, 2.5), 1.15 if close else 0.75)
		var group := _near_flakes if close else _fine_flakes
		group.append(point - half)
		group.append(point + half)
		if close and _quality == 2 and absf(_wind) < 30.0:
			group.append(point + Vector2(-1.05, 0))
			group.append(point + Vector2(1.05, 0))
	if not _fine_flakes.is_empty():
		draw_multiline(_fine_flakes, Color(0.79, 0.89, 0.97, 0.31), 1.0, true)
	if not _near_flakes.is_empty():
		draw_multiline(_near_flakes, Color(0.85, 0.92, 0.98, 0.42), 1.25, true)


func _paint_wind() -> void:
	_streaks.clear()
	var span := _route_width + 200.0
	var gust := clampf(absf(_wind) / 56.0, 0.0, 1.0)
	var direction := -1.0 if _wind <= 0.0 else 1.0
	for i in (5 if _quality == 1 else 8):
		var x := fposmod(i * 407.3 + _wind_travel, span) - 100.0
		if not _visible_x(x, 90.0):
			continue
		var y := 296.0 + (i % 4) * 46.0 + sin(i * 1.83 + _clock * 0.55) * 6.0
		var at := Vector2(x, y)
		var length := (21.0 + (i % 3) * 8.0) * (0.8 + gust * 1.1)
		_streaks.append(at)
		_streaks.append(at + Vector2(length * direction, -1.0))
	if not _streaks.is_empty():
		draw_multiline(_streaks, Color(0.76, 0.87, 0.95, 0.105 + gust * 0.09), 1.0, true)


func _paint_ice_reactions() -> void:
	for hit in _impact_points.size():
		var at := _impact_points[hit]
		if not _visible_x(at.x, 65.0):
			continue
		var age := float(_impact_times[hit])
		var intensity := 1.0 - age / REACTION_TIME
		var tint := Color(0.73, 0.88, 0.97, intensity * (0.42 if _still else 0.68))
		for i in (3 if _still else 4 + _quality * 2):
			var direction := -1.0 if i % 2 == 0 else 1.0
			var rise := 42.0 + fposmod(i * 57.1, 105.0)
			var drift := 37.0 + fposmod(i * 63.0, 90.0)
			var point := at + Vector2(direction * (3.0 + i * 1.7), -4.0 - i % 3 * 1.5)
			if not _still:
				point += Vector2(direction * drift * age, minf(0.0, -rise * age + 250.0 * age * age))
			var length := (2.0 + i % 3 * 1.1) * (0.6 + intensity * 0.4)
			draw_line(point, point + Vector2(direction * length, -length * 0.58), tint, 1.3, true)
