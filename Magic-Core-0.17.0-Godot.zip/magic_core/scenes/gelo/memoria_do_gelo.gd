extends "res://systems/combat/impact_receiver.gd"

## Target for the normal blade sweep. Its fixed hitbox and optional solid
## collider share the same dimensions, so a crack never moves the obstacle.
signal fractured(memory, source: Node)

const ART_PATH := "res://assets/gelo/%s_memoria.png"
const CRACKS := [
	[Vector2(-.41, .09), Vector2(-.23, -.02), Vector2(-.16, .04),
		Vector2(.03, -.12), Vector2(.11, -.07), Vector2(.26, -.21)],
	[Vector2(-.16, .04), Vector2(-.15, .16), Vector2(-.04, .21), Vector2(-.09, .36)],
	[Vector2(.03, -.12), Vector2(.02, -.24), Vector2(-.14, -.36)],
	[Vector2(-.04, .21), Vector2(.14, .16), Vector2(.21, .23), Vector2(.39, .22)],
	[Vector2(.11, -.07), Vector2(.17, .053), Vector2(.32, .072)],
	[Vector2(-.23, -.02), Vector2(-.24, -.16), Vector2(-.35, -.20)],
]

@export_range(1, 12) var required_impacts := 3
var impacts_taken := 0
var broken := false
var spec: Dictionary
var _dimensions: Vector2
var _center := Vector2.ZERO
var _art: Sprite2D
var _solid: CollisionShape2D
var _feedback := 0.0


func configure(definition: Dictionary) -> void:
	spec = definition
	name = spec.id
	position = spec.point
	required_impacts = clampi(int(spec.get("impacts", required_impacts)), 1, 12)
	max_health = required_impacts
	impact_resistance = 0.70
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	_dimensions = spec.size
	_center = Vector2(0, -_dimensions.y * .5)


func _ready() -> void:
	super()
	add_child(_box(_dimensions))
	if spec.get("solid", false):
		var support := StaticBody2D.new()
		support.collision_layer = 1
		support.collision_mask = 0
		_solid = _box(_dimensions * Vector2(.86, 1.0))
		support.add_child(_solid)
		add_child(support)
	var art_path := ART_PATH % str(spec.art)
	if ResourceLoader.exists(art_path, "Texture2D"):
		_art = Sprite2D.new()
		_art.texture = load(art_path)
		_art.position = _center
		_art.scale = _dimensions / _art.texture.get_size()
		add_child(_art)
		# Draw cracks over the model while keeping both behind the hero.
		_art.show_behind_parent = true
	set_physics_process(false)


func _box(size: Vector2) -> CollisionShape2D:
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	collision.position = _center
	collision.shape = shape
	return collision


func can_receive_strike() -> bool:
	return not broken


func receive_strike(hit: Impact) -> bool:
	if broken or hit.damage < 1 or hit.sequence <= _latest_hit.get(hit.source_id, -1):
		return false
	_latest_hit[hit.source_id] = hit.sequence
	return _remember_hit(null)


func ground_impact(point: Vector2, radius: float, source: Node) -> bool:
	if broken or not is_instance_valid(source) or source.name not in spec.get("attackers", []) or radius <= 0:
		return false
	var relative := to_local(point) - _center
	var excess := (relative.abs() - _dimensions * .5).max(Vector2.ZERO)
	return _remember_hit(source) if excess.length_squared() <= radius * radius else false


func _remember_hit(source: Node) -> bool:
	impacts_taken += 1
	health = required_impacts - impacts_taken
	if impacts_taken >= required_impacts:
		broken = true
		if is_instance_valid(_solid):
			_solid.set_deferred("disabled", true)
		set_deferred("monitorable", false)
		hide()
		set_physics_process(false)
		fractured.emit(self, source)
	else:
		_feedback = .11
		set_physics_process(true)
		queue_redraw()
	return true


func _physics_process(delta: float) -> void:
	_feedback = maxf(0.0, _feedback - delta)
	if _feedback == 0.0:
		set_physics_process(false)
	queue_redraw()


func _draw() -> void:
	if broken:
		return
	if not is_instance_valid(_art):
		var outline := PackedVector2Array([
			Vector2(-.46, .49), Vector2(-.5, .19), Vector2(-.44, -.30), Vector2(-.21, -.49),
			Vector2(.17, -.50), Vector2(.42, -.37), Vector2(.50, .20), Vector2(.40, .49),
		])
		for i in outline.size():
			outline[i] = _center + outline[i] * _dimensions
		draw_colored_polygon(outline, Color("#648ca4"))
		outline.append(outline[0])
		draw_polyline(outline, Color("#b0cfde"), 2.0, true)
	if impacts_taken == 0:
		return
	var depth := float(impacts_taken) / required_impacts
	var count := mini(1 + 2 * (impacts_taken - 1), CRACKS.size())
	var extent := lerpf(.57, 1.0, depth)
	var width := lerpf(1.0, 1.9, depth)
	var shine := Color("#b9ebfa") if _feedback > 0.0 and not Preferences.values.reduced_motion else Color("#76bdde")
	for i in count:
		var path := PackedVector2Array()
		for point: Vector2 in CRACKS[i]:
			path.append(_center + point * _dimensions * extent)
		draw_polyline(path, Color("#243741"), width + 2, true)
		draw_polyline(path, shine, width, true)
