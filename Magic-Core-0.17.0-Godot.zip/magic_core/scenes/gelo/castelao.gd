extends "res://scenes/forest/foe.gd"

const SovereignRig := preload("res://scenes/gelo/rig_soberano.gd")
const LANDING := 0.17
const CRACK_WIDTH := 104.0
const CRACK_WARNING := 0.96
const CRACK_DURATION := 0.30
const ICE := Color("#9bccea")
const ICE_CORE := Color("#d5f9ff")
const WARNING := Color("#e5c487")
const WARNING_SHADOW := Color("#202233")
const ICE_CHARGE_SPEED := 455.0
const ICE_CHARGE_ACCELERATION := 1690.0
const ICE_CHARGE_REACH := 230.0

enum Encounter { VIGILANCIA, COMBATE, INVERNO_DESPERTADO }

var encounter := Encounter.VIGILANCIA
var floor_at: Callable
var fault_lines := PackedFloat32Array()
var awakening := false
var rupture := false
var ice_charge := false
var _attack_history: Array[Move] = []
var _cracks := PackedFloat32Array()
var _crack_time := 0.0
var _crack_spent := false
var _crack_shape := RectangleShape2D.new()
var _wave_blocked := [false, false]
var _slash_tips := PackedVector2Array()
var _slash_edges := PackedVector2Array()


func _ready() -> void:
	_crack_shape.size = Vector2(CRACK_WIDTH, 52.0)
	super()


func _make_rig() -> Rig:
	return SovereignRig.new()


func _choose_action(separation: Vector2) -> void:
	if awakening:
		if time <= 0.0:
			awakening = false
			change(State.PURSUE)
		return
	match state:
		State.PATROL:
			if spotted and hero.position.x > territory.x - 65.0:
				encounter = Encounter.COMBATE
				side = signf(separation.x) if separation.x != 0.0 else side
				change(State.OBSERVE, 0.44)
		State.WINDUP:
			if time <= 0.0:
				var duration: float = [0.30, 0.78, 0.48][attack]
				change(State.STRIKE, 0.36 if rupture else duration)
		State.STRIKE:
			if attack == Move.CHARGE and age < 0.38:
				step_toward(position.x + side * 80.0, ICE_CHARGE_SPEED if ice_charge else 330.0)
		State.RECOVER:
			if time <= 0.0:
				change(State.PURSUE)
		_:
			super(separation)


func _pursue(separation: Vector2) -> void:
	var distance := absf(separation.x)
	if distance > 370.0 or absf(separation.y) > 143.0 or not spotted:
		step_toward(last_seen, 82.0)
		return

	var choices: Array[Move] = []
	if distance < 122.0:
		choices.append(Move.RAKE)
	if distance < 248.0:
		choices.append(Move.STOMP)
	if distance > 108.0 and distance < 295.0:
		choices.append(Move.CHARGE)
	if choices.is_empty():
		step_toward(hero.position.x, 96.0)
		return

	if count % 4 == 3 and _cracks.is_empty():
		_prepare(Move.STOMP, separation.x, 0.92)
		rupture = true
		_mark_fissures(separation.x, 2 if angry else 1)
		return
	# Prefer the attack used least recently among those that can reach.
	for recent in _attack_history:
		if choices.size() > 1:
			choices.erase(recent)
	var selected := choices[0]
	_prepare(selected, separation.x, [0.74, 0.83, 0.82][selected])
	if angry and selected == Move.CHARGE and _cracks.is_empty():
		_mark_fissures(separation.x, 1)


func _prepare(move: Move, direction: float, duration: float) -> void:
	var route := get_parent()
	ice_charge = (move == Move.CHARGE and is_on_floor() and route.has_method("is_slick_surface_at")
		and route.is_slick_surface_at(position))
	# The path is committed from the first warning, so ice speed never changes without notice.
	super(move, direction, duration + (0.12 if ice_charge else 0.0))
	rupture = false
	_wave_blocked = [false, false]
	_attack_history.erase(move)
	_attack_history.push_front(move)


func _steer_horizontally(dt: float) -> void:
	if ice_charge and state == State.STRIKE and _target_speed != 0.0:
		velocity.x = move_toward(velocity.x, _target_speed, ICE_CHARGE_ACCELERATION * dt)
	else:
		super(dt)


func _recovery_time() -> float:
	if ice_charge:
		return 1.28
	return 1.02 if rupture else float([0.94, 1.08, 1.12][attack])


func struck(hit: Impact) -> void:
	rig.impact(hit.direction, hit.strength)
	if receiver.health == 0:
		_cracks.clear()
		awakening = false
		ice_charge = false
		velocity = Vector2.ZERO
		change(State.DEAD, 1.48)
		queue_redraw()
		vitality.emit(0)
		return
	armor = 0.14
	memory = memory_duration
	last_seen = hero.position.x
	if encounter == Encounter.VIGILANCIA:
		encounter = Encounter.COMBATE
	if not angry and receiver.health * 2 <= receiver.max_health:
		encounter = Encounter.INVERNO_DESPERTADO
		angry = true
		awakening = true
		ice_charge = false
		_cracks.clear()
		velocity.x = 0.0
		change(State.ALERT, 1.12)
	elif not awakening and (hit.strength >= 1.12 or state in [State.PURSUE, State.PATROL, State.OBSERVE]):
		if state == State.WINDUP and rupture:
			_cracks.clear()
		velocity.x = hit.direction.x * hit.strength * 78.0
		change(State.HURT, 0.48 if hit.strength >= 1.12 else 0.20)
	vitality.emit(receiver.health)


func _mark_fissures(direction: float, amount: int) -> void:
	if fault_lines.is_empty():
		return
	var target := hero.position.x + signf(direction) * (106.0 if not rupture else 0.0)
	var nearest := 0
	for index in fault_lines.size():
		if absf(fault_lines[index] - target) < absf(fault_lines[nearest] - target):
			nearest = index
	_cracks.append(fault_lines[nearest])
	if amount > 1 and fault_lines.size() > 1:
		var second := nearest + (1 if nearest + 1 < fault_lines.size() else -1)
		_cracks.append(fault_lines[second])
	_crack_time = 0.0
	_crack_spent = false


func _physics_process(delta: float) -> void:
	var previous := state
	super(delta)
	if state == State.STRIKE and attack == Move.RAKE and not Preferences.values.reduced_motion:
		var tip: Vector2 = rig.attack_point(8)
		var grip: Vector2 = rig.attack_point(7)
		if _slash_tips.is_empty() or tip.distance_squared_to(_slash_tips[-1]) > 4.0:
			_slash_tips.append(tip)
			_slash_edges.append(tip.lerp(grip, 0.27))
			if _slash_tips.size() > 7:
				_slash_tips.remove_at(0)
				_slash_edges.remove_at(0)
	else:
		_slash_tips.clear()
		_slash_edges.clear()
	if previous == State.STRIKE and state == State.RECOVER:
		follow_charge = false
		time = _recovery_time()
	if state == State.DEAD or _cracks.is_empty():
		return
	_crack_time += delta
	if _crack_time >= CRACK_WARNING + CRACK_DURATION:
		_cracks.clear()
	elif _crack_time >= CRACK_WARNING and not _crack_spent:
		for x in _cracks:
			var point := Vector2(x, floor_at.call(x) - 26.0)
			if _crack_shape.collide(Transform2D(0.0, get_parent().to_global(point)), _hero_hull.shape,
					_hero_hull.global_transform):
				_crack_spent = true
				contact.emit(17, signf(hero.position.x - x) * 160.0)
				break


func _wave_at(direction: float) -> Vector2:
	var x := wave_origin.x + direction * maxf(0.0, age - LANDING) * 380.0
	return get_parent().to_global(Vector2(x, floor_at.call(x) - 16.0))


func apply_attack() -> void:
	if attack == Move.STOMP:
		if rupture or age < LANDING:
			return
		if not _sweep_started:
			wave_origin = position
			_sweep_started = true
		for i in 2:
			var direction := -1.0 if i == 0 else 1.0
			var point := _wave_at(direction)
			var local_x: float = get_parent().to_local(point).x
			_wave_blocked[i] = _wave_blocked[i] or local_x < territory.x - 105.0 or local_x > territory.y + 105.0
			if not spent and not _wave_blocked[i] and _wave_shape.collide(
					Transform2D(0.0, point), _hero_hull.shape, _hero_hull.global_transform):
				_hit(point, direction, 19, 220.0)
		return
	if spent or age < 0.07 or (attack == Move.CHARGE and age > 0.40):
		return
	var start: Vector2 = rig.attack_point(7 if attack == Move.RAKE else 5)
	var end: Vector2 = rig.attack_point(8 if attack == Move.RAKE else 7)
	var radius := 11.0 if attack == Move.RAKE else 23.0
	if ice_charge:
		# The leading shoulder and sliding body carry the impact on this variant.
		var shoulder := global_position + Vector2(side * 15.0, -67.0)
		if _touches_hero(shoulder, shoulder + Vector2(side * 31.0, 27.0), 19.0):
			_hit(shoulder, side, 25, 250.0)
	if _touches_hero(start, end, radius) or (_sweep_started and _touches_hero(
			_last_grip.lerp(start, 0.5), _last_tip.lerp(end, 0.5), radius)):
		_hit(start, side, 22 if attack == Move.RAKE else 25, 250.0)
	_sweep_started = true
	_last_grip = start
	_last_tip = end


func _draw() -> void:
	if state == State.DEAD:
		return
	_draw_slash()
	if awakening:
		var rise := sin(PI * clampf(age / 1.12, 0.0, 1.0))
		draw_arc(Vector2(0, -92), 55 + 37 * rise, PI, TAU, 28, Color(ICE, rise * 0.63), 2, true)
	if state == State.WINDUP and not rupture:
		_draw_attack_warning()
	if ice_charge and state == State.STRIKE and not Preferences.values.reduced_motion:
		var drag := smoothstep(90.0, ICE_CHARGE_SPEED, absf(get_real_velocity().x))
		for index in 4:
			var left := _floor_point(position.x - side * (6.0 + index * 14.0), -2.0 - index)
			draw_line(left, left - Vector2(side * (14.0 + drag * 14.0), 0.0),
				Color(ICE_CORE, drag * 0.66), 1.8, true)
	if state == State.STRIKE and attack == Move.STOMP and not rupture and _sweep_started:
		for i in 2:
			if not _wave_blocked[i]:
				var ground := to_local(_wave_at(-1.0 if i == 0 else 1.0)) + Vector2(0, 16)
				_draw_crystals(ground, 44.0, 30.0, ICE)
	for x in _cracks:
		var center := _floor_point(x, -2)
		if _crack_time < CRACK_WARNING:
			var left := _floor_point(x - CRACK_WIDTH * 0.5, -3)
			var right := _floor_point(x + CRACK_WIDTH * 0.5, -3)
			_draw_warning_line(PackedVector2Array([left - Vector2(0, 14), left,
				_floor_point(x - CRACK_WIDTH * 0.25, -11), center,
				_floor_point(x + CRACK_WIDTH * 0.25, -11), right, right - Vector2(0, 14)]),
				_warning_tint(_crack_time, CRACK_WARNING))
		else:
			_draw_crystals(center, CRACK_WIDTH, 52.0, Color(ICE,
				1.0 - smoothstep(CRACK_WARNING + 0.12, CRACK_WARNING + CRACK_DURATION, _crack_time)))


func _draw_attack_warning() -> void:
	var extent: float = [162.0, 229.0, 193.0][attack]
	var tint := _warning_tint(age, 0.6)
	if ice_charge:
		extent = ICE_CHARGE_REACH
		tint = Color(ICE_CORE, tint.a)
	var start := -extent if attack == Move.STOMP else 0.0
	var finish := extent if attack == Move.STOMP else side * extent
	var points := PackedVector2Array()
	for i in 17:
		points.append(_floor_point(position.x + lerpf(start, finish, i / 16.0), -4.0))
	_draw_warning_line(points, tint)
	if attack == Move.STOMP:
		for direction in [-1.0, 1.0]:
			_draw_warning_chevron(_floor_point(position.x + extent * direction, -14.0),
				direction, tint)
	else:
		_draw_warning_chevron(_floor_point(position.x + finish, -14.0), side, tint)
		if attack == Move.CHARGE:
			for fraction in [0.38, 0.69]:
				_draw_warning_chevron(_floor_point(position.x + finish * fraction, -14.0), side, tint)
			if ice_charge:
				var rail := PackedVector2Array()
				for i in 17:
					rail.append(_floor_point(position.x + finish * i / 16.0, -10.0))
				draw_polyline(rail, tint, 1.45, true)


func _warning_tint(elapsed: float, duration: float) -> Color:
	var progress := 1.0 if Preferences.values.reduced_motion else smoothstep(0.0, duration, elapsed)
	return Color(WARNING, lerpf(0.76, 1.0, progress))


func _draw_warning_line(points: PackedVector2Array, tint: Color) -> void:
	draw_polyline(points, WARNING_SHADOW, 8.0, true)
	draw_polyline(points, tint, 3.5, true)


func _draw_warning_chevron(point: Vector2, direction: float, tint: Color) -> void:
	var back := point - Vector2(direction * 12.0, 0)
	_draw_warning_line(PackedVector2Array([back - Vector2(0, 7), point, back + Vector2(0, 7)]), tint)


func _draw_slash() -> void:
	for i in range(1, _slash_tips.size()):
		var outer := to_local(_slash_tips[i])
		var previous := to_local(_slash_tips[i - 1])
		var inner := to_local(_slash_edges[i])
		var old_inner := to_local(_slash_edges[i - 1])
		var fade := float(i) / _slash_tips.size()
		# Separate triangles remain valid as the blade changes direction.
		draw_colored_polygon(PackedVector2Array([previous, outer, inner]), Color(ICE, fade * 0.48))
		draw_colored_polygon(PackedVector2Array([previous, inner, old_inner]), Color(ICE, fade * 0.48))
		draw_line(previous, outer, Color(ICE_CORE, fade * 0.82), 2.6, true)


func _floor_point(x: float, offset: float) -> Vector2:
	return Vector2(x, floor_at.call(x) + offset) - position


func _draw_crystals(center: Vector2, width: float, height: float, tint: Color) -> void:
	for index in 5:
		var x := width * (index - 2) / 5.0
		var foot := center + Vector2(x, 0)
		var tip := foot + Vector2(width * 0.08, -height * (1.0 - absf(index - 2) * 0.23))
		draw_colored_polygon(PackedVector2Array([foot - Vector2(width * 0.1, 0), tip,
			foot + Vector2(width * 0.1, 0)]), Color(tint, tint.a * 0.38))
		var ridge := foot + Vector2(width * 0.023, -height * 0.10)
		draw_colored_polygon(PackedVector2Array([foot - Vector2(width * 0.1, 0), tip,
			ridge]), Color(tint.lightened(0.22), tint.a * 0.57))
		draw_line(tip, ridge, Color(ICE_CORE, tint.a * 0.86), 1.7, true)
