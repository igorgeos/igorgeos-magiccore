extends Node2D

const LENGTH := 53.0
const WARNING_TIME := 0.82

enum State { HANGING, WARNING, FALLING, SHATTERED }

var state := State.HANGING
var floor_y: float
var reduced_motion := false
var _begin_y: float
var _elapsed := 0.0
var _speed := 0.0
var _shard: Sprite2D
var _shape := RectangleShape2D.new()
var _spent := false


func setup(anchor: Vector2, surface: float, art: Texture2D) -> void:
	position = anchor
	_begin_y = anchor.y
	floor_y = surface
	_shard = Sprite2D.new()
	_shard.texture = art
	_shard.centered = false
	_shard.offset.x = -art.get_width() * 0.5
	_shard.scale = Vector2(37, LENGTH) / art.get_size()
	_shard.modulate = Color("#c4d8e6")
	add_child(_shard)


func advance(delta: float, hero: CharacterBody2D, hull: CollisionShape2D) -> bool:
	_elapsed += delta
	match state:
		State.HANGING:
			if absf(hero.position.x - position.x) < 109.0 and hero.position.y > _begin_y + 45.0:
				state = State.WARNING
				_elapsed = 0.0
				queue_redraw()
		State.WARNING:
			if not reduced_motion:
				_shard.position.x = sin(_elapsed * 49.0) * 2.0
			if _elapsed >= WARNING_TIME:
				state = State.FALLING
				_elapsed = 0.0
				_shard.position.x = 0.0
			queue_redraw()
		State.FALLING:
			var previous := position.y
			_speed = minf(1030.0, _speed + delta * 1850.0)
			position.y = minf(floor_y - LENGTH, position.y + delta * _speed)
			var swept := position.y + LENGTH - previous
			_shape.size = Vector2(28.0, swept)
			var hit := not _spent and _shape.collide(Transform2D(0.0, Vector2(position.x, previous + swept * 0.5)),
				hull.shape, hull.global_transform)
			_spent = _spent or hit
			if position.y + LENGTH >= floor_y:
				state = State.SHATTERED
				_shard.hide()
				_elapsed = 0.0
				queue_redraw()
			return hit
		State.SHATTERED:
			pass
	return false


func _draw() -> void:
	if _shard == null:
		return
	if state == State.WARNING or state == State.FALLING:
		var feet := floor_y - position.y
		var fade := smoothstep(0.0, 0.44, _elapsed) if state == State.WARNING else 0.75
		var color := Color(0.90, 0.77, 0.58, 0.42 + fade * 0.47)
		draw_line(Vector2(-17, feet - 2), Vector2(16, feet - 2), color, 2.5, true)
		if not reduced_motion:
			for i in 5:
				var y := LENGTH + fposmod(_elapsed * (72.0 + i * 5.0) + 52.0 * i, maxf(feet - LENGTH, 1.0))
				draw_line(Vector2(i * 3 - 6, y), Vector2(i * 3 - 6, y + 3.0), color, 1.45, true)
