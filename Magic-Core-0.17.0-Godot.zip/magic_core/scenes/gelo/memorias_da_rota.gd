extends Node2D

const Memory := preload("res://scenes/gelo/memoria_do_gelo.gd")

signal opened(definition: Dictionary, source: Node)

var structures: Dictionary[String, Memory] = {}
var _locks: Dictionary[String, Memory] = {}
var _hidden: Dictionary[String, CanvasItem] = {}
var _last_near := ""


func configure(definitions: Array, sites: Dictionary) -> void:
	for definition: Dictionary in definitions:
		var memory := Memory.new()
		memory.configure(definition)
		memory.fractured.connect(_release)
		add_child(memory)
		structures[definition.id] = memory
		var key: String = definition.get("site", "")
		if not key.is_empty():
			_locks[key] = memory
			if definition.get("conceal", false) and sites.has(key):
				var visual: CanvasItem = sites[key].visual
				visual.hide()
				_hidden[key] = visual


func site_available(key: String) -> bool:
	return not _locks.has(key) or _locks[key].broken


func hint_at(feet: Vector2) -> String:
	var key := ""
	var distance := 97.0
	for memory: Memory in structures.values():
		if memory.broken or not memory.spec.has("prompt"):
			continue
		var gap := (feet - memory.position).abs()
		if gap.y <= 44.0 and gap.x < distance:
			key = memory.spec.id
			distance = gap.x
	if key == _last_near:
		return ""
	_last_near = key
	return "" if key.is_empty() else str(structures[key].spec.prompt)


func ground_impact(point: Vector2, radius: float, source: Node) -> int:
	var affected := 0
	for memory: Memory in structures.values():
		affected += int(memory.ground_impact(point, radius, source))
	return affected


func _release(memory: Memory, source: Node) -> void:
	var key: String = memory.spec.get("site", "")
	if _hidden.has(key):
		_hidden[key].show()
		_hidden.erase(key)
	opened.emit(memory.spec, source)
