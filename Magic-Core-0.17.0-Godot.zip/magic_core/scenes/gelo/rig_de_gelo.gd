extends "res://scenes/forest/rig/creature_motion.gd"
# Motion and combat stay on the 2D plane. A small orthographic viewport gives
# the two winter enemies continuous volume and real depth at any heading.
const Body := preload("res://scenes/gelo/corpos_de_gelo.gd")
const PROFILE_ANGLE := 0.19
# Offset to pelvis, spine tilt, near hand, far hand, blade angle from vertical.
const VIGIA_READY := [
	[Vector2(-0.07, 0.08), -0.24, Vector2(-0.28, -0.78), Vector2(0.16, -0.57), -1.39],
	[],
	[Vector2(-0.08, 0.13), -0.24, Vector2(-0.20, -0.49), Vector2(0.18, -0.65), 0.25],
]
const VIGIA_HIT := [
	[Vector2(0.06, 0.055), 0.31, Vector2(0.48, -0.57), Vector2(-0.14, -0.48), 1.92],
	[],
	[Vector2(0.13, 0.11), 0.38, Vector2(0.60, -0.56), Vector2(-0.26, -0.52), 1.39],
]
const COLOSSUS_READY := [
	[Vector2(-0.08, -0.025), -0.28, Vector2(0.04, -1.11), Vector2(0.24, -0.43), 0.0],
	[Vector2(-0.045, -0.055), -0.14, Vector2(0.19, -1.08), Vector2(-0.03, -1.06), 0.0],
	[Vector2(-0.09, 0.09), -0.29, Vector2(-0.34, -0.56), Vector2(0.17, -0.39), 0.0],
]
const COLOSSUS_HIT := [
	[Vector2(0.09, 0.19), 0.53, Vector2(0.54, -0.12), Vector2(-0.14, -0.45), 0.0],
	[Vector2(0.07, 0.25), 0.52, Vector2(0.36, -0.055), Vector2(0.14, -0.06), 0.0],
	[Vector2(0.10, 0.11), 0.37, Vector2(0.57, -0.46), Vector2(-0.26, -0.44), 0.0],
]

var heavy: bool
var model: Body
var _viewport: SubViewport
var _screen: Sprite2D
var _yaw_angle := 0.0
var _yaw_from := 0.0
var _yaw_goal := 0.0
var _turn_progress := 1.0
var _turn_start := 1.0
var _facing := 1.0
var _turn_foot := 13
var _plant := Vector3.ZERO
var _joints := PackedVector3Array()
var _heading := Basis.IDENTITY
var _stance_mix := 0.0
var _cloak_pitch := 0.0
var _torso_twist := 0.0
var _blade_angle := 0.0
var _old_blade_angle := 0.0
var _front_pitch := 0.0
var _far_pitch := 0.0
var _move_side := 1.0
var _reaction := 0.0
var _tilt := 0.0


func setup(body) -> void:
	animal = body
	heavy = body.heavy
	h = body.height
	_facing = body.side
	_yaw_angle = _angle_for(_facing)
	_yaw_goal = _yaw_angle
	pose.resize(24)
	previous.resize(24)
	_joints.resize(24)
	_build_view()
	tick(0.0, 0.0)


func _build_view() -> void:
	var size := 456.0 if heavy else 312.0
	var center := 115.0 if heavy else 76.0
	_viewport = SubViewport.new()
	_viewport.size = Vector2i(320, 320) if heavy else Vector2i(256, 256)
	_viewport.msaa_3d = Viewport.MSAA_2X
	_viewport.transparent_bg = true
	_viewport.own_world_3d = true
	_viewport.gui_disable_input = true
	_viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	add_child(_viewport)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = size
	camera.position = Vector3(0, center, 320)
	camera.far = 625.0
	_viewport.add_child(camera)
	camera.current = true
	model = Body.new()
	_viewport.add_child(model)
	model.build(heavy)
	_screen = Sprite2D.new()
	_screen.texture = _viewport.get_texture()
	_screen.scale = Vector2.ONE * size / float(_viewport.size.x)
	_screen.position.y = -center
	_screen.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	add_child(_screen)


func _angle_for(direction: float) -> float:
	return -PROFILE_ANGLE if direction > 0.0 else -PI + PROFILE_ANGLE


func _turn(dt: float, travel: float) -> void:
	if not is_equal_approx(float(animal.side), _facing):
		_facing = animal.side
		_yaw_from = _yaw_angle
		_yaw_goal = _angle_for(_facing)
		_turn_progress = 0.0
		_turn_start = maxf(0.12, absf(_yaw_goal - _yaw_from) / (PI - PROFILE_ANGLE * 2.0))
		_turn_foot = 13 if _joints[15].y < _joints[19].y else 17
		_plant = _heading * _joints[_turn_foot + 2]
	_turn_progress = minf(1.0, _turn_progress + dt / ((0.36 if heavy else 0.23) * _turn_start))
	_plant.x -= travel
	_yaw_angle = lerpf(_yaw_from, _yaw_goal, smoothstep(0.0, 1.0, _turn_progress))
	_heading = Basis(Vector3.UP, _yaw_angle)
	yaw = cos(_yaw_angle)


func impact(direction: Vector2, force: float) -> void:
	var brace_scale := (0.22 if force < 0.78 else 0.65) if heavy else 1.0
	recoil_speed += Vector2(direction.x * animal.side, -0.22) * minf(force, 1.6) * (h * 0.95) * brace_scale
	_reaction = minf(1.0, force * brace_scale)


func tick(dt: float, travel: float) -> void:
	var first := mode < 0
	if mode != animal.state:
		mode = animal.state
		transition = 0.0
		for i in pose.size():
			previous[i] = pose[i]
		_old_blade_angle = _blade_angle
	transition += dt
	clock = fposmod(clock + dt, 600.0)
	var speed := absf(travel) / maxf(dt, 0.001)
	var sprint := smoothstep(94.0, 142.0, speed) if not heavy else 0.0
	var cycle := 82.0 if heavy else lerpf(63.0, 95.0, sprint)
	var moving := mode in [Mode.PATROL, Mode.PURSUE, Mode.RECOVER, Mode.STRIKE]
	_turn(dt, travel)
	if moving and speed > 5.0:
		_move_side = signf(travel * animal.side)
		phase = fposmod(phase + absf(travel) * absf(yaw) / cycle, 1.0)
	locomotion = move_toward(locomotion, float(moving and speed > 6.0), dt * (4.5 if heavy else 8.5))
	attention = move_toward(attention, float(mode in [Mode.OBSERVE, Mode.ALERT, Mode.PURSUE]), dt * 4.5)
	recoil_speed += (-75.0 * recoil - 14.0 * recoil_speed) * dt
	recoil += recoil_speed * dt
	_reaction = move_toward(_reaction, 0.0, dt * 2.9)
	var t := clampf(float(animal.age) / maxf(animal.age + animal.time, 0.001), 0.0, 1.0)
	var ready_amount := 0.0
	var hit_amount := 0.0
	if mode == Mode.WINDUP:
		ready_amount = smoothstep(0.0, 0.86, t)
	elif mode == Mode.STRIKE:
		var interval := 0.31 if animal.attack == animal.Move.STOMP else 0.69
		hit_amount = smoothstep(0.0, interval, t)
		ready_amount = 1.0 - hit_amount
	elif mode == Mode.RECOVER:
		hit_amount = 1.0 - smoothstep(0.03, 0.90, t)
	var death := smoothstep(0.0, 0.73, t) if mode == Mode.DEAD else 0.0
	_assemble(sprint, cycle, ready_amount, hit_amount, death)
	if not first:
		var blend := smoothstep(0.0, 0.095 if heavy else 0.072, transition)
		for i in pose.size():
			pose[i] = previous[i].lerp(pose[i], blend)
		_blade_angle = lerp_angle(_old_blade_angle, _blade_angle, blend)
	position.x = animal.receiver.offset.x * (0.25 if heavy else 0.78)
	_display(dt, travel, ready_amount, hit_amount, death)
	modulate = Color.WHITE.lerp(Color("#e9c2b4"), minf(animal.receiver.flash * 2.1, 0.31))
	if mode == Mode.DEAD:
		modulate.a = 1.0 - smoothstep(0.78, 1.0, t)


func _assemble(sprint: float, cycle: float, load_amount: float, strike_amount: float, death: float) -> void:
	var beat := phase * TAU
	var weight := sin(beat) * locomotion
	var chest_height := 0.255 * h
	var hip := Vector2(weight * (4.8 if heavy else 2.8),
		-h * (0.49 if heavy else 0.50) + absf(weight) * (6.0 if heavy else 2.2))
	hip.y += sin(clock * (1.3 if heavy else 2.8)) * (1.0 - locomotion) * 1.3
	var tilt := attention * 0.10 + sprint * 0.24 + weight * (0.09 if heavy else 0.045)
	var near := Vector2(0.14 + 0.13 * weight, -0.43 - 0.12 * attention)
	var far := Vector2(-0.03 - 0.115 * weight, -0.44 - 0.08 * attention)
	var blade := 0.54 + attention * 0.63 - 0.31 * weight
	if mode in [Mode.WINDUP, Mode.STRIKE, Mode.RECOVER]:
		var prepared: Array = (COLOSSUS_READY if heavy else VIGIA_READY)[animal.attack]
		var delivered: Array = (COLOSSUS_HIT if heavy else VIGIA_HIT)[animal.attack]
		if not prepared.is_empty():
			hip += (prepared[0] * load_amount + delivered[0] * strike_amount) * h
			tilt += prepared[1] * load_amount + delivered[1] * strike_amount
			near = near.lerp(prepared[2], load_amount / maxf(1.0 - strike_amount, 0.001)).lerp(delivered[2], strike_amount)
			far = far.lerp(prepared[3], load_amount / maxf(1.0 - strike_amount, 0.001)).lerp(delivered[3], strike_amount)
			blade = lerpf(lerpf(blade, prepared[4], load_amount / maxf(1.0 - strike_amount, 0.001)), delivered[4], strike_amount)
	var correction: float = animal.balance_correction * (1.0 - death) if not heavy else 0.0
	hip += Vector2(-0.045 * correction, 0.032 * absf(correction)) * h
	tilt -= correction * 0.19
	far += Vector2(-0.17 * correction, -0.11 * absf(correction))
	hip += recoil * 0.48 + Vector2(-h * 0.20, h * 0.34) * death
	tilt += recoil.x / h * 2.7 - death * (1.18 if heavy else 1.35)
	_tilt = tilt
	var spine := Vector2.UP.rotated(tilt)
	var chest := hip + spine * chest_height + recoil * 0.44
	var reach_width := (0.072 if heavy else 0.030) * h
	var shoulder := chest + spine.orthogonal() * reach_width
	var far_shoulder := chest - spine.orthogonal() * (reach_width * 0.73) + Vector2(0, 3)
	var reaction_spread := _reaction * (0.032 if heavy else 0.14)
	near += Vector2(0.35, -0.28) * reaction_spread
	far -= Vector2(0.25, 0.65) * reaction_spread
	near = near.lerp(Vector2(0.02, -0.075), death)
	far = far.lerp(Vector2(-0.42, -0.07), death)
	pose[0] = hip
	pose[1] = chest
	pose[2] = chest + spine * 0.084 * h
	_arm(5, shoulder, near * h + recoil * 0.6, 0.247 if heavy else 0.19, 0.255 if heavy else 0.17)
	_arm(9, far_shoulder, far * h + recoil * 0.4, 0.205 if heavy else 0.18, 0.22 if heavy else 0.18)
	var gait := locomotion * (1.0 - death) * (1.0 - 0.86 * maxf(load_amount, strike_amount))
	gait *= 1.0 - absf(correction) * 0.78
	var support := 0.71 if heavy else lerpf(0.59, 0.47, sprint)
	var step_a := _step(phase, cycle, support, sprint)
	var step_b := _step(fposmod(phase + 0.5, 1.0), cycle, support, sprint)
	var span := (0.115 if heavy else 0.078 + 0.048 * absf(correction)) * h
	var lunge := strike_amount * (1.0 - strike_amount) * h * (0.10 if heavy else 0.16)
	_leg(13, hip + Vector2(span * 0.42, 0), Vector2(span + lunge + step_a.x * gait + 23 * death, (-10 if heavy else -9) + step_a.y * gait))
	_leg(17, hip - Vector2(span * 0.32, 0), Vector2(-span + step_b.x * gait - 20 * death, (-10 if heavy else -9) + step_b.y * gait))
	_front_pitch = step_a.z * gait - death * 0.40
	_far_pitch = step_b.z * gait + death * 0.28
	_blade_angle = blade + death * 0.84


func _step(progress: float, cycle: float, support: float, sprint: float) -> Vector3:
	var reach := cycle * support * 0.5
	if progress < support:
		return Vector3(_move_side * (reach - cycle * progress), 0.0, 0.0)
	var swing := inverse_lerp(support, 1.0, progress)
	var lift := sin(PI * swing) * (12.0 if heavy else lerpf(13.0, 31.0, sprint))
	return Vector3(_move_side * lerpf(-reach, reach, smoothstep(0.0, 1.0, swing)), -lift,
		_move_side * sin(TAU * swing) * (0.17 if heavy else 0.34))


func _arm(index: int, origin: Vector2, desired: Vector2, upper: float, forearm: float) -> void:
	pose[index] = origin
	pose[index + 2] = origin + (desired - origin).limit_length(h * (upper + forearm - 0.003))


func _leg(index: int, origin: Vector2, ankle: Vector2) -> void:
	pose[index] = origin
	pose[index + 2] = ankle


func _display(dt: float, travel: float, windup: float, strike: float, death: float) -> void:
	var needs_turn := sin(_turn_progress * PI)
	_stance_mix = move_toward(_stance_mix, smoothstep(0.0, 1.0, attention), dt * 5.5)
	var step_weight := sin(phase * TAU) * locomotion
	var torso_target := step_weight * (0.23 if heavy else 0.19) + 0.31 * windup - 0.25 * strike
	if heavy and animal.attack == animal.Move.CHARGE:
		torso_target += 0.53 * windup - 0.48 * strike
	_torso_twist = lerpf(_torso_twist, torso_target, 1.0 - exp(-17.0 * dt))
	var pelvis_twist := -step_weight * 0.13 + windup * 0.13 - strike * 0.14
	var normal := Vector3.UP
	if animal.is_on_floor():
		var floor_normal: Vector2 = animal.get_floor_normal()
		normal = Vector3(floor_normal.x, -floor_normal.y, 0)
	var hip := _point(0) + Vector3(0, -needs_turn * (5.8 if heavy else 3.0), step_weight * (4.2 if heavy else 2.5))
	var ribs := _point(1) + (hip - _point(0))
	var head := _point(2) + (hip - _point(0))
	var neck_top := head + Vector3(0, 3.5, 0)
	model.rotation.y = _yaw_angle
	model.place("hip", hip, Vector3(0, pelvis_twist, -_tilt * 0.52))
	model.place("ribcage", ribs, Vector3(-step_weight * 0.042, _torso_twist, -_tilt))
	model.link("neck", ribs, neck_top)
	model.place("head", head, Vector3(0, _torso_twist * 0.58 - 0.14 * needs_turn * _facing,
		-_tilt * 0.33 + _stance_mix * 0.12 - death * 0.27))

	for limb in 2:
		var depth_side := 1.0 if limb == 0 else -1.0
		var mark := "a" if limb == 0 else "b"
		var arm := 5 + limb * 4
		var leg := 13 + limb * 4
		var shoulder_depth := (35.0 if heavy else 16.0) * depth_side
		var arm_twist := Basis(Vector3.UP, _torso_twist)
		var shoulder := ribs + arm_twist * (_point(arm) - _point(1) + Vector3(0, 0, shoulder_depth))
		var arm_length := (50.0 if limb == 0 else 43.0) if heavy else 27.0
		var forearm_length := (51.0 if limb == 0 else 45.0) if heavy else 25.0
		var arm_depth := shoulder_depth * (1.12 + 0.12 * absf(step_weight))
		if limb == 0:
			arm_depth += windup * (21.0 if heavy else 11.0) - strike * (31.0 if heavy else 15.0)
		var grip := _point(arm + 2) + Vector3(0, 0, arm_depth)
		grip.y = maxf(23.0 if heavy else 10.0, grip.y)
		var available_reach := arm_length + forearm_length - 0.8
		grip = shoulder + (grip - shoulder).limit_length(available_reach)
		var elbow := _joint_between(shoulder, grip, arm_length, forearm_length,
			Vector3(-0.48, -0.68, 0.84 * depth_side))
		model.place("shoulder_" + mark, shoulder, Vector3(step_weight * 0.05 * depth_side,
			_torso_twist, clampf((elbow.x - shoulder.x) * 0.008, -0.42, 0.54)))
		model.link("upper_" + mark, shoulder, elbow)
		model.place("elbow_" + mark, elbow)
		model.link("lower_" + mark, elbow, grip)
		var tip := grip + (grip - elbow).normalized() * (21.0 if heavy else 8.0)
		if not heavy and limb == 0:
			var axis := Vector3(sin(_blade_angle), cos(_blade_angle), 0.24 * windup - 0.30 * strike).normalized()
			tip = grip + axis * 43.0
		model.link("hand_" + mark, grip, grip + (tip - grip).normalized())
		_joints[arm] = shoulder
		_joints[arm + 1] = elbow
		_joints[arm + 2] = grip
		_joints[arm + 3] = tip

		var ankle := _point(leg + 2) + Vector3(needs_turn * 3.0, 0, (23.0 if heavy else 9.0) * depth_side)
		var pitch := _front_pitch if limb == 0 else _far_pitch
		if _turn_progress < 1.0 and death == 0.0:
			if leg == _turn_foot:
				var support := _heading.inverse() * _plant
				# The support remains fixed against the world while the other foot steps.
				ankle.x = lerpf(ankle.x, support.x, needs_turn * 0.90)
				ankle.z = lerpf(ankle.z, support.z, needs_turn * 0.90)
				ankle.y = 10.0 if heavy else 9.0
				pitch = 0.0
			else:
				ankle.y += needs_turn * (17.0 if heavy else 13.0)
				pitch += 0.29 * needs_turn
		ankle.y -= normal.x * ((_heading * ankle).x + position.x) / maxf(normal.y, 0.55)
		var socket := hip + Basis(Vector3.UP, pelvis_twist) * (_point(leg) - _point(0)
			+ Vector3(0, 0, (19.0 if heavy else 9.0) * depth_side))
		var thigh := h * (0.242 if heavy else 0.234)
		var shin := h * (0.250 if heavy else 0.243)
		var knee := _joint_between(socket, ankle, thigh, shin, Vector3(1.0, 0.2, 0.32 * depth_side))
		model.link("thigh_" + mark, socket, knee)
		model.place("knee_" + mark, knee)
		model.link("shin_" + mark, knee, ankle)
		model.place("boot_" + mark, ankle, Vector3(death * 0.11 * depth_side,
			depth_side * 0.07, -pitch + atan2(-normal.x * yaw, normal.y)))
		_joints[leg] = socket
		_joints[leg + 1] = knee
		_joints[leg + 2] = ankle

	var cloth_target := 0.19 * clampf(travel / maxf(dt, 0.001) * yaw / 142.0, -1, 1) + 0.26 * strike
	_cloak_pitch = lerpf(_cloak_pitch, cloth_target, 1.0 - exp(-8.0 * dt))
	var mantle := ribs + Vector3(-15 if heavy else -12, 6, -step_weight * 1.8)
	model.place("mantle", mantle, Vector3(step_weight * 0.08, _torso_twist,
		-_tilt * 0.8 - _cloak_pitch * (0.37 if heavy else 1.0)))
	model.place("hem", mantle + Vector3(-2 - _cloak_pitch * 9, -25.5, 0),
		Vector3(step_weight * 0.10, _torso_twist * 0.8, -_tilt - _cloak_pitch * 1.4 + sin(clock * 4.0) * 0.07))
	pose[8] = Vector2(_joints[8].x, -_joints[8].y)
	pose[12] = Vector2(_joints[12].x, -_joints[12].y)


func _point(index: int) -> Vector3:
	return Vector3(pose[index].x, -pose[index].y, 0)


func _joint_between(origin: Vector3, end: Vector3, first: float, second: float, hint: Vector3) -> Vector3:
	var axis := origin.direction_to(end)
	var distance := maxf(origin.distance_to(end), 0.01)
	# Hip shifts and slope alignment may stretch the chain slightly. The linked
	# shells always meet the same knee and ankle, even on irregular terrain.
	var ratio := maxf(1.0, distance / (first + second - 0.3))
	first *= ratio
	second *= ratio
	var run := (first * first - second * second + distance * distance) / (2.0 * distance)
	var bend := (hint - axis * hint.dot(axis)).normalized()
	return origin + axis * run + bend * sqrt(maxf(0.0, first * first - run * run))


func attack_point(index: int) -> Vector2:
	var model_point := _heading * _joints[index]
	return to_global(Vector2(model_point.x, -model_point.y))
