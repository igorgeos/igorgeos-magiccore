extends RefCounted

const Strike := preload("res://characters/player/sword_strike.gd")
const LINK_BUFFER_SECONDS := 0.075

var current: Strike
var _index := -1
var _elapsed := 0.0
var _pending_index := -1
var _pending_rhythm := 0.0
var _entry_rhythm := 0.0


func request(profiles: Array[Strike]) -> void:
	if _pending_index >= 0:
		return
	if current == null:
		if not profiles.is_empty() and profiles[0] != null:
			_pending_index = 0
	elif _has_next(profiles) and current.chain_close > current.chain_open and _within_buffer():
		_pending_index = _index + 1
		var beat := inverse_lerp(current.chain_open, current.chain_close, progress())
		_pending_rhythm = sin(PI * clampf(beat, 0.0, 1.0))


func link_open(profiles: Array[Strike]) -> bool:
	if not _has_next(profiles):
		return false
	var at := progress()
	return current.chain_close > current.chain_open and at >= current.chain_open and at <= current.chain_close


func _has_next(profiles: Array[Strike]) -> bool:
	return current != null and _pending_index < 0 and _index + 1 < profiles.size() and profiles[_index + 1] != null


func _within_buffer() -> bool:
	var at := progress()
	return at <= current.chain_close and _elapsed + LINK_BUFFER_SECONDS >= current.chain_open * current.duration


func begin_pending(profiles: Array[Strike]) -> bool:
	if current != null or _pending_index < 0:
		return false
	_index = _pending_index
	current = profiles[_index]
	_entry_rhythm = _pending_rhythm
	cancel_pending()
	_elapsed = 0.0
	return true


func progress() -> float:
	return -1.0 if current == null else clampf(_elapsed / current.duration, 0.0, 1.0)


func advance(delta: float, flow_strength := 1.0) -> float:
	if current == null:
		return -1.0
	var recovery_begins := minf(1.0, current.active_end + 0.045) * current.duration
	var tempo := 1.0
	if _elapsed >= recovery_begins:
		tempo += 0.62 * flow_strength * _pending_rhythm
	_elapsed += delta * tempo
	return progress()


func carry() -> float:
	if current == null:
		return 0.0
	var at := progress()
	var entering := _entry_rhythm * (1.0 - smoothstep(0.0, 0.34, at))
	var leaving := _pending_rhythm * smoothstep(current.active_end, minf(1.0, current.active_end + 0.14), at)
	return maxf(entering, leaving)


func finish() -> void:
	current = null
	_index = -1
	_elapsed = 0.0
	_entry_rhythm = 0.0


func cancel_pending() -> void:
	_pending_index = -1
	_pending_rhythm = 0.0
