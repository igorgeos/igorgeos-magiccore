extends RefCounted

const Strike := preload("res://characters/player/sword_strike.gd")
const Adaptive := preload("res://characters/player/adaptive_motion.gd")
const BLADE_LENGTH := 59.5
const GUARD := 5.0
const REACH := 0.23
const CLEAR := 0.74

var hip := Vector2.ZERO
var chest := Vector2.ZERO
var neck := Vector2.ZERO
var head_angle := 0.0
var mantle_angle := 0.0
var tabard_angle := 0.0
var front_hip := Vector2.ZERO
var rear_hip := Vector2.ZERO
var front_knee := Vector2.ZERO
var rear_knee := Vector2.ZERO
var front_ankle := Vector2.ZERO
var rear_ankle := Vector2.ZERO
var front_foot_angle := 0.0
var rear_foot_angle := 0.0
var front_shoulder := Vector2.ZERO
var rear_shoulder := Vector2.ZERO
var front_elbow := Vector2.ZERO
var rear_elbow := Vector2.ZERO
var front_hand := Vector2.ZERO
var rear_hand := Vector2.ZERO
var socket := Vector2.ZERO
var keeper := Vector2.ZERO
var axis := Vector2.DOWN
var mouth := Vector2.ZERO
var grip := Vector2.ZERO
var blade_angle := 0.0
var blade_projection := 1.0
var exposed := 0.0
var closed_hand := 0.0
var hand_brace := 0.0
var terrain_slip := 0.0
var cloak_drag := 0.0
var cloak_lift := 0.0
var hem_wave := 0.0
var body_turn := 0.0
var adaptive := Adaptive.new()
var _time := 0.0
var _phase := 0.05
var _stride := 0.0
var run_blend := 0.0
var _cape_follow := 0.0
var _sheath_swing := 0.0
var _plants := PackedFloat32Array([0.0, 0.0])
var _planted := PackedByteArray([0, 0])
var _turn_front := Vector2.ZERO
var _turn_rear := Vector2.ZERO
var _turn_shift := 0.0
var _turn_foot := -1
var _step_profile: Strike
var _last_attack_phase := -1.0
var _attack_step_planted := false
var _follow_phase := 0.0
var _entry_wrist := Vector2.ZERO
var _entry_angle := 0.0
var _outgoing_weights := Vector4.ZERO
var _body_weights := Vector4.ZERO
var _link_pose := false
var _support_x := 0.0
var _support_height := -6.0
var _attack_step_x := 0.0
var _recoil := Vector2.ZERO
var _guard_ready := 0.0
var _flow_support := 0.0


func advance(delta: float, travel: float, velocity: Vector2, grounded: bool, facing: float,
		gait_length: float, walk_speed: float, weapon: float, attack: float, running := 0.0, intent := 0.0,
		profile: Strike = null, approach := 0.0, balance := 0.0) -> void:
	_time += delta
	adaptive.advance(delta, velocity, grounded, facing, intent, walk_speed)
	var speed := velocity.x * facing
	var speed_ratio := speed / maxf(1.0, walk_speed)
	var travel_local := travel * facing
	if adaptive.turned:
		_turn_foot = 0 if front_ankle.y >= rear_ankle.y else 1
		if not adaptive.hard_turn:
			_turn_foot = -1
		_turn_front = Vector2(-front_ankle.x, front_ankle.y)
		_turn_rear = Vector2(-rear_ankle.x, rear_ankle.y)
		_turn_shift = 0.0
		_planted[0] = 0
		_planted[1] = 0
		cloak_drag *= -0.52
		_cape_follow *= -0.52
		_sheath_swing *= -0.45
	run_blend = lerpf(run_blend, running, 1.0 - exp(-delta * 13.0))
	var cycle := lerpf(gait_length, 150.0, run_blend)
	if grounded:
		_phase = fposmod(_phase + absf(travel) / cycle, 1.0)
	var cut := profile != null
	var entering_cut := cut and (profile != _step_profile or attack < _last_attack_phase)
	if entering_cut:
		_link_pose = _step_profile != null and not adaptive.turned
		_entry_wrist = grip
		_entry_angle = blade_angle
		_outgoing_weights = _body_weights
		_follow_phase = attack
	elif cut:
		# A queued link spends its remaining recovery carrying the follow-through.
		var phase_speed := 1.0 - clampf(balance, 0.0, 1.0) if attack > profile.active_end else 1.0
		_follow_phase += maxf(0.0, attack - _last_attack_phase) * phase_speed
	if entering_cut:
		_support_x = front_ankle.x if not adaptive.turned else -front_ankle.x
		_support_height = front_ankle.y
	var desired_stride := minf(absf(speed_ratio), 1.0) if grounded else 0.0
	if cut:
		desired_stride *= 0.38
	_stride = lerpf(_stride, desired_stride, 1.0 - exp(-delta * (20.0 if desired_stride > _stride else 12.0)))
	_stride *= 1.0 - terrain_slip * delta * 8.0
	var air := adaptive.air_weight
	var land := adaptive.landing
	var pivot := adaptive.turn
	# Guard, approach and the timing of a link contribute to the same adaptive pose.
	var ready_goal := smoothstep(CLEAR, 1.0, weapon) * (1.0 - 0.38 * run_blend - 0.28 * air)
	_guard_ready = lerpf(_guard_ready, ready_goal, 1.0 - exp(-13.0 * delta))
	_flow_support = lerpf(_flow_support, balance, 1.0 - exp(-23.0 * delta))
	var repose := (1.0 - _stride) * (1.0 - air) * float(not cut)
	var breath := sin(_time * 1.85 + 0.14 * sin(_time * 0.37))
	var step := _phase * TAU
	var lean := clampf(speed_ratio, -1.0, 1.3) * 2.9 + run_blend * 4.8
	lean += 3.9 * adaptive.momentum + 2.4 * adaptive.readiness - 3.0 * pivot
	lean += 2.1 * _guard_ready + 3.9 * approach + 2.35 * _flow_support
	_recoil = _recoil.lerp(Vector2.ZERO, 1.0 - exp(-17.0 * delta))
	lean += _recoil.x
	var cut_weights := profile.weights(_follow_phase) if cut else Vector4.ZERO
	if cut and _link_pose and attack < profile.coil_timing.y:
		cut_weights = _outgoing_weights.lerp(cut_weights, smoothstep(0.0, profile.coil_timing.y, attack))
	_body_weights = cut_weights
	var coil := cut_weights.x
	var drive := cut_weights.y
	var rise := cut_weights.z
	var lunge := cut_weights.w
	var turn_goal := -0.22 + 0.12 * sin(step) * _stride + 0.46 * coil - 0.36 * drive
	body_turn = lerpf(body_turn, turn_goal, 1.0 - exp(-delta * 18.0))
	var compression := coil * profile.load_depth if cut else 0.0
	var twist := (drive - coil) * profile.shoulder_turn if cut else 0.0
	# Pelvis leads the rib cage; the shoulder follows as the wrist accelerates.
	var pelvis_drive := profile.weights(minf(1.0, _follow_phase + 0.065)).y if cut else 0.0
	var rib_drive := profile.weights(maxf(0.0, _follow_phase - 0.026)).y if cut else 0.0
	var jump := adaptive.air_pose
	var equip_effort := sin(weapon * PI)
	var weight := sin(step - 0.38) * _stride
	hip = Vector2(-4.3 * coil + 8.0 * pelvis_drive + 2.6 * weight + 0.55 * repose * sin(_time * 0.86)
			+ 2.1 * approach + 2.1 * _flow_support,
		-61.2 + _stride * (2.0 + 1.7 * sin(step * 2.0)) + 8.2 * land + 4.0 * pivot
		+ compression - 3.1 * rise + 1.3 * equip_effort + 2.2 * adaptive.readiness
		+ 1.4 * _guard_ready + 0.65 * _flow_support)
	hip.y += run_blend * (2.1 + 3.4 * cos(2.0 * step - 0.7))
	hip += Vector2(-3.2 * signf(speed_ratio), 4.0) * terrain_slip
	var far_phase := fposmod(_phase + 0.5, 1.0)
	var front := _gait_foot(_phase, cycle)
	var rear := _gait_foot(far_phase, cycle)
	var front_ground := Vector2(-7, -6).lerp(Vector2(front.x, front.y), _stride)
	var rear_ground := Vector2(7, -6).lerp(Vector2(rear.x, rear.y), _stride)
	if grounded and not cut:
		var support := lerpf(minf(0.5, 56.0 / cycle), 0.32, run_blend)
		front_ground.x = _ground_x(0, front_ground.x, _phase, support, travel_local)
		rear_ground.x = _ground_x(1, rear_ground.x, far_phase, support, travel_local)
		if _turn_foot >= 0:
			_turn_shift += travel_local
			var turn := adaptive.turn_progress
			front_ground = _turn_step(front_ground, _turn_front, _turn_foot == 0, turn)
			rear_ground = _turn_step(rear_ground, _turn_rear, _turn_foot == 1, turn)
			if turn >= 1.0:
				_turn_foot = -1
	else:
		_planted[0] = 0
		_planted[1] = 0
		_turn_foot = -1
	var guard_stance := _guard_ready * (1.0 - _stride) * (1.0 - air)
	front_ground.x -= 2.8 * guard_stance
	rear_ground.x += 2.8 * guard_stance
	front_foot_angle = front.z * _stride
	rear_foot_angle = rear.z * _stride
	var near_air := Vector2(7 + 13 * jump.x + 3 * jump.z, -8 - 22 * jump.y - 2 * jump.z)
	var far_air := Vector2(-9 - 13 * jump.x, -7 - 15 * jump.y - 4 * jump.z)
	var ground_mix := air if not grounded else air * 0.37
	front_ankle = front_ground.lerp(near_air, ground_mix)
	rear_ankle = rear_ground.lerp(far_air, ground_mix)
	front_foot_angle += air * (0.16 + 0.28 * jump.y - 0.18 * jump.z)
	rear_foot_angle += air * (0.34 + 0.14 * jump.y - 0.27 * jump.z)
	# Transfer the weight onto the forward step while keeping the common ground and air poses.
	rear_ankle.x += lunge * (profile.step_reach + approach * 4.0) if cut else 0.0
	rear_ankle.y -= 18.0 * lunge * (1.0 - lunge) + 8.0 * drive * air
	front_ankle.x -= 7.0 * drive
	front_ankle.y -= 2.0 * rise
	front_foot_angle += 0.22 * rise
	if cut and grounded:
		_support_x -= travel_local
		var unweight := smoothstep(profile.step_timing.y, profile.step_timing.z, attack)
		front_ankle.x = lerpf(clampf(_support_x, hip.x - 32.0, hip.x + 30.0), front_ankle.x, unweight)
		front_ankle.y = lerpf(lerpf(_support_height, -6.3, smoothstep(0.0, 0.21, attack)), front_ankle.y, unweight)
	_plant_attack_step(profile, attack, grounded, travel_local)
	if grounded:
		front_ankle.y = _sole_height(front_ankle.y, front_foot_angle)
		rear_ankle.y = _sole_height(rear_ankle.y, rear_foot_angle)
		var near_reach := clampf(front_ankle.x - (hip.x - 2.0), -47.0, 47.0)
		var far_reach := clampf(rear_ankle.x - (hip.x + 2.0), -47.0, 47.0)
		hip.y = maxf(hip.y, front_ankle.y - sqrt(56.0 * 56.0 - near_reach * near_reach) - 1.0)
		hip.y = maxf(hip.y, rear_ankle.y - sqrt(56.0 * 56.0 - far_reach * far_reach))
		# Limit the crouch with a full-length scabbard at the belt, including a hard running landing.
		hip.y = minf(hip.y, -53.5)
	chest = hip + Vector2(lean - weight * 1.7 + 2.4 * coil + 7.4 * rib_drive - 5.0 * rise + air * (2.8 * jump.y + 3.0 * jump.x),
		-23.5 - (0.45 + 0.45 * repose) * breath + 1.4 * land + 3.4 * coil - 2.3 * rise + _recoil.y)
	neck = chest + Vector2(1.0 + 0.52 * lean, -7.8 + 0.65 * coil)
	head_angle = -0.018 * breath + 0.028 * weight + 0.075 * land - 0.06 * coil - 0.10 * pivot
	head_angle += 0.05 * air * (jump.z - jump.y)
	front_hip = hip + Vector2(-2, 1)
	rear_hip = hip + Vector2(2, 0)
	front_knee = _joint(front_hip, front_ankle, 28.0, 28.5, 1.0)
	rear_knee = _joint(rear_hip, rear_ankle, 28.0, 28.5, 1.0)
	front_shoulder = chest + Vector2(-2.4 + twist, -3.0 - 0.55 * repose * breath + weight * 0.45)
	rear_shoulder = chest + Vector2(2.9 - twist * 0.54, -4.2 - 0.39 * repose * breath - weight * 0.50)
	front_shoulder.y -= 1.7 * drive + 1.1 * maxf(rise, 0.0)
	var swing := cos(step) * _stride
	rear_hand = rear_shoulder + Vector2(5.0 + 14.0 * swing - 8.0 * drive, 31.2 - 5.8 * absf(swing))
	rear_hand += Vector2(5.0 + 4.0 * swing, -11.0 - 3.8 * swing) * run_blend
	rear_hand += Vector2(-5.0 + 17.0 * jump.y - 7.0 * jump.x, -6.0 - 13.0 * jump.y - 3.0 * jump.z) * air
	rear_hand += Vector2(8.0, -8.0) * pivot + Vector2(5.0, -5.0) * land
	rear_hand += Vector2(9, -16) * coil + Vector2(-15, -8) * rise
	rear_hand += Vector2(-2.3, -3.5) * (_guard_ready + _flow_support)
	rear_hand = rear_shoulder + (rear_hand - rear_shoulder).limit_length(33.6)
	rear_elbow = _joint(rear_shoulder, rear_hand, 16.5, 17.4, -1.0)
	_weapon_pose(swing, equip_effort, weapon, attack, profile, coil, jump, delta)
	_fabric(delta, speed, velocity.y, drive, rise, land, breath)


func recoil(direction: Vector2, strength: float) -> void:
	_recoil = Vector2(-3.0 * direction.x, -1.9 * direction.y) * minf(strength, 1.35)


func _plant_attack_step(profile: Strike, phase: float, grounded: bool, travel: float) -> void:
	if profile != _step_profile or phase < _last_attack_phase or not grounded:
		_attack_step_planted = false
	_step_profile = profile
	_last_attack_phase = phase
	if profile == null or not grounded or phase < profile.step_timing.y or phase >= 1.0:
		return
	if _attack_step_planted:
		_attack_step_x -= travel
	else:
		_attack_step_planted = true
		_attack_step_x = rear_ankle.x
	var release := smoothstep(profile.step_timing.z, 1.0, phase)
	var anchored := clampf(_attack_step_x, rear_ankle.x - 18.0, rear_ankle.x + 18.0)
	rear_ankle.x = lerpf(anchored, rear_ankle.x, release)
	rear_ankle.y -= 6.0 * sin(PI * release)


func _weapon_pose(swing: float, effort: float, weapon: float, attack: float, profile: Strike,
		coil: float, jump: Vector3, delta: float) -> void:
	var waist := (chest - hip).normalized()
	socket = hip + waist * 5.0 + Vector2(-waist.y, waist.x) * 1.7
	var thigh := front_hip.lerp(front_knee, 0.52) + Vector2(-1.2, 0.0)
	var swing_target := -0.068 * adaptive.momentum + 0.023 * swing + 0.04 * adaptive.landing + 0.035 * coil - 0.018 * _flow_support
	_sheath_swing = lerpf(_sheath_swing, swing_target, 1.0 - exp(-delta * 18.0))
	axis = socket.direction_to(thigh).rotated(clampf(_sheath_swing, -0.066, 0.066))
	keeper = socket + axis * (thigh - socket).dot(axis)
	mouth = socket - axis * 2.4
	var free := front_shoulder + Vector2(0.5 - 14 * swing, 32.7 - 5.5 * absf(swing))
	free += Vector2(5.0 - 4.0 * swing, -11.0 + 4.0 * swing) * run_blend
	free += Vector2(12.0 - 19.0 * jump.y + 5.0 * jump.x, -8.0 - 8.0 * jump.y - 2.0 * jump.z) * adaptive.air_weight
	hand_brace = smoothstep(0.12, 0.56, adaptive.brace) * (1.0 - smoothstep(0.0, REACH, weapon))
	free = free.lerp(mouth + axis * 1.8 + axis.orthogonal() * 3.0, hand_brace)
	var guard := front_shoulder + Vector2(12 + 2.0 * swing, 19.0 + 1.5 * swing) + Vector2(2.0, -3.0) * run_blend
	guard += Vector2(2.6, -3.1) * _guard_ready + Vector2(2.4, -1.8) * _flow_support
	var ready_angle := -49.0 + swing * 3.0 - 7.0 * _guard_ready
	exposed = (BLADE_LENGTH - GUARD) * smoothstep(REACH, CLEAR, weapon)
	var home := mouth - axis * (GUARD + exposed)
	var present := smoothstep(CLEAR, 1.0, weapon)
	var lift_out := home.lerp(guard, 0.27) + Vector2(12.0, -1.0)
	var descend_to_guard := home.lerp(guard, 0.73) + Vector2(10.0, -6.0)
	grip = home.bezier_interpolate(lift_out, descend_to_guard, guard, present)
	blade_angle = axis.angle() + wrapf(deg_to_rad(ready_angle) - axis.angle(), -PI, PI) * present
	var touch_grip := smoothstep(0.0, REACH, weapon)
	var reach_path := free.bezier_interpolate(free + Vector2(8.0, 1.0), grip + Vector2(5.0, 2.0), grip, touch_grip)
	front_hand = reach_path
	closed_hand = smoothstep(0.15, REACH, weapon)
	blade_projection = 1.0
	if profile != null:
		var strike := profile.wrist(_follow_phase)
		var blend := smoothstep(0.0, 0.12, attack) * (1.0 - smoothstep(0.86, 1.0, _follow_phase))
		grip = guard.lerp(front_shoulder + Vector2(strike.x, strike.y), blend)
		blade_angle = deg_to_rad(lerpf(ready_angle, strike.z, blend))
		if _link_pose and attack < profile.coil_timing.y:
			var incoming := smoothstep(0.0, profile.coil_timing.y, attack)
			grip = _entry_wrist.lerp(grip, incoming)
			blade_angle = lerp_angle(_entry_angle, blade_angle, incoming)
		blade_projection -= profile.blade_foreshortening * coil
		front_hand = grip
	# The lifting shoulder travels with the grip during the long part of the draw.
	var reach := front_shoulder.direction_to(front_hand)
	var extension := minf(maxf(front_shoulder.distance_to(front_hand) - 33.4, 0.0), 7.0)
	front_shoulder += reach * extension * maxf(effort, float(profile != null))
	front_elbow = _joint(front_shoulder, front_hand, 17.0, 18.0, -1.0)


func _fabric(delta: float, speed: float, vertical: float, drive: float, rise: float, land: float, breath: float) -> void:
	var airflow := -clampf(speed * 0.082, -14.0, 22.0)
	var target := airflow - adaptive.air_weight * 3.4 - drive * 9.0 - adaptive.momentum * 4.3
	# Two damped stages keep the collar fixed while the hem catches up.
	_cape_follow = lerpf(_cape_follow, target, 1.0 - exp(-delta * 14.0))
	cloak_drag = lerpf(cloak_drag, _cape_follow, 1.0 - exp(-delta * 11.0))
	var sail := clampf((cloak_drag - _cape_follow) * 0.30, -5.0, 5.0)
	var lift := -clampf(vertical * 0.022, -5.0, 11.0) - absf(cloak_drag) * 0.37 - rise * 10.0 - land * 3.0
	cloak_lift = lerpf(cloak_lift, lift, 1.0 - exp(-delta * 13.0))
	hem_wave = 0.68 * sin(_time * 2.7) + _stride * 1.4 * sin(_phase * TAU - 0.8) + sail
	mantle_angle = -cloak_drag * 0.003 + 0.014 * breath - 0.024 * adaptive.momentum
	tabard_angle = 0.07 - cloak_drag * 0.012 - hem_wave * 0.038 + land * 0.075


func _ground_x(index: int, goal: float, phase: float, support: float, travel: float) -> float:
	if phase >= support or _stride < 0.13:
		_planted[index] = 0
		return goal
	if _planted[index] == 0:
		_plants[index] = goal
		_planted[index] = 1
	else:
		_plants[index] = clampf(_plants[index] - travel, goal - 14.0, goal + 14.0)
	var release := smoothstep(support - 0.07, support, phase)
	release = maxf(release, 1.0 - smoothstep(0.13, 0.44, _stride))
	return lerpf(_plants[index], goal, release)


func _turn_step(goal: Vector2, old: Vector2, supported: bool, progress: float) -> Vector2:
	var carry := old - Vector2(_turn_shift, 0.0)
	carry.x = clampf(carry.x, -39.0, 39.0)
	var recovery := smoothstep(0.34 if supported else 0.0, 1.0, progress)
	var step := carry.lerp(goal, recovery)
	if not supported:
		step.y -= 9.0 * sin(PI * progress)
	return step


func _sole_height(height: float, angle: float) -> float:
	var heel := Vector2(-4.6, 5.4).rotated(angle).y
	var toe := Vector2(13.5, 4.8).rotated(angle).y
	return minf(height, -maxf(heel, toe) - 0.75)


func _gait_foot(phase: float, cycle: float) -> Vector3:
	var walk := _foot(phase, cycle)
	if run_blend < 0.001:
		return walk
	const CONTACT := 0.32
	var reach := cycle * CONTACT * 0.5
	var running: Vector3
	if phase < CONTACT:
		var stance := phase / CONTACT
		running = Vector3(reach - phase * cycle, -6.0 - 5.0 * smoothstep(0.72, 1.0, stance),
			lerpf(-0.19, 0.43, smoothstep(0.23, 1.0, stance)))
	else:
		var t := (phase - CONTACT) / (1.0 - CONTACT)
		var stride := lerpf(-reach, reach, smoothstep(0.0, 1.0, t))
		stride -= cycle * (1.0 - CONTACT) * t * (1.0 - t) * (1.0 - 2.0 * t)
		var lift := pow(sin(t * PI), 1.25) * (24.5 - 8.5 * t)
		running = Vector3(stride, -6.0 - 5.0 * (1.0 - t) - lift,
			lerpf(0.43, -0.19, smoothstep(0.30, 0.88, t)) + 0.42 * sin(t * PI))
	return walk.lerp(running, run_blend)


func _foot(phase: float, stride_length: float) -> Vector3:
	var support := minf(0.5, 56.0 / stride_length)
	var reach := stride_length * support * 0.5
	if phase < support:
		var u := phase / support
		var roll := -0.14 * (1.0 - smoothstep(0.0, 0.25, u)) + 0.28 * smoothstep(0.75, 1.0, u)
		return Vector3(reach - phase * stride_length, -6.0 - 3.0 * smoothstep(0.78, 1.0, u), roll)
	var t := (phase - support) / (1.0 - support)
	var x := lerpf(-reach, reach, t * t * (3.0 - 2.0 * t)) - minf(stride_length * (1.0 - support), 65.0) * t * (1.0 - t) * (1.0 - 2.0 * t)
	return Vector3(x, -6.0 - lerpf(3.0, 0.0, t) - 11.5 * pow(sin(t * PI), 1.35),
		lerpf(0.28, -0.14, smoothstep(0.15, 0.88, t)) + 0.17 * sin(t * PI))


# The two-bone solution keeps heels planted and sleeves touching the moving wrist.
func _joint(base: Vector2, end: Vector2, first: float, second: float, bend: float) -> Vector2:
	var toward := base.direction_to(end)
	var length := clampf(base.distance_to(end), absf(first - second) + 0.01, first + second - 0.01)
	var along := (first * first - second * second + length * length) / (2.0 * length)
	return base + toward * along + Vector2(toward.y, -toward.x) * sqrt(maxf(0.0, first * first - along * along)) * bend


