extends RefCounted

class Contact:
	var point: Vector2
	var direction: Vector2
	var strength: float
	var expires: float

const WAKE_TIME := 0.104
const WAKE_LENGTH := 61.0
const CAPACITY := 28
const MARK_TIME := 0.105
const STEEL_BLUE := Color("#86b0cc")
const CONTACT_BLUE := Color("#b6cdde")

var _locations := PackedVector2Array()
var _inner_edge := PackedVector2Array()
var _birth := PackedFloat64Array()
var _groups := PackedInt32Array()
var _head := 0
var _count := 0
var _swing := 0
var _time := 0.0
var _contacts: Array[Contact] = []


func _init() -> void:
	_locations.resize(CAPACITY)
	_inner_edge.resize(CAPACITY)
	_birth.resize(CAPACITY)
	_groups.resize(CAPACITY)


func advance(delta: float) -> void:
	_time += delta
	while _count > 0 and _time - _birth[_head] >= WAKE_TIME:
		_head = (_head + 1) % CAPACITY
		_count -= 1
	while not _contacts.is_empty() and _contacts[0].expires <= _time:
		_contacts.pop_front()


func begin_swing() -> void:
	_swing += 1


func blade(grip: Vector2, tip: Vector2, age: float) -> void:
	var index := (_head + _count) % CAPACITY
	_locations[index] = tip
	_inner_edge[index] = grip.lerp(tip, 0.71)
	_birth[index] = _time - age
	_groups[index] = _swing
	if _count == CAPACITY:
		_head = (_head + 1) % CAPACITY
	else:
		_count += 1


func hit(point: Vector2, direction: Vector2, strength: float) -> void:
	var contact := Contact.new()
	contact.point = point
	contact.direction = direction
	contact.strength = strength
	contact.expires = _time + MARK_TIME
	_contacts.append(contact)


func draw_wake(canvas: Node2D, reduced: bool) -> void:
	canvas.draw_set_transform(Vector2.ZERO)
	if _count < 2:
		return
	var to_local := canvas.global_transform.affine_inverse()
	var length_left := WAKE_LENGTH
	for i in range(_count - 1, 0, -1):
		var newest := (_head + i) % CAPACITY
		var prior := (_head + i - 1) % CAPACITY
		if _groups[prior] != _groups[newest]:
			continue
		var from := _locations[newest]
		var to := _locations[prior]
		var length := from.distance_to(to)
		if length < 0.10:
			continue
		var fade := clampf(1.0 - (_time - _birth[prior]) / WAKE_TIME, 0.0, 1.0)
		var fraction := minf(1.0, length_left / length)
		var outer_start := to_local * from
		var outer_end := to_local * from.lerp(to, fraction)
		var thickness := lerpf(0.7, 2.1, fade) * (0.58 if reduced else 1.0)
		if not reduced:
			var inner_start := to_local * from.lerp(_inner_edge[newest], fade)
			var inner_end := to_local * from.lerp(to, fraction).lerp(
				_inner_edge[newest].lerp(_inner_edge[prior], fraction), fade)
			_wake_triangle(canvas, outer_start, outer_end, inner_start, fade)
			_wake_triangle(canvas, outer_end, inner_end, inner_start, fade)
		canvas.draw_line(outer_start, outer_end, Color(CONTACT_BLUE, fade * fade * (0.34 if reduced else 0.68)),
			thickness, true)
		length_left -= length
		if length_left <= 0.0:
			break


func _wake_triangle(canvas: Node2D, outer: Vector2, end: Vector2, inner: Vector2, fade: float) -> void:
	if absf((end - outer).cross(inner - outer)) > 0.12:
		canvas.draw_colored_polygon(PackedVector2Array([outer, end, inner]), Color(STEEL_BLUE, 0.26 * fade * fade))


func draw_impacts(canvas: Node2D, reduced: bool) -> void:
	canvas.draw_set_transform(Vector2.ZERO)
	if _contacts.is_empty():
		return
	var to_local := canvas.global_transform.affine_inverse()
	for contact in _contacts:
		var life := clampf((contact.expires - _time) / MARK_TIME, 0.0, 1.0)
		var center := to_local * contact.point
		var axis := to_local.basis_xform(contact.direction).normalized()
		var force := minf(1.0, contact.strength)
		var mark := axis * lerpf(3.0, 7.8, force)
		canvas.draw_line(center - mark * 0.28, center + mark, Color(CONTACT_BLUE, life * (0.44 if reduced else 0.82)),
			lerpf(1.05, 1.95, force), true)
		if not reduced:
			var side := mark.orthogonal() * (1.0 - 0.30 * life)
			canvas.draw_line(center + side, center + side + mark * 0.45, Color(STEEL_BLUE, life * 0.56), 1.25, true)
