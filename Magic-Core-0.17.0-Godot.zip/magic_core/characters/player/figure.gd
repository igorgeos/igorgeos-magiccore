extends Node2D

const Motion := preload("res://characters/player/motion.gd")
const Strike := preload("res://characters/player/sword_strike.gd")
const Trace := preload("res://characters/player/strike_trace.gd")
const Model := preload("res://characters/player/model.gd")

var pose := Motion.new()
var _trace := Trace.new()
var _model := Model.new()
var _facing := 1.0

@onready var _waist: Marker2D = $Cintura
@onready var _grip: Marker2D = $Empunhadura


func _ready() -> void:
	_model.attach(self)
	pose.advance(0, 0, Vector2.ZERO, true, 1, 112, 140, 0, -1)
	_sync_anchors()


func advance(delta: float, travel: float, velocity: Vector2, grounded: bool, facing: float,
		gait_length: float, walk_speed: float, weapon: float, attack: float, running: float,
		intent: float, profile: Strike, approach: float, balance: float) -> void:
	if facing != _facing:
		_facing = facing
		transform = Transform2D(Vector2(_facing, 0.0), Vector2.DOWN, Vector2.ZERO)
		reset_physics_interpolation()
	pose.advance(delta, travel, velocity, grounded, facing, gait_length, walk_speed, weapon,
		attack, running, intent, profile, approach, balance)
	_sync_anchors()
	advance_trace(delta)


func _sync_anchors() -> void:
	_waist.position = pose.socket
	_waist.rotation = pose.axis.angle()
	_grip.position = pose.grip
	_grip.rotation = pose.blade_angle
	_model.apply_pose(pose)


func blade_tip() -> Vector2:
	var length := Motion.GUARD + pose.exposed * pose.blade_projection
	return pose.grip + Vector2.from_angle(pose.blade_angle) * length


func begin_strike_trace() -> void:
	_trace.begin_swing()


func trace_blade(grip: Vector2, tip: Vector2, age: float) -> void:
	_trace.blade(grip, tip, age)


func trace_impact(point: Vector2, direction: Vector2, strength: float) -> void:
	_trace.hit(point, direction, strength)


func advance_trace(delta: float) -> void:
	_trace.advance(delta)
	queue_redraw()


func recoil(direction: Vector2, strength: float) -> void:
	pose.recoil(direction, strength)


func _draw() -> void:
	_trace.draw_wake(self, Preferences.values.reduced_motion)
	_trace.draw_impacts(self, Preferences.values.reduced_motion)
