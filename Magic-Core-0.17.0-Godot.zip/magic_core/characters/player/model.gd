extends Node3D

const Asset := preload("res://characters/player/andarilho.glb")
const Motion := preload("res://characters/player/motion.gd")
const VIEW_SIZE := 206.0
const VIEW_CENTER := 62.0
const VIEW_RESOLUTION := 352

var _parts: Dictionary[String, Node3D] = {}
var _fabric: MeshInstance3D


func attach(figure: Node2D) -> void:
	var view := SubViewport.new()
	view.size = Vector2i(VIEW_RESOLUTION, VIEW_RESOLUTION)
	view.transparent_bg = true
	view.msaa_3d = Viewport.MSAA_2X
	view.own_world_3d = true
	view.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	view.gui_disable_input = true
	figure.add_child(view)
	view.add_child(self)

	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = VIEW_SIZE
	camera.position = Vector3(0.0, VIEW_CENTER, 225.0)
	camera.far = 400.0
	view.add_child(camera)
	camera.current = true

	var world_light := WorldEnvironment.new()
	world_light.environment = Environment.new()
	world_light.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world_light.environment.ambient_light_color = Color("#c7d3dd")
	world_light.environment.ambient_light_energy = 0.64
	view.add_child(world_light)
	_light(view, Color("#fff1d6"), 1.68, Vector3(-0.4, -0.64, -0.7))
	_light(view, Color("#9bcbdc"), 0.85, Vector3(0.53, -0.43, 0.65))

	var model := Asset.instantiate()
	add_child(model)
	for name in ["torso", "head", "mantle", "cape", "sheath", "sword", "blade"]:
		_parts[name] = model.find_child(name, true, false) as Node3D
	for side in ["near", "far"]:
		for segment in ["upper", "fore", "hand", "thigh", "shin", "boot"]:
			var name := "%s_%s" % [segment, side]
			_parts[name] = model.find_child(name, true, false) as Node3D
	_fabric = _parts["cape"].get_child(0) as MeshInstance3D
	assert(_fabric.get_blend_shape_count() == 2)

	var canvas := Sprite2D.new()
	canvas.texture = view.get_texture()
	canvas.position.y = -VIEW_CENTER
	canvas.scale = Vector2.ONE * VIEW_SIZE / VIEW_RESOLUTION
	canvas.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	canvas.show_behind_parent = true
	figure.add_child(canvas)


func apply_pose(pose: Motion) -> void:
	var torso_angle := (pose.neck - pose.hip).angle() + PI * 0.5
	var yaw := pose.body_turn
	_place("torso", pose.hip, 0, torso_angle, yaw)
	_place("head", pose.neck, 1.5, torso_angle * 0.35 + pose.head_angle, yaw * 0.75 - 0.23)
	_place("mantle", pose.neck + Vector2(0, 2), 0, torso_angle + pose.mantle_angle, yaw)
	_place("cape", pose.neck + Vector2(0, 3), -1, torso_angle * 0.5, yaw * 0.4)
	_fabric.set_blend_shape_value(0, clampf((-pose.cloak_drag - pose.cloak_lift * 0.5) / 28.0, -0.35, 1.0))
	_fabric.set_blend_shape_value(1, clampf(pose.hem_wave / 3.5, -1.0, 1.0))

	_leg("near", pose.front_hip, pose.front_knee, pose.front_ankle, pose.front_foot_angle, 6.2)
	_leg("far", pose.rear_hip, pose.rear_knee, pose.rear_ankle, pose.rear_foot_angle, -6.2)
	var shoulder_depth := cos(yaw) * 11.5
	_arm("near", pose.front_shoulder, pose.front_elbow, pose.front_hand, shoulder_depth)
	_arm("far", pose.rear_shoulder, pose.rear_elbow, pose.rear_hand, -shoulder_depth)

	_place("sheath", pose.mouth, 9.0, pose.axis.angle() - PI * 0.5)
	var sword_depth := lerpf(9.0, shoulder_depth + 2.1, pose.closed_hand)
	_place("sword", pose.grip, sword_depth, pose.blade_angle - PI * 0.5)
	var exposed := pose.exposed * pose.blade_projection
	_parts["blade"].visible = exposed > 0.15
	_parts["blade"].scale.y = maxf(exposed / (Motion.BLADE_LENGTH - Motion.GUARD), 0.003)


func _leg(side: String, hip: Vector2, knee: Vector2, ankle: Vector2, angle: float, depth: float) -> void:
	_segment("thigh_" + side, hip, knee, depth, 28.0)
	_segment("shin_" + side, knee, ankle, depth, 28.5)
	_place("boot_" + side, ankle, depth, angle, -0.13)


func _arm(side: String, shoulder: Vector2, elbow: Vector2, wrist: Vector2, depth: float) -> void:
	_segment("upper_" + side, shoulder, elbow, depth, 16.75)
	_segment("fore_" + side, elbow, wrist, depth, 17.7)
	_place("hand_" + side, wrist, depth, (wrist - elbow).angle() - PI * 0.5)


func _segment(name: String, start: Vector2, finish: Vector2, depth: float, length: float) -> void:
	var direction := finish - start
	_place(name, start, depth, direction.angle() - PI * 0.5)
	_parts[name].scale.y = maxf(0.01, direction.length() / length)


func _place(name: String, point: Vector2, depth: float, angle: float, yaw := 0.0) -> void:
	var part := _parts[name]
	part.position = Vector3(point.x, -point.y, depth)
	part.rotation = Vector3(0, yaw, -angle)


func _light(view: SubViewport, tint: Color, energy: float, direction: Vector3) -> void:
	var light := DirectionalLight3D.new()
	light.light_color = tint
	light.light_energy = energy
	view.add_child(light)
	light.look_at(direction)
