# MAGIC CORE · 0.17.1

Projeto Godot 4.7 de um RPG 2D Dark Fantasy. Derrote o Guardião do Véu para abrir as Terras Congeladas e jogar Passagem da Geada, Abismo Branco e Fortaleza do Inverno.

## Terras Congeladas · Memória do Gelo

Golpeie as estruturas de gelo com a espada. Cada impacto válido aumenta as rachaduras até o rompimento. O rompimento abre espaço, libera mecanismos ou revela uma interação de abrigo, conforme a estrutura. Os impactos necessários são configurados por estrutura em `scenes/gelo/percursos.gd`.

Neve e rocha congelada mantêm o apoio firme. O gelo liso prolonga a frenagem e o gelo frágil cede sob certas condições. Os efeitos de neve, vento e estilhaços acompanham a região. O modo **Reduzir movimento** diminui a animação ambiental.

Na primeira conclusão de cada travessia, o jogo salva e carrega a próxima fase após cinco segundos. É possível avançar imediatamente ou voltar ao mapa na tela de vitória. A vitória na Fortaleza registra o selo que desbloqueia o Reino Vulcânico.

## Abrir no Galaxy A36

1. Extraia o ZIP em uma pasta própria.
2. No gerenciador de projetos do Godot, toque em **Importar** e selecione `magic_core/project.godot`.
3. Abra o projeto e execute a cena principal.

## Navegar

Arraste para os lados para girar o carrossel. Toque em um selo lateral para trazê-lo à frente ou toque no selo central para abri-lo. No computador, você também pode usar as setas e Enter.

O selo central recebe um brilho azul. O giro e a confirmação têm sons próprios, ajustados pelo volume de efeitos. A opção **Reduzir movimento** torna as transições imediatas e mantém o destaque da seleção.

- **Jogar** abre o Atlas Ancestral. Selecione **Floresta Sombria → Explorar ilha → Entrada da Mata** para começar. O botão **Treino** no atlas abre a sala de teste. Abra **Armas** e toque em **Espada** para sacar a Espada do Vigia. Abra a roda novamente e escolha **Guardar** para embainhar. Use **Atacar** com a espada em mãos. No direcional de duas pontas, segure uma seta para se mover. Toque em **Correr** para alternar a corrida, inclusive durante a caminhada. No teclado, segure **Shift** com a direção. No computador, **Q** abre a roda, as setas selecionam, **Enter** confirma e **J** ataca. O alvo de treino reaparece após três acertos.
- **Novo jogo** abre o prólogo *O Núcleo Desperta*. Toque em **Iniciar campanha** e escolha um dos três slots. O jogo salva ao começar e ao chegar a cada novo trecho. Substituir um slot exige confirmação.
- **Continuar** aparece no menu quando há arquivos de progresso. A lista mostra o capítulo, o trecho e o horário da última gravação. Selecione uma partida para retornar ao ponto salvo.
- **Configurações** tem abas de áudio, gráficos, controles e acessibilidade. Ajuste trilha, navegação e confirmação separadamente. Há opções de FPS, brilho mágico, luminosidade, arrasto e sensibilidade, vibração, atalhos de teclado, texto maior, contraste e movimento reduzido. Toque em **Salvar e voltar** para aplicar e guardar as escolhas.
- **Créditos** reúne equipe, arte, trilha, efeitos e versão.
- **Sair** pede confirmação e fecha o aplicativo.

Em **Configurações → Acessibilidade**, **Tamanho do HUD** ajusta os botões, o retrato e a roda de armas de 100% a 150%. O tamanho se adapta ao espaço disponível em telas mais estreitas. Escolha **Salvar e voltar** para usar o ajuste.

## Combate Ancestral 1.0

Com a espada empunhada, toque em **Atacar** e volte a tocar quando o arco ao redor do botão ficar dourado. Cada janela aceita um toque para preparar o golpe seguinte. O Andarilho executa **corte horizontal → corte ascendente → corte descendente**. Depois do terceiro golpe, um novo toque inicia pelo horizontal. Para interromper a sequência, deixe a janela passar ou pressione **Armas**. A roda abre assim que o golpe atual termina.

| Golpe | Duração | Janela para encadear |
|---|---:|---|
| Horizontal | 0,38 s | 54% a 98% |
| Ascendente | 0,46 s | 60% a 98% |
| Descendente | 0,65 s | Finaliza a sequência |

Os três golpes usam a pose articulada do Andarilho. O horizontal projeta o ombro e gira o tronco, o ascendente usa a extensão das pernas e o descendente concentra o peso no passo e termina agachado. Cada golpe pode tirar um ponto do mesmo alvo.

A **Ressonância Ancestral** usa o contato da lâmina para definir recuo, elevação, compressão e uma micropausa local. Encadear próximo ao centro da janela ativa o **Fluxo Ancestral**, que encurta a recuperação e leva a postura do golpe anterior ao seguinte. Cada golpe do combo exige um toque.

## Andarilho 2.0

O **Movimento Adaptativo do Andarilho** combina cada passada com a distância percorrida. O pé de apoio fica no mesmo ponto do piso enquanto o tronco avança. Durante uma inversão brusca no chão, um pé sustenta o peso enquanto o outro recupera a passada. A capa acompanha a freada e, com a espada guardada, a mão ampara a bainha. O salto distingue a extensão do impulso, a subida, o ápice, a abertura das pernas na queda e a compressão no contato com o chão.

O cinto, a boca da bainha e a empunhadura têm pontos de encaixe na cena do personagem. Durante o saque, a mão alcança o cabo e acompanha a lâmina pela boca da bainha. Guardar a espada percorre a mesma trajetória no sentido inverso.

### Conferir no Android

Importe o projeto no Godot 4.7 do Galaxy A36, execute e toque em **Jogar**. Use **Armas → Espada**, aproxime-se do alvo e encadeie os três golpes com o arco dourado. Repita andando, correndo, pulando e no lado oposto do alvo. Pressione **Armas** no meio de um golpe para conferir a interrupção do combo e guarde a espada. Observe a bainha na cintura e o cabo dentro da mão durante as transições. Repita com **Configurações → Acessibilidade → Tamanho do HUD** em 150% e com os dois limites de quadros. O teste no aparelho mede a resposta real ao toque e a estabilidade de quadros.

### Teste automatizado

As suítes `andarilho_regression.gd`, `combate_regression.gd` e `impacto_regression.gd` em `tests/` injetam toques na sala de teste. No Linux, execute com um perfil descartável.

```bash
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --import
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/andarilho_regression.gd
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/andarilho_regression.gd -- 30fps
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/combate_regression.gd
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/combate_regression.gd -- 30fps
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/impacto_regression.gd
XDG_DATA_HOME=$(mktemp -d) godot4 --headless --path . --script res://tests/impacto_regression.gd -- 30fps
```

## Onde editar

- `scenes/splash/` contém a abertura **Despertando o Núcleo**, com progresso real e cenário em `assets/splash/santuario_do_nucleo.jpg`.
- `scenes/menu/` contém o carrossel, os painéis e o prólogo.
- `assets/menu/ponte_do_sino_partido.jpg` é o fundo da tela inicial. O título é uma camada editável na cena do menu.
- `assets/menu/selos/` guarda os originais em PNG (384 × 384) e as texturas `.res` usadas pelo carrossel. Cada `.res` contém a imagem, sem depender do cache de importação dos PNGs. O texto e o desenho de reserva ficam em `scenes/menu/carousel.gd`.
- `scenes/menu/settings_view.gd` monta o painel de configurações, com a ilustração em `assets/menu/configuracoes/astrolabio.jpg`.
- `characters/player/player.tscn` é a cena reutilizável do personagem. Selecione o nó raiz para ajustar velocidade no chão e no ar, aceleração, pulo, gravidade e distância de cada ciclo de caminhada no Inspetor.
- `characters/player/adaptive_motion.gd` define as fases de movimento e as reações à velocidade, à freada e ao pouso. `motion.gd` combina essas reações com o ciclo de pernas, os braços, o tecido, o saque e os cortes. `figure.gd` monta as peças de `andarilho_articulado.png` e desenha o equipamento a partir dos pontos da cena.
- `characters/player/combat_controller.gd` controla o relógio do golpe e o pedido de encadeamento. Abra os recursos em `characters/player/strikes/` no Inspetor para ajustar duração, janela ativa, `chain_open`, `chain_close` e as chaves de pose. As duas janelas usam frações de 0 a 1 do tempo do golpe.
- `scenes/world/test_world.tscn` contém o piso e os limites laterais da sala de teste.
- `systems/story.gd` organiza os capítulos e trechos, ligados por identificadores estáveis. Preserve os identificadores de trechos já publicados para que os slots antigos continuem válidos.
- `systems/campaign.gd` gerencia os três slots em arquivos locais `user://campanha_1.cfg` a `campanha_3.cfg`. As partidas são armazenadas no dispositivo.
- `systems/preferences.gd` carrega e salva as preferências.

A base é 1280 × 720, com interface em paisagem e renderizador Compatibility. O projeto inclui preset de exportação Android para ARM64 e ARMv7. Para gerar um APK, configure os templates de exportação e o ambiente Android no Godot.
