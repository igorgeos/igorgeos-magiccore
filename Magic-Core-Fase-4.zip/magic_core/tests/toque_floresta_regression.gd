extends SceneTree

func _initialize() -> void:
	run.call_deferred()
	create_timer(9.0).timeout.connect(func(): quit(1))


func frames(n: int) -> void:
	for i in n:
		await physics_frame


func finger(index: int, point: Vector2, down: bool) -> void:
	var touch := InputEventScreenTouch.new()
	touch.index = index
	touch.position = point
	touch.pressed = down
	root.push_input(touch, true)


func run() -> void:
	var prefs = root.get_node("Preferences")
	var campaign = root.get_node("Campaign")
	var fps := 30 if "30" in OS.get_cmdline_user_args() else 60
	prefs.values.fps = fps
	prefs.values.hud_size = 150
	prefs.values.large_text = true
	prefs.apply()
	root.size = Vector2i(2340, 1080) if fps == 30 else Vector2i(1920, 1080)
	assert(campaign.start(1) == OK and campaign.enter_stage("mata1"))
	assert(change_scene_to_file(campaign.stage_data("mata1").scene) == OK)
	await frames(6)
	var forest = current_scene
	var hero = forest._player
	assert(Engine.max_fps == fps)
	assert(forest._mission_plate.get_global_rect().encloses(forest.objective.get_global_rect()))
	assert(forest._mission_plate.get_rect().end.x < forest._controls._origin.x + forest._controls.centers[&"back"].x * forest._controls._unit)
	hero.position = Vector2(1178, 540)
	hero.reset_physics_interpolation()
	forest.hurt(24, 0.0)
	await frames(5)
	assert(forest.interact.visible and forest.hp == 76)
	var hud = forest._controls
	var right: Vector2 = hud._origin + hud.centers[&"right"] * hud._unit
	var touch: Vector2 = forest.interact.get_global_rect().get_center()
	finger(0, right, true)
	assert(hero.touch_axis > 0)
	finger(1, touch, true)
	finger(1, touch, false)
	assert(forest.hp == 100 and forest.used.has("rest"))
	assert(hero.touch_axis > 0)
	finger(0, right, false)
	assert(is_zero_approx(hero.touch_axis))
	hero.position = Vector2(2190, 540)
	hero.reset_physics_interpolation()
	await frames(5)
	touch = forest.interact.get_global_rect().get_center()
	finger(0, touch, true)
	finger(0, touch, false)
	assert(forest.won and campaign.completed == ["mata1"])
	await frames(24)
	for button in forest._hud.find_children("*", "Button", true, false):
		if button.text == "Voltar ao mapa":
			touch = button.get_global_rect().get_center()
			finger(0, touch, true)
			finger(0, touch, false)
			break
	await frames(9)
	assert(current_scene.scene_file_path == campaign.ATLAS and current_scene.map_open)
	print("PASS: interação por segundo toque, cura única, área segura do HUD e vitória a ", fps, " FPS em ", root.size)
	prefs.stop_audio()
	await create_timer(0.35).timeout
	quit()
