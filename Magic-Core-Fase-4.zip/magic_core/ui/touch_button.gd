extends Button
## An interaction remains available while another finger holds a movement control.

var _finger := -1


func _notification(what: int) -> void:
	if what == NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree():
		_finger = -1


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.device == InputEvent.DEVICE_ID_EMULATION:
		accept_event()
		return
	if event is not InputEventScreenTouch or disabled:
		return
	accept_event()
	if event.pressed and _finger < 0:
		_finger = event.index
	elif not event.pressed and _finger == event.index:
		_finger = -1
		if not event.canceled and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit()
