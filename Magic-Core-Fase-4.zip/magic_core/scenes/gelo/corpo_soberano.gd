extends Node3D
## Pilota as placas rígidas da malha do Senhor do Abismo. Os pivôs da
## exportação usam +X para frente, +Y para cima e +Z para o lado da espada.

const MODEL := preload("res://assets/gelo/senhor_abismo.glb")
const PIXEL := 0.278
const ORIGIN := Vector2(850, 813)
const BLADE_TIP := Vector3(0, -96, 0)
const SLOT_DEPTH := {
	"torso": 0.0, "head": 0.0, "cape": 0.0, "hem": 0.0,
	"upper_a": 34.0, "lower_a": 34.0, "sword": 34.0,
	"upper_b": -34.0, "lower_b": -34.0,
	"thigh_a": 15.5, "shin_a": 15.5, "boot_a": 15.5,
	"thigh_b": -15.5, "shin_b": -15.5, "boot_b": -15.5,
}

var _sockets: Dictionary = {}


static func at(x: float, y: float) -> Vector2:
	return (Vector2(x, y) - ORIGIN) * PIXEL


func construct() -> void:
	var imported := MODEL.instantiate() as Node3D
	add_child(imported)
	for key: String in SLOT_DEPTH:
		var socket := imported.find_child(key, true, false) as Node3D
		assert(socket != null, "Pivô ausente na malha do Abismo: " + key)
		_sockets[key] = socket


func pose(key: String, point: Vector2, angle := 0.0) -> void:
	var socket: Node3D = _sockets[key]
	socket.position = Vector3(point.x, -point.y, SLOT_DEPTH[key])
	socket.rotation.z = -angle


func leg_segment(key: String, start: Vector3, finish: Vector3, length: float) -> void:
	var socket: Node3D = _sockets[key]
	var direction := finish - start
	socket.transform = Transform3D(
		Basis(Quaternion(Vector3.DOWN, direction.normalized())).scaled_local(
			Vector3(1.0, direction.length() / length, 1.0)), start)


func boot(key: String, point: Vector3, pitch: float) -> void:
	var socket: Node3D = _sockets[key]
	socket.position = point
	socket.rotation.z = -pitch


func projected(point: Vector2, weapon_side := false) -> Vector2:
	return project_3d(Vector3(point.x, -point.y, SLOT_DEPTH["sword"] if weapon_side else 0.0))


func project_3d(point: Vector3) -> Vector2:
	var world := transform * point
	return Vector2(world.x, -world.y)


func sword_point(tip := false) -> Vector2:
	var sword: Node3D = _sockets["sword"]
	return project_3d(sword.transform * (BLADE_TIP if tip else Vector3.ZERO))
