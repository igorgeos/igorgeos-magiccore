extends Node3D
## Each plane keeps the original painted pixels. The outline cuts the artwork
## into pieces, while the rig defines how those pieces move around their pivots.

const ART := preload("res://assets/gelo/soberano_referencia.png")
const PIXEL := 0.278
const ORIGIN := Vector2(850, 813)

var _pieces: Dictionary = {}


var _art_size := Vector2(ART.get_width(), ART.get_height())


static func at(x: float, y: float) -> Vector2:
	return (Vector2(x, y) - ORIGIN) * PIXEL


func build() -> void:
	_part("rest", Vector2(850, 813), [
		900, 9, 914, 6, 907, 30, 899, 60, 904, 76, 916, 100, 904, 128,
		902, 150, 911, 165, 922, 184, 932, 204, 934, 238, 932, 280, 931, 319,
		937, 345, 939, 360, 930, 369, 940, 403, 951, 466, 950, 503, 940, 587,
		936, 553, 929, 531, 930, 503, 924, 491, 916, 507, 919, 541, 926, 566,
		916, 601, 902, 625, 893, 659, 889, 713, 883, 745, 896, 758, 916, 768,
		943, 792, 949, 804, 947, 815, 803, 815, 797, 805, 801, 774, 808, 756,
		814, 739, 812, 712, 803, 671, 802, 648, 807, 627, 804, 611, 806, 576,
		811, 563, 811, 533, 812, 516, 803, 527, 794, 519, 789, 552, 782, 570,
		781, 598, 782, 631, 783, 668, 769, 690, 758, 717, 758, 738, 741, 775,
		741, 747, 734, 766, 730, 748, 727, 710, 728, 669, 735, 642, 735, 623,
		723, 644, 712, 671, 707, 701, 705, 674, 700, 660, 706, 640, 713, 613,
		722, 587, 718, 589, 731, 558, 735, 527, 748, 485, 758, 445, 767, 412,
		776, 378, 783, 343, 766, 365, 765, 347, 772, 316, 778, 294, 783, 260,
		779, 245, 775, 229, 771, 208, 770, 189, 773, 172, 781, 153, 791, 134,
		806, 123, 820, 108, 826, 115, 824, 86, 819, 79, 817, 68, 838, 58,
		872, 50, 883, 28, 888, 38, 885, 51, 890, 51, 897, 26], 10)
	# Keep both shape and color from the original profile or the front study.
	_part("cape", Vector2(811, 162), [
		811, 135, 846, 134, 839, 271, 810, 367, 799, 471, 781, 568, 782, 624,
		782, 665, 762, 709, 758, 742, 741, 776, 740, 748, 734, 765, 727, 718,
		733, 643, 738, 619, 726, 640, 713, 672, 707, 699, 702, 670, 700, 659,
		715, 610, 723, 585, 733, 546, 742, 513, 754, 472, 765, 431, 777, 389,
		786, 338, 768, 361, 769, 336, 778, 297, 791, 242], -11)
	_part("upper_b", Vector2(487, 190), [
		451, 167, 472, 164, 494, 175, 510, 196, 521, 227, 525, 254, 540, 283,
		526, 304, 498, 294, 485, 267, 474, 234, 453, 214], -8, Vector2(0.86, 1))
	_part("lower_b", Vector2(513, 290), [
		502, 274, 529, 263, 540, 283, 557, 303, 562, 330, 576, 352, 590, 377,
		603, 396, 612, 426, 609, 458, 599, 476, 591, 469, 588, 434, 576, 410,
		564, 428, 557, 442, 551, 434, 552, 412, 554, 390, 538, 362, 518, 335,
		496, 313], -7, Vector2(0.82, 0.86))
	for mark in ["a", "b"]:
		var front: bool = mark == "a"
		_part("thigh_" + mark, Vector2(859, 465), [
			822, 423, 899, 425, 920, 457, 917, 494, 905, 529, 910, 550, 919, 572,
			904, 595, 857, 599, 817, 584, 813, 555, 815, 528, 800, 526, 802, 482], 1 if front else -6)
		_part("shin_" + mark, Vector2(867, 589), [
			813, 568, 851, 561, 900, 550, 924, 565, 918, 600, 903, 630, 892, 660,
			886, 713, 881, 751, 858, 768, 814, 755, 808, 740, 813, 718, 806, 683,
			802, 651, 810, 621, 804, 604], 2 if front else -5)
		_part("boot_" + mark, Vector2(850, 770), [
			812, 742, 880, 740, 898, 758, 917, 769, 942, 792, 949, 805, 947, 815,
			803, 815, 798, 805, 800, 777, 806, 757], 3 if front else -4)
		if not front:
			for segment in ["thigh_", "shin_", "boot_"]:
				var piece: StandardMaterial3D = _pieces[segment + mark].material_override
				piece.albedo_color = Color(0.73, 0.75, 0.80)
	_part("torso", Vector2(376, 347), [
		327, 141, 349, 132, 370, 145, 388, 142, 414, 132, 439, 151, 463, 192,
		450, 243, 443, 290, 454, 346, 462, 373, 458, 430, 407, 446, 368, 421,
		324, 445, 284, 432, 293, 376, 302, 329, 305, 292, 290, 245, 287, 209,
		302, 175], 4, Vector2(0.68, 1.08))
	_part("head", Vector2(866, 124), [
		818, 68, 838, 58, 871, 50, 884, 29, 887, 38, 885, 51, 891, 50, 901, 9,
		913, 6, 907, 31, 900, 57, 903, 77, 916, 101, 907, 125, 901, 151,
		870, 149, 853, 140, 838, 119, 827, 118, 822, 88], 5)
	_part("upper_a", Vector2(828, 166), [
		822, 107, 847, 127, 871, 146, 887, 175, 886, 200, 886, 229, 877, 253,
		860, 251, 862, 266, 866, 289, 857, 319, 835, 343, 815, 330, 803, 313,
		804, 288, 811, 269, 804, 253, 790, 256, 784, 237, 773, 216, 770, 195,
		775, 171, 785, 146, 800, 131], 8)
	_part("lower_a", Vector2(833, 312), [
		815, 277, 839, 269, 861, 285, 872, 313, 864, 330, 867, 350, 875, 373,
		880, 392, 895, 424, 895, 451, 885, 474, 868, 480, 856, 480, 849, 469,
		839, 473, 831, 458, 827, 438, 821, 418, 819, 389, 816, 371, 806, 344,
		801, 321, 803, 295], 9)
	_part("sword", Vector2(1170, 146), [
		1155, 78, 1184, 74, 1196, 96, 1182, 103, 1183, 196, 1199, 223,
		1244, 224, 1242, 254, 1225, 246, 1204, 241, 1205, 270, 1203, 363,
		1204, 447, 1199, 483, 1205, 491, 1204, 544, 1203, 606, 1198, 634,
		1204, 650, 1203, 706, 1172, 796, 1157, 752, 1138, 707, 1136, 592,
		1136, 523, 1145, 484, 1133, 476, 1142, 459, 1135, 452, 1138, 425,
		1136, 308, 1136, 276, 1133, 263, 1135, 244, 1110, 248, 1094, 255,
		1099, 225, 1128, 226, 1149, 224, 1158, 203, 1158, 102, 1146, 96], 7,
		Vector2.ONE * 0.43)


func set_profile_pose(still: bool) -> void:
	for key in _pieces:
		(_pieces[key] as MeshInstance3D).visible = key == "sword" or (key == "rest") == still


func pose(key: String, point: Vector2, angle := 0.0) -> void:
	var piece: MeshInstance3D = _pieces[key]
	piece.position.x = point.x
	piece.position.y = -point.y
	piece.rotation.z = -angle


func _part(key: String, pivot: Vector2, outline: Array, order: int, aspect := Vector2.ONE) -> MeshInstance3D:
	var uv_pixels := PackedVector2Array()
	var vertices := PackedVector3Array()
	for i in range(0, outline.size(), 2):
		var pixel := Vector2(outline[i], outline[i + 1])
		uv_pixels.append(pixel)
		var point := (pixel - pivot) * PIXEL * aspect
		vertices.append(Vector3(point.x, -point.y, 0))
	var indices := Geometry2D.triangulate_polygon(uv_pixels)
	assert(not indices.is_empty(), "Contorno inválido: " + key)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var uv := PackedVector2Array()
	for pixel in uv_pixels:
		uv.append(pixel / _art_size)
	arrays[Mesh.ARRAY_TEX_UV] = uv
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var finish := StandardMaterial3D.new()
	finish.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	finish.cull_mode = BaseMaterial3D.CULL_DISABLED
	finish.albedo_texture = ART
	finish.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = finish
	instance.position.z = float(order) * 0.7
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	_pieces[key] = instance
	return instance
