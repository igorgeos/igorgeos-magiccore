extends "res://scenes/gelo/corpos_de_gelo.gd"
## Armadura articulada com malhas fechadas. Frente anatômica em +X,
## largura dos ombros em Z e eixo vertical em Y.

const PIXEL := 0.278
const ORIGIN := Vector2(850, 813)
const NIGHT := Color("#111a2d")
const STEEL := Color("#263855")
const EDGE := Color("#647692")
const SILVER := Color("#929fb9")
const BRASS := Color("#ac8c69")
const FROST := Color("#dce5f4")
const SHADOW_FUR := Color("#5c6e91")
const PLUM := Color("#35182f")
const WINE := Color("#772b51")
const GLACIER := Color("#1476cf")
const ICE_EDGE := Color("#82ddff")
const RADIANCE := Color("#baf4ff")

static var _abyss_meshes: Dictionary = {}
static var _material: ShaderMaterial
var _depth: Dictionary = {}
var _sockets: Dictionary = {}


static func at(x: float, y: float) -> Vector2:
	return (Vector2(x, y) - ORIGIN) * PIXEL


func construct() -> void:
	if _abyss_meshes.is_empty():
		_sculpt()
		for key in _surfaces:
			var surface: SurfaceTool = _surfaces[key]
			surface.index()
			_abyss_meshes[key] = surface.commit()
		_surfaces.clear()
	if _material == null:
		_material = ShaderMaterial.new()
		_material.shader = preload("res://scenes/gelo/material_abismo.gdshader")
	for key in _abyss_meshes:
		var socket := Node3D.new()
		socket.name = key
		add_child(socket)
		_sockets[key] = socket
		var mesh := MeshInstance3D.new()
		mesh.mesh = _abyss_meshes[key]
		mesh.material_override = _material
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		socket.add_child(mesh)
	_depth = {
		"upper_a": 34.0, "lower_a": 34.0, "sword": 34.0,
		"upper_b": -34.0, "lower_b": -34.0,
		"thigh_a": 15.5, "shin_a": 15.5, "boot_a": 15.5,
		"thigh_b": -15.5, "shin_b": -15.5, "boot_b": -15.5,
	}


func pose(key: String, point: Vector2, angle := 0.0, stretch := 1.0) -> void:
	var socket: Node3D = _sockets[key]
	socket.position = Vector3(point.x, -point.y, _depth.get(key, 0.0))
	socket.rotation.z = -angle
	socket.scale.y = stretch


func projected(point: Vector2, weapon_side := false) -> Vector2:
	var world := transform * Vector3(point.x, -point.y, 34.0 if weapon_side else 0.0)
	return Vector2(world.x, -world.y)


func _sculpt() -> void:
	_part("torso", "cuirass", Vector3(51, 60, 61), Vector3(-1, 24, 0), NIGHT)
	_part("torso", "cuirass", Vector3(49, 46, 56), Vector3(4, 31, 0), STEEL)
	for level in 3:
		var y := 37.0 - 11.0 * level
		var width := 56.0 - 5.0 * level
		_part("torso", "lame", Vector3(47 - level * 3, 11, width), Vector3(4, y, 0), EDGE.darkened(0.14))
		_part("torso", "lame", Vector3(49 - level * 3, 9, width - 2), Vector3(5, y + 2, 0), STEEL)
		for sign_z in [-1.0, 1.0]:
			var start := Vector3(29 - level * 1.6, y - 2, 0)
			var end := Vector3(22 - level * 1.6, y + 5, (width * 0.34) * sign_z)
			_bar("torso", start, end, 1.45, BRASS if level == 0 else EDGE)
			if level == 0:
				_bar("torso", end, end + Vector3(-3.5, -9.5, 3.5 * sign_z), 1.2, SILVER, false, true)
	_part("torso", "band", Vector3(43, 10, 54), Vector3(1, -4, 0), BRASS)
	_part("torso", "band", Vector3(44, 6, 54), Vector3(1, -4, 0), NIGHT)
	_part("torso", "bevel", Vector3(9, 10, 12), Vector3(24, -3, 0), BRASS)
	for z in [-17.0, 17.0]:
		_part("torso", "lame", Vector3(28, 27, 24), Vector3(3, -19, z), EDGE, Vector3(0.17 * signf(z), 0, 0.16))
		_part("torso", "lame", Vector3(30, 21, 22), Vector3(5, -17, z), NIGHT, Vector3(0.17 * signf(z), 0, 0.16))
	_part("torso", "cloth", Vector3(13, 58, 13), Vector3(22, -31, 0), WINE, Vector3(0, 0, -0.07))
	_part("torso", "mail", Vector3(19, 18, 24), Vector3(1, 52, 0), NIGHT)
	for side in [-1.0, 1.0]:
		var z := float(side)
		_bar("torso", Vector3(23, 45, 22 * z), Vector3(27, 21, 17 * z), 1.65, EDGE)
		_bar("torso", Vector3(27, 21, 17 * z), Vector3(28, 12, 8 * z), 1.35, BRASS)
		for i in 3:
			_part("torso", "bevel", Vector3(3, 2.3, 2.3), Vector3(23.5 - i, 34 - 7 * i, 22 * z), BRASS)
	# Small skull clasp on each side of the fur.
	for sign_z in [-1.0, 1.0]:
		var z := float(sign_z) * 24.0
		_part("torso", "helm", Vector3(9, 11, 10), Vector3(19, 43, z), BRASS)
		_part("torso", "bevel", Vector3(8, 5, 7), Vector3(21, 38, z), BRASS)
		for eye in [-2.0, 2.0]:
			_part("torso", "bevel", Vector3(1.8, 2.5, 2.3), Vector3(23.2, 42.8, z + eye), NIGHT)

	_part("head", "helm", Vector3(30, 35, 29), Vector3(-1, 6, 0), NIGHT)
	_part("head", "helm", Vector3(32, 26, 29), Vector3(0, 11, 0), STEEL)
	_part("head", "blade", Vector3(18, 29, 23), Vector3(10, -4, 0), NIGHT, Vector3(0, 0, PI))
	_bar("head", Vector3(19, 6, 0), Vector3(15, -16, 0), 3.8, EDGE)
	for sign_z in [-1.0, 1.0]:
		var z := float(sign_z)
		_bar("head", Vector3(13, 8, 12 * z), Vector3(19.5, 3, 2.0 * z), 4.1, ICE_EDGE, true)
		_bar("head", Vector3(13, 13, 14 * z), Vector3(19.8, 7, 2.6 * z), 2.9, SILVER)
		_bar("head", Vector3(15, -7, 12 * z), Vector3(16, -15, 4 * z), 1.9, EDGE)
		_horn(Vector3(-4, 10, 13 * z), Vector3(-8, 27, 16 * z), Vector3(-1, 47, 21 * z), 5.5)
		_horn(Vector3(3, 11, 10 * z), Vector3(7, 22, 11 * z), Vector3(9, 37, 11 * z), 3.9)
	_horn(Vector3(10, 8, 0), Vector3(11, 25, 0), Vector3(6, 39, 0), 3.5)

	for mark: String in ["a", "b"]:
		var side := 1.0 if mark == "a" else -1.0
		var arm := "upper_" + mark
		var forearm := "lower_" + mark
		var thigh := "thigh_" + mark
		var shin := "shin_" + mark
		var boot := "boot_" + mark
		_part(arm, "mail", Vector3(20, 36, 23), Vector3(0, -20, 0), NIGHT)
		_part(arm, "pauldron", Vector3(34, 25, 33), Vector3(-4, 1, 2 * side), SILVER)
		_part(arm, "pauldron", Vector3(33, 22, 34), Vector3(-4, 4, 2 * side), STEEL)
		_part(arm, "lame", Vector3(29, 11, 30), Vector3(0, -14, 2 * side), EDGE)
		_part(arm, "lame", Vector3(28, 9, 28), Vector3(1, -17, 1 * side), NIGHT)
		_bar(arm, Vector3(13, 3, 10 * side), Vector3(0, -10, 18 * side), 2.1, BRASS)
		_part(forearm, "pauldron", Vector3(23, 18, 23), Vector3(0, 1, 0), EDGE)
		_part(forearm, "lame", Vector3(21, 26, 23), Vector3(1, -14, 0), STEEL)
		_bar(forearm, Vector3(8, -6, 9 * side), Vector3(6, -24, 9 * side), 2.7, SILVER)
		_part(forearm, "band", Vector3(20, 7, 23), Vector3(0, -26, 0), BRASS)
		_part(forearm, "bevel", Vector3(17, 15, 19), Vector3(0, -34, 0), NIGHT)
		for i in 4:
			_bar(forearm, Vector3(3.4, -31.5, (i - 1.5) * 3.6), Vector3(3.8, -38, (i - 1.5) * 3.5),
				3.1, EDGE.darkened(0.19), false, true)
		_part(thigh, "mail", Vector3(25, 39, 26), Vector3(0, -17, 0), NIGHT)
		_part(thigh, "lame", Vector3(23, 30, 27), Vector3(5, -15, 0), STEEL)
		_bar(thigh, Vector3(12, -5, 8 * side), Vector3(10, -27, 10 * side), 2.1, BRASS)
		_part(shin, "lame", Vector3(22, 47, 24), Vector3(2, -26, 0), NIGHT)
		_part(shin, "pauldron", Vector3(28, 22, 27), Vector3(6, -1, 0), EDGE)
		_part(shin, "pauldron", Vector3(31, 18, 24), Vector3(7, 0, 0), STEEL)
		_part(shin, "lame", Vector3(23, 30, 20), Vector3(6, -29, 0), STEEL)
		_bar(shin, Vector3(16, -6, 10 * side), Vector3(10, -40, 7 * side), 2.2, EDGE)
		_part(boot, "boot", Vector3(37, 18, 25), Vector3(8, -3, 0), NIGHT)
		for index in 3:
			_part(boot, "lame", Vector3(18, 7, 23 - index * 2), Vector3(7 + index * 5, 1 - index, 0), EDGE.darkened(0.23))

	# White fur made of tapered solid tufts running over both shoulder blades.
	_part("cape", "pauldron", Vector3(40, 19, 82), Vector3(3, 3, 0), SHADOW_FUR)
	for row in 4:
		for i in 13:
			var z := (i - 6) * 6.5
			var base := Vector3(6 - row * 6.4, 12 - 4 * row - absf(z) * 0.11, z)
			var lateral := (0.19 + row * 0.055) * z
			var tip := base + Vector3(-10 - float((i * 3 + row) % 9), -8 - 3 * row, lateral)
			var shade := float((i * 3 + row) % 4) * 0.12
			_bar("cape", base, tip, 11.0 - (row % 2) * 2.25, FROST.lerp(SHADOW_FUR, shade), false, true)
	for side in [-1.0, 1.0]:
		for i in 5:
			var root := Vector3(13 - i * 4.4, 9 - i * 1.4, (26.0 + i * 2.3) * side)
			_bar("cape", root, root + Vector3(-15, -10, 13 * side), 11.3 - i * 0.7,
				FROST.lerp(SHADOW_FUR, i * 0.07), false, true)
	_cloth("cape", 0, 65, 0.0)
	_cloth("hem", 65, 143, -15.0)
	for arm in 6:
		var ray := Vector3(0, cos(arm * TAU / 6.0), sin(arm * TAU / 6.0))
		var base := Vector3(-26, -34, 0)
		_bar("cape", base, base + ray * 10.0, 1.3, FROST)
		_bar("cape", base + ray * 6.7, base + ray * 8.5 + Vector3(0, ray.z, -ray.y) * 2.4, 1.0, FROST)
	_sword()


func _sword() -> void:
	_part("sword", "band", Vector3(8, 24, 8), Vector3(0, 0, 0), NIGHT)
	_part("sword", "ice", Vector3(13, 13, 11), Vector3(0, 16, 0), STEEL)
	_bar("sword", Vector3(-16, -19, 0), Vector3(16, -19, 0), 7.0, BRASS)
	for side in [-1.0, 1.0]:
		_bar("sword", Vector3(8 * side, -16, 0), Vector3(21 * side, -8, 0), 8, EDGE, false, true)
		_bar("sword", Vector3(18 * side, -20, 0), Vector3(22 * side, -27, 0), 5, ICE_EDGE, true, true)
	_part("sword", "blade", Vector3(20, 82, 9), Vector3(0, -55, 0), GLACIER, Vector3(0, 0, PI))
	_bar("sword", Vector3(0, -17, 5), Vector3(0, -89, 2), 4.5, RADIANCE, true, true)
	_bar("sword", Vector3(0, -17, -5), Vector3(0, -89, -2), 4.5, RADIANCE, true, true)
	for side in [-1.0, 1.0]:
		for i in 4:
			_bar("sword", Vector3(side * (10.0 - i), -29.0 - i * 13.0, 0),
				Vector3(side * (14.0 - i * 1.8), -36.0 - i * 13.0, 0), 4.5, ICE_EDGE, true, true)


func _horn(a: Vector3, b: Vector3, c: Vector3, width: float) -> void:
	_bar("head", a, b, width, EDGE)
	_bar("head", b, c, width * 0.68, SILVER, false, true)


func _bar(key: String, a: Vector3, b: Vector3, width: float, color: Color,
		luminous := false, pointed := false) -> void:
	var delta := b - a
	var angle := Quaternion(Vector3.UP, delta.normalized()).get_euler()
	# The shared ice primitive tapers at its positive Y end.
	if luminous:
		_part(key, "ice", Vector3(width, delta.length() + 2.0, width), (a + b) * 0.5, color, angle)
	else:
		_part(key, "blade" if pointed else "bevel", Vector3(width, delta.length() + 1.5, width),
			(a + b) * 0.5, color, angle)


func _cloth(key: String, start: int, finish: int, pivot_x: float) -> void:
	var pitch := 11
	for i in range(-4, 4):
		var z := float(i * pitch)
		var rag := float(posmod(i * 21, 5))
		var last := finish + int(rag * 5.5) - 7 if key == "hem" else finish
		var a := _cloth_point(start, z, start, pivot_x)
		var b := _cloth_point(start, z + pitch, start, pivot_x)
		var c := _cloth_point(last, z + (2 if key == "hem" else 0), start, pivot_x)
		var d := _cloth_point(finish - 3 if key == "hem" else finish, z + pitch, start, pivot_x)
		var tint := PLUM.lerp(WINE, 0.28 + rag * 0.13)
		_panel(key, a, b, c, tint)
		_panel(key, b, d, c, tint.darkened(0.20))


func _cloth_point(y: int, z: float, start: int, pivot_x: float) -> Vector3:
	var fall := float(y)
	return Vector3(-13.0 - fall * 0.18 + sin(z * 0.21) * (2.1 + fall * 0.035) - pivot_x,
		float(start - y), z * (0.80 + fall * 0.0034))


func _panel(key: String, a: Vector3, b: Vector3, c: Vector3, tint: Color) -> void:
	if not _surfaces.has(key):
		var new_surface := SurfaceTool.new()
		new_surface.begin(Mesh.PRIMITIVE_TRIANGLES)
		_surfaces[key] = new_surface
	var surface: SurfaceTool = _surfaces[key]
	var face := (c - a).cross(b - a).normalized()
	for point in [a, b, c]:
		surface.set_normal(face)
		surface.set_color(tint)
		surface.set_uv2(Vector2(0.12, 1))
		surface.add_vertex(point)
