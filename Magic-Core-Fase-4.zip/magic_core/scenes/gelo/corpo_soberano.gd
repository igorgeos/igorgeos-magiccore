extends "res://scenes/gelo/corpos_de_gelo.gd"

const MAIL := Color("#323d46")
const STEEL := Color("#657683")
const EDGES := Color("#94a3aa")
const BRONZE := Color("#a3875c")
const LEATHER := Color("#443830")
const CLOTH := Color("#324a61")
const RIME := Color("#a8d0df")



func _material_for_mesh() -> ShaderMaterial:
	var finish := super().duplicate() as ShaderMaterial
	finish.set_shader_parameter("painted_finish", true)
	finish.set_shader_parameter("painted_study", preload("res://assets/gelo/soberano_referencia.png"))
	return finish


func _sculpt_sovereign() -> void:
	_part("hip", "mail", Vector3(43, 30, 58), Vector3(0, 1, 0), MAIL)
	_part("hip", "band", Vector3(44, 10, 65), Vector3(0, 8, 0), LEATHER)
	_part("hip", "bevel", Vector3(7, 10, 13), Vector3(23, 8, 0), BRONZE)
	_part("ribcage", "cuirass", Vector3(65, 58, 76), Vector3(-5, -12, 0), STEEL)
	_part("ribcage", "band", Vector3(52, 8, 53), Vector3(-6, 13, 0), EDGES)
	_part("ribcage", "ice", Vector3(6, 10, 10), Vector3(22, 8, 0), RIME)
	for index in 3:
		_part("ribcage", "lame", Vector3(48, 10, 57 - index * 4), Vector3(-2, -39 + 7 * index, 0),
			STEEL.darkened(0.15 + index * 0.025), Vector3(0, 0, 0.11))
	_part("neck", "mail", Vector3(22, 0.85, 25), Vector3(0, 0.5, 0), MAIL)
	_part("head", "helm", Vector3(36, 43, 36), Vector3(0, 5, 0), STEEL)
	_part("head", "bevel", Vector3(19, 19, 30), Vector3(12, -4, 0), MAIL)
	_part("head", "bevel", Vector3(13, 14, 27), Vector3(16, -5, 0), STEEL)
	_part("head", "bevel", Vector3(7, 5, 29), Vector3(18, 5, 0), MAIL)
	for depth in [-8.0, 8.0]:
		_part("head", "bevel", Vector3(4, 2.3, 8), Vector3(21.0, 5, depth), RIME)
	_part("head", "band", Vector3(35, 6, 39), Vector3(-2, 19, 0), BRONZE)
	for index in 5:
		var angle := TAU * index / 5.0
		var length: float = [16.0, 10.0, 13.0, 9.0, 15.0][index]
		_part("head", "blade", Vector3(7, length, 7), Vector3(cos(angle) * 14.5 - 2, 20 + length * 0.44,
			sin(angle) * 16), BRONZE.lightened(0.10), Vector3(0, -angle, -0.19))
	for limb in ["a", "b"]:
		var near_side: bool = limb == "a"
		var weight := 1.0 if near_side else 0.83
		_part("shoulder_" + limb, "pauldron", Vector3(44, 35, 46) * weight, Vector3(-5, 2, 0), STEEL)
		_part("shoulder_" + limb, "lame", Vector3(37, 10, 40) * weight, Vector3(-3, -12, 0), EDGES.darkened(0.27))
		_part("upper_" + limb, "mail", Vector3(28, 1.11, 27) * Vector3(weight, 1, weight), Vector3(0, 0.48, 0), MAIL)
		_part("elbow_" + limb, "bevel", Vector3(24, 21, 28) * weight, Vector3.ZERO, STEEL)
		_part("lower_" + limb, "lame", Vector3(29 * weight, 1.05, 30 * weight), Vector3(0, 0.46, 0), STEEL)
		_part("lower_" + limb, "band", Vector3(24, 0.15, 26) * Vector3(weight, 1, weight), Vector3(0, 0.79, 0), EDGES)
		_part("hand_" + limb, "bevel", Vector3(19, 24, 23) * weight, Vector3(0, 4, 0), MAIL)
		_part("thigh_" + limb, "lame", Vector3(32, 1.11, 34), Vector3(0, 0.44, 0), MAIL)
		_part("shin_" + limb, "lame", Vector3(28, 1.15, 29), Vector3(0, 0.47, 0), STEEL)
		_part("knee_" + limb, "pauldron", Vector3(29, 27, 30), Vector3(5, 0, 0), EDGES.darkened(0.25))
		_part("boot_" + limb, "boot", Vector3(40, 17, 31), Vector3(9, -1, 0), MAIL)
		_part("boot_" + limb, "lame", Vector3(26, 11, 27), Vector3(17, -1, 0), STEEL)
	_part("hand_a", "band", Vector3(8, 28, 8), Vector3(0, 0, 0), LEATHER)
	_part("hand_a", "bevel", Vector3(33, 6, 10), Vector3(0, 14, 0), BRONZE)
	_part("hand_a", "bevel", Vector3(14, 10, 12), Vector3(0, -16, 0), BRONZE)
	_part("hand_a", "blade", Vector3(21, 62, 7), Vector3(0, 45, 0), EDGES)
	_part("hand_a", "lame", Vector3(4, 28, 7.5), Vector3(0, 36, 0), RIME.darkened(0.26))
	_part("mantle", "cloth", Vector3(22, 45, 62), Vector3(-10, -19, 0), CLOTH)
	_part("hem", "cloth", Vector3(16, 73, 30), Vector3(-13, -32, -13), CLOTH.darkened(0.19),
		Vector3(-0.11, 0, -0.20))
	_part("hem", "cloth", Vector3(15, 84, 25), Vector3(-17, -34, 15), CLOTH.darkened(0.11),
		Vector3(0.15, 0, -0.16))
