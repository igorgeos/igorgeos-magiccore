shader_type spatial;
render_mode unshaded, cull_back;

uniform bool painted_finish = false;
uniform sampler2D painted_study : source_color, filter_linear_mipmap, repeat_disable;

varying vec3 normal_mundo;
varying vec3 pd;

void vertex() {
	normal_mundo = normalize(MODEL_NORMAL_MATRIX * NORMAL);
	pd = VERTEX;
}

float grain(vec3 p) {
	return fract(sin(dot(p, vec3(13.941, 71.183, 27.211))) * 15731.743);
}

void fragment() {
	vec3 n = normalize(normal_mundo);
	float key = max(0.0, dot(n, normalize(vec3(-0.53, 0.76, 0.46))));
	float bounce = max(0.0, dot(n, normalize(vec3(0.84, 0.22, -0.49))));
	float fill = max(0.0, dot(n, normalize(vec3(0.21, -0.28, 0.94))));
	vec3 p = vec3(pd.x, pd.y * UV2.y, pd.z);
	float coarse = grain(floor(p * 0.38));
	float fine = grain(floor(p * 0.95));
	float mineral = sin(p.x * 0.31 + p.y * 0.47 + p.z * 0.28 + coarse * 1.1);
	float patina = 0.79 + 0.19 * coarse + 0.12 * fine;
	bool frost = UV2.x > 0.6;
	bool cloth = UV2.x < 0.2;
	patina += (frost ? 0.13 : 0.060) * mineral;
	// Sample two interior material swatches of the painted model sheet.
	if (painted_finish) {
		vec2 origin = cloth ? vec2(1547.0, 333.0) : vec2(351.0, 221.0);
		vec2 tile = 0.5 + 0.5 * sin(vec2(p.x + p.z * 0.7, p.y - p.z * 0.4) * 0.13);
		vec2 uv = (origin + tile * vec2(35.0, 27.0)) / vec2(textureSize(painted_study, 0));
		float painted = dot(texture(painted_study, uv).rgb, vec3(0.21, 0.72, 0.07));
		patina *= mix(0.94, 1.14, smoothstep(0.015, 0.13, painted));
	}
	float glint = pow(max(0.0, dot(n, normalize(vec3(-0.32, 0.48, 0.81)))), frost ? 6.0 : 10.0);
	vec3 diffuse = COLOR.rgb * patina
		* (vec3(0.62, 0.68, 0.75) + vec3(0.58, 0.53, 0.44) * key
		+ vec3(0.16, 0.23, 0.29) * bounce + vec3(0.18, 0.18, 0.16) * fill);
	ALBEDO = diffuse + vec3(0.16, 0.20, 0.24) * glint * (cloth ? 0.09 : (frost ? 0.44 : 0.29));
}
