extends Node3D

# The binding faces +X. Joints run along local +Y and overlap their sockets.
static var _meshes: Dictionary
static var _sculpts: Array[Dictionary] = [{}, {}, {}]
static var _finish: ShaderMaterial
var _surfaces: Dictionary
var bones: Dictionary
var heavy: bool


func build(is_colossus: bool, is_sovereign := false) -> void:
	heavy = is_colossus
	for key in ["hip", "ribcage", "neck", "head", "shoulder_a", "shoulder_b",
			"upper_a", "upper_b", "elbow_a", "elbow_b", "lower_a", "lower_b",
			"hand_a", "hand_b", "thigh_a", "thigh_b", "knee_a", "knee_b",
			"shin_a", "shin_b", "boot_a", "boot_b", "mantle", "hem"]:
		var node := Node3D.new()
		node.name = key
		bones[key] = node
		add_child(node)
	var sculpt := _sculpts[2 if is_sovereign else int(heavy)]
	if sculpt.is_empty():
		if is_sovereign:
			_sculpt_sovereign()
		elif heavy:
			_sculpt_colossus()
		else:
			_sculpt_watch()
		for key in _surfaces:
			var surface: SurfaceTool = _surfaces[key]
			surface.index()
			sculpt[key] = surface.commit()
		_surfaces.clear()
	if _finish == null:
		_finish = ShaderMaterial.new()
		_finish.shader = preload("res://scenes/gelo/material_de_gelo.gdshader")
	var finish := _material_for_mesh()
	for key in sculpt:
		var piece := MeshInstance3D.new()
		piece.mesh = sculpt[key]
		piece.material_override = finish
		piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		(bones[key] as Node3D).add_child(piece)


func _material_for_mesh() -> ShaderMaterial:
	return _finish


func _sculpt_sovereign() -> void:
	pass


func place(key: String, point: Vector3, angles: Vector3 = Vector3.ZERO) -> void:
	var node: Node3D = bones[key]
	node.position = point
	node.rotation = angles


func link(key: String, joint: Vector3, end: Vector3) -> void:
	var node: Node3D = bones[key]
	var direction := (end - joint).normalized()
	var width_axis := Vector3.FORWARD.cross(direction).normalized()
	if width_axis.length_squared() < 0.01:
		width_axis = Vector3.RIGHT
	node.transform = Transform3D(Basis(width_axis, direction * maxf(0.01, joint.distance_to(end)),
		width_axis.cross(direction)), joint)


func _sculpt_watch() -> void:
	var iron := Color("#525a66")
	var steel := Color("#716c63")
	var cloth := Color("#262d38")
	var glove := Color("#3e3935")
	var trim := Color("#7a7667")
	_part("hip", "mail", Vector3(17, 16, 30), Vector3(0, -3, 0), cloth)
	_part("hip", "band", Vector3(17, 5, 31), Vector3(0, 4, 0), glove)
	_part("hip", "bevel", Vector3(2, 5, 5), Vector3(9, 4, 0), trim)
	for depth in [-12.0, 12.0]:
		_part("hip", "lame", Vector3(15, 17, 7), Vector3(0, -9, depth), iron,
			Vector3(0.08 * signf(depth), 0, -0.10))
	_part("ribcage", "cuirass", Vector3(28, 32, 38), Vector3(0, -8, 0), iron, Vector3(0, 0, -0.12))
	_part("ribcage", "cuirass", Vector3(15, 27, 29), Vector3(8, -5, 0), steel, Vector3(0, 0, 0.12))
	for plate in 3:
		_part("ribcage", "band", Vector3(22 - plate * 1.5, 5, 33 - plate * 2),
			Vector3(2, -19 - plate * 4.0, 0), iron.darkened(plate * 0.07))
	_part("neck", "mail", Vector3(13, 1.95, 18), Vector3(0, 0.48, 0), cloth)
	_part("ribcage", "band", Vector3(17, 8, 24), Vector3(0, 7, 0), glove)
	_part("head", "helm", Vector3(20, 24, 22), Vector3(-2.3, 4, 0), cloth)
	_part("head", "mail", Vector3(17, 12, 20), Vector3(-2, -5, 0), cloth)
	_part("head", "helm", Vector3(13, 18, 9), Vector3(-7, 0, 3.8), cloth,
		Vector3(-0.21, 0.17, -0.27))
	_part("head", "helm", Vector3(15, 20, 18), Vector3(3, 4, 0), iron)
	_part("head", "bevel", Vector3(3, 4.2, 15), Vector3(10.4, 6, 0), Color("#151a20"))
	_part("head", "lame", Vector3(4, 9, 15), Vector3(10, 0, 0), steel)
	_part("head", "bevel", Vector3(5, 2, 16), Vector3(9, 9, 0), steel)
	for depth in [-5.8, 5.8]:
		_part("head", "bevel", Vector3(9, 3.2, 4.6), Vector3(8.8, 9, depth), steel,
			Vector3(0, 0.23 * signf(depth), -0.18))
		_part("head", "bevel", Vector3(1.5, 0.8, 2.9), Vector3(11.8, 6.2, depth), Color("#a4b9be"))
		for cut in [-1.7, 1.7]:
			_part("head", "bevel", Vector3(0.9, 4.4, 0.7), Vector3(12.0, -0.5, depth + cut), cloth)
	for depth in [-12.0, 12.0]:
		_part("ribcage", "band", Vector3(18, 8, 8), Vector3(3, 1, depth), steel,
			Vector3(0.1, 0.1, 0.22))
		for rivet in 3:
			_part("ribcage", "bevel", Vector3(3, 2.2, 2.2),
				Vector3(11.3, -1.0 - rivet * 6, depth * (0.84 - 0.12 * rivet)), trim)
	for limb in ["a", "b"]:
		_part("shoulder_" + limb, "pauldron", Vector3(22, 17, 17), Vector3(-1, -1.5, 0), steel)
		_part("shoulder_" + limb, "band", Vector3(16, 5, 15), Vector3(0, -8, 0), iron)
		_part("shoulder_" + limb, "pauldron", Vector3(18, 9, 15), Vector3(0, -6, 1.1), steel.darkened(0.15))
		_part("shoulder_" + limb, "bevel", Vector3(2.1, 2.1, 2.1),
			Vector3(5.8, -4.6, 6.9 if limb == "a" else -6.9), trim)
		_part("upper_" + limb, "mail", Vector3(10, 1.13, 11), Vector3(0, 0.49, 0), cloth)
		_part("upper_" + limb, "lame", Vector3(11, 0.59, 10), Vector3(0, 0.53, 0), iron)
		_part("elbow_" + limb, "pauldron", Vector3(10, 10, 11), Vector3.ZERO, steel)
		_part("lower_" + limb, "lame", Vector3(11, 1.09, 9), Vector3(0, 0.51, 0), iron)
		_part("lower_" + limb, "lame", Vector3(7, 0.71, 9.7), Vector3(1, 0.49, 0), steel)
		_part("lower_" + limb, "band", Vector3(10, 0.14, 10), Vector3(0, 0.84, 0), trim.darkened(0.12))
		_part("hand_" + limb, "bevel", Vector3(8, 10, 8), Vector3.ZERO, glove)
		_part("hand_" + limb, "lame", Vector3(7, 6, 8.5), Vector3(0, 1, 0), iron)
		_part("thigh_" + limb, "mail", Vector3(14, 1.13, 13), Vector3(0, 0.47, 0), cloth)
		_part("thigh_" + limb, "lame", Vector3(14, 0.79, 12), Vector3(1.9, 0.46, 0), iron)
		_part("knee_" + limb, "pauldron", Vector3(12, 12, 12), Vector3(1, 0, 0), steel)
		_part("shin_" + limb, "lame", Vector3(11, 1.20, 11), Vector3(0, 0.52, 0), iron)
		_part("boot_" + limb, "boot", Vector3(22, 12, 12), Vector3(4, -3, 0), glove)
		_part("boot_" + limb, "boot", Vector3(19, 6, 12.5), Vector3(6, -5, 0), iron)
		for plate in 3:
			_part("boot_" + limb, "lame", Vector3(4, 4, 10.3), Vector3(7 + plate * 2.9, -1.0 - plate * 0.74, 0),
				steel.darkened(0.06 * plate), Vector3(0, 0, -0.24))
	_part("hand_a", "bevel", Vector3(3.3, 15, 3.3), Vector3(0, -2, 0), Color("#292524"))
	_part("hand_a", "bevel", Vector3(5, 4, 5), Vector3(0, -10, 0), trim)
	_part("hand_a", "bevel", Vector3(17, 2.8, 4), Vector3(0, 6, 0), steel, Vector3(0, 0, -0.10))
	_part("hand_a", "blade", Vector3(9, 37, 2.8), Vector3(0, 24.5, 0), Color("#9da4a7"))
	_part("hand_a", "blade", Vector3(2.2, 29, 3.0), Vector3(0, 23, 0), Color("#666e73"))
	_part("mantle", "cloth", Vector3(7, 38, 31), Vector3(-2, -15, 0), cloth)
	for fold in 5:
		var depth := (fold - 2) * 6.0
		_part("mantle", "cloth", Vector3(6 + absf(depth) * 0.22, 37, 9),
			Vector3(-0.4 + absf(depth) * 0.14, -14, depth), cloth.lightened(0.055 - fold * 0.011),
			Vector3(depth * 0.009, 0.0, -0.10))
		_part("hem", "cloth", Vector3(4, 27 - fold + (fold % 2) * 11, 9), Vector3(-1.8, -9, depth),
			cloth.lightened(0.053 - fold * 0.012), Vector3(depth * 0.014, 0, -0.12 - fold * 0.06))


func _sculpt_colossus() -> void:
	var stone := Color("#51595d")
	var basalt := Color("#333c43")
	var frost := Color("#829da5")
	var buried_ice := Color("#526e79")
	var rime := Color("#9aa8a8")
	_part("hip", "rock", Vector3(36, 36, 52), Vector3(0, -4, 0), basalt)
	_part("hip", "ice", Vector3(20, 19, 34), Vector3(7, -4, 3), buried_ice, Vector3(0.05, 0.23, 0.31))
	_part("ribcage", "rock", Vector3(73, 56, 80), Vector3(-4, -15, 0), stone, Vector3(-0.12, 0.15, 0.19))
	_part("ribcage", "rock", Vector3(52, 32, 52), Vector3(6, -35, 1), basalt, Vector3(0.11, -0.13, -0.18))
	# Irregular shelves break up the front and each profile of the frozen shale.
	for slab in 4:
		var depth := -21.0 + slab * 14.0
		_part("ribcage", "ice", Vector3(19, 16 - slab * 1.3, 16), Vector3(29 - slab * 1.8, -20 + slab * 6.0, depth),
			frost.darkened(0.10 * slab), Vector3(slab * 0.25, 0.2 - slab * 0.12, 0.45))
	_part("neck", "rock", Vector3(30, 1.95, 32), Vector3(0, 0.49, 0), basalt)
	_part("head", "rock", Vector3(40, 33, 38), Vector3(-1, -1, 0), stone, Vector3(0.07, 0.08, -0.12))
	_part("head", "rock", Vector3(23, 12, 28), Vector3(9, -12, 0), basalt)
	_part("head", "ice", Vector3(25, 11, 43), Vector3(3, 11, 0), frost, Vector3(0, 0.12, -0.28))
	_part("head", "rock", Vector3(12, 10, 28), Vector3(19.2, -8, 0), stone)
	_part("head", "rock", Vector3(8, 12, 8), Vector3(20, 1, -1), basalt)
	for crest in 3:
		_part("head", "ice", Vector3(13, 16 - crest * 2, 15),
			Vector3(-8 - crest * 3, 12 - crest * 4, -9 + crest * 8), frost.darkened(0.14 * crest),
			Vector3(0.22 * crest, 0.42, 0.5 - crest * 0.4))
	for depth in [-9.0, 8.0]:
		_part("head", "bevel", Vector3(5, 6, 9), Vector3(17, 4, depth), basalt, Vector3(0.18 * signf(depth), 0, 0.1))
		_part("head", "bevel", Vector3(4, 2.2, 6.5), Vector3(19.4, 4, depth), Color("#a5c7d1"))
	for limb in ["a", "b"]:
		var weight := 1.0 if limb == "a" else 0.73
		_part("shoulder_" + limb, "rock", Vector3(51, 42, 49) * weight, Vector3(-6, 0, 0), stone)
		_part("shoulder_" + limb, "ice", Vector3(33, 30, 29) * weight, Vector3(-14, 15, 2), frost,
			Vector3(0.28, 0.30, 0.44))
		_part("shoulder_" + limb, "ice", Vector3(23, 24, 34) * weight, Vector3(9, 14, 0), rime,
			Vector3(-0.20, 0.3, -0.23))
		for plate in 3:
			var height := 9 + plate * 6.0
			_part("shoulder_" + limb, "ice", Vector3(17 - plate * 2, 9 + plate * 2, 10) * weight,
				Vector3(-10 - plate * 7.5, height, (12.0 + plate * 1.5) * (1 if limb == "a" else -1)),
				buried_ice.lightened(0.08 * plate), Vector3(0.53, 0.35, -0.20 + plate * 0.25))
		_part("upper_" + limb, "rock", Vector3(36 * weight, 1.18, 33 * weight), Vector3(0, 0.46, 0), basalt)
		_part("upper_" + limb, "ice", Vector3(28 * weight, 0.54, 27 * weight), Vector3(2, 0.40, 1), buried_ice)
		_part("elbow_" + limb, "rock", Vector3(30, 27, 29) * weight, Vector3.ZERO, stone)
		_part("lower_" + limb, "rock", Vector3(39 * weight, 1.18, 37 * weight), Vector3(0, 0.5, 0), stone)
		_part("lower_" + limb, "ice", Vector3(28 * weight, 0.67, 21 * weight), Vector3(3, 0.56, 7), frost,
			Vector3(0.0, 0.22, 0.0))
		_part("hand_" + limb, "rock", Vector3(41, 35, 38) * weight, Vector3(0, 5, 0), basalt)
		for digit in 3:
			_part("hand_" + limb, "ice", Vector3(9, 18 - digit, 11) * weight,
				Vector3((digit - 1) * 10.0, 10, 12) * weight, frost.darkened(0.06 * digit), Vector3(0, 0.20, -0.18 * digit))
		for shard in 3:
			_part("lower_" + limb, "ice", Vector3(16 - shard * 2, 0.29, 14) * weight,
				Vector3(-9 + shard * 7, 0.37 + shard * 0.12, (13 if limb == "a" else -13) * weight),
				frost.darkened(shard * 0.095), Vector3(0, -0.04 * shard, 0))
		_part("thigh_" + limb, "rock", Vector3(39, 1.18, 33), Vector3(0, 0.45, 0), basalt)
		_part("knee_" + limb, "ice", Vector3(32, 29, 34), Vector3(4, 0, 0), buried_ice)
		_part("shin_" + limb, "rock", Vector3(31, 1.20, 32), Vector3(0, 0.44, 0), stone)
		_part("shin_" + limb, "ice", Vector3(17, 0.67, 25), Vector3(9, 0.46, 3), buried_ice)
		_part("boot_" + limb, "boot", Vector3(46, 19, 42), Vector3(10, -0.5, 0), basalt)
		_part("boot_" + limb, "rock", Vector3(30, 14, 38), Vector3(14, -1, 0), stone)
	for plate in 4:
		_part("mantle", "ice", Vector3(25 - plate * 2, 39 - plate * 3, 23),
			Vector3(-9, -14 - plate * 9.0, (plate - 1.5) * 12.0), buried_ice.lightened(plate * 0.055),
			Vector3(0.06 * plate, 0.24 * plate, 0.49 + plate * 0.1))


func _part(parent: String, shape: String, size: Vector3, center: Vector3, color: Color,
		angles := Vector3.ZERO) -> void:
	if not _meshes.has(shape):
		var mesh := _make_mesh(shape)
		_meshes[shape] = mesh.surface_get_arrays(0)
	var arrays: Array = _meshes[shape]
	var material_kind := 0.85 if shape == "ice" else (0.12 if shape in ["cloth", "mail"] else 0.48)
	if not _surfaces.has(parent):
		var destination := SurfaceTool.new()
		destination.begin(Mesh.PRIMITIVE_TRIANGLES)
		_surfaces[parent] = destination
	var surface: SurfaceTool = _surfaces[parent]
	var piece := Basis.from_euler(angles).scaled_local(size)
	var normals := piece.inverse().transposed()
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var source_normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
	var colors: PackedColorArray = arrays[Mesh.ARRAY_COLOR]
	for index in vertices.size():
		surface.set_normal((normals * source_normals[index]).normalized())
		surface.set_color(color * colors[index])
		surface.set_uv2(Vector2(material_kind, 27.0 if size.y < 2.1 else 1.0))
		surface.add_vertex(center + piece * vertices[index])


static func _make_mesh(kind: String) -> ArrayMesh:
	# Profile rings from sole to crown. Their offsets generate wedges, shelves,
	# bevels and breaches without a stack of spherical joints.
	var profile: Array = [
		Vector4(-0.50, 0.36, 0.36, 0.00), Vector4(-0.34, 0.49, 0.48, 0.00),
		Vector4(0.28, 0.50, 0.50, 0.00), Vector4(0.50, 0.32, 0.34, 0.00)]
	var count := 8
	var grain := 0.10
	match kind:
		"blade":
			profile = [Vector4(-0.50, 0.47, 0.46, 0), Vector4(0.14, 0.43, 0.43, 0),
				Vector4(0.39, 0.24, 0.28, -0.06), Vector4(0.50, 0.025, 0.025, -0.13)]
			count = 4
		"boot":
			profile = [Vector4(-0.50, 0.50, 0.48, 0), Vector4(-0.36, 0.50, 0.50, 0),
				Vector4(0.08, 0.46, 0.47, 0), Vector4(0.50, 0.23, 0.43, -0.22)]
		"band":
			profile = [Vector4(-0.5, 0.41, 0.43, 0), Vector4(-0.33, 0.47, 0.49, 0),
				Vector4(0.31, 0.50, 0.50, 0), Vector4(0.50, 0.48, 0.48, 0)]
		"cuirass":
			profile = [Vector4(-0.50, 0.27, 0.34, -0.03), Vector4(-0.20, 0.39, 0.42, 0),
				Vector4(0.20, 0.50, 0.50, 0.05), Vector4(0.49, 0.37, 0.44, -0.055)]
		"helm":
			profile = [Vector4(-0.50, 0.35, 0.37, 0.04), Vector4(-0.32, 0.47, 0.44, 0.07),
				Vector4(0.13, 0.48, 0.50, 0), Vector4(0.43, 0.33, 0.41, -0.065),
				Vector4(0.50, 0.12, 0.20, -0.11)]
			count = 10
		"pauldron":
			profile = [Vector4(-0.50, 0.34, 0.48, 0.10), Vector4(-0.16, 0.50, 0.50, 0),
				Vector4(0.33, 0.38, 0.40, -0.02), Vector4(0.50, 0.24, 0.29, -0.03)]
		"lame":
			profile = [Vector4(-0.5, 0.32, 0.35, -0.01), Vector4(-0.25, 0.45, 0.48, 0.01),
				Vector4(0.32, 0.50, 0.50, 0.04), Vector4(0.5, 0.36, 0.37, 0.06)]
		"rock":
			grain = 0.27
		"ice":
			profile = [Vector4(-0.5, 0.32, 0.28, -0.01), Vector4(-0.29, 0.50, 0.50, 0.02),
				Vector4(0.31, 0.37, 0.42, -0.09), Vector4(0.5, 0.11, 0.17, -0.13)]
			count = 6
			grain = 0.21
		"cloth":
			profile = [Vector4(-0.5, 0.29, 0.47, -0.11), Vector4(-0.28, 0.40, 0.50, -0.07),
				Vector4(0.19, 0.40, 0.41, 0.04), Vector4(0.50, 0.35, 0.37, 0.12)]
			count = 10
			grain = 0.16
	var positions := PackedVector3Array()
	for row in profile.size():
		var ring: Vector4 = profile[row]
		for index in count:
			var angle := TAU * index / count
			var distortion := sin(float(index * 17 + row * 11)) * grain
			var y := ring.x
			if kind in ["rock", "ice", "cloth"]:
				y += distortion * (0.43 if kind != "cloth" or row != 0 else 1.2)
			positions.append(Vector3(ring.w + cos(angle) * ring.y * (1.0 + distortion),
				y, sin(angle) * ring.z * (1.0 + distortion)))
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	surface.set_smooth_group(-1)
	for row in profile.size() - 1:
		for index in count:
			var lower := row * count + index
			var next := row * count + (index + 1) % count
			var shade := 0.90 + sin(float(row * 9 + index * 17)) * grain * 0.39
			_face(surface, positions[lower], positions[lower + count], positions[next], shade)
			_face(surface, positions[next], positions[lower + count], positions[next + count], shade * 0.97)
	for index in range(1, count - 1):
		var top := (profile.size() - 1) * count
		_face(surface, positions[0], positions[index], positions[index + 1], 0.86)
		_face(surface, positions[top], positions[top + index + 1], positions[top + index], 0.96)
	surface.generate_normals()
	return surface.commit()


static func _face(surface: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, tint: float) -> void:
	# Godot front faces use clockwise winding.
	surface.set_color(Color(tint, tint, tint))
	surface.add_vertex(a)
	surface.add_vertex(c)
	surface.add_vertex(b)
