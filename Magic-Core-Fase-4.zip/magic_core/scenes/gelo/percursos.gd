extends RefCounted

const Event := preload("res://scenes/forest/objectives.gd").Event

const STAGES := {
	"gelo1": {
		"art": "porto", "width": 2890.0,
		"ground": [
			[[0, 553], [226, 553], [362, 544], [512, 544], [678, 563], [826, 573], [1000, 573]],
			[[1275, 570], [1435, 570], [1550, 553], [1770, 553], [2040, 534], [2120, 534]],
			[[2250, 538], [2415, 538], [2550, 523], [2890, 523]],
		],
		# x, superfície, largura e material das plataformas de mão única.
		"platforms": [
			[330, 469, 155, "stone"], [1050, 562, 103, "brittle"], [1200, 554, 55, "ice"],
			[2123, 527, 124, "bridge"], [2375, 460, 135, "stone"],
			[920, 465, 101, "stone"], [1082, 432, 99, "bridge"], [1259, 476, 114, "stone"],
		],
		"slippery": [Vector2(375, 487), Vector2(1545, 1657), Vector2(2260, 2385)],
		"water": [Rect2(994, 619, 288, 145), Rect2(2117, 608, 140, 146)],
		"icicles": [],
		# Os elementos em fundo, cenário e primeiro plano têm velocidades de paralaxe próprias.
		"far": [
			["pine", 191, 548, 335], ["pine", 1117, 653, 305], ["arch", 1540, 590, 235],
			["pine", 2320, 576, 305], ["pine", 2730, 586, 290],
		],
		"props": [
			["ivy", 270, 552, 76], ["arch", 406, 543, 203], ["pine", 650, 564, 222],
			["ivy", 954, 573, 46], ["arch", 1558, 553, 175], ["ivy", 2133, 554, 61],
			["pine", 2441, 538, 212], ["wall", 2818, 526, 176],
		],
		"front": [["pine", -54, 595, 226], ["ivy", 929, 607, 77], ["ivy", 2053, 586, 58], ["pine", 2892, 572, 218]],
		"sites": [
			["rest", 1469, 565, "Aquecer-se", "hearth", 66],
			["lanterna", 535, 547, "Acender lanterna", "beacon", 127],
			["farol", 1900, 544, "Acender farol", "beacon", 154],
			["sino", 2720, 523, "Registrar chegada", "tower", 273],
		],
		"tasks": [
			[Event.INTERACT, "lanterna", "Acenda a lanterna do cais."],
			[Event.INTERACT, "farol", "Cruze o lago e acenda o farol da outra margem."],
			[Event.INTERACT, "sino", "Alcance o antigo posto de vigilância."],
		],
		"foes": [
			["VigiaDaGeadaDoCais", 788, 0, 614, 966], ["ColossoDasGeadasDoLago", 1722, 1, 1500, 2008],
		],
	},
	"gelo2": {
		"art": "passo", "width": 3270.0,
		"ground": [
			[[0, 573], [258, 573], [470, 552], [645, 531], [836, 531], [990, 515]],
			[[1142, 508], [1324, 508], [1503, 540], [1697, 540], [1840, 519], [2034, 519]],
			[[2174, 502], [2287, 502], [2438, 468], [2644, 468], [2811, 486], [3270, 486]],
		],
		"platforms": [
			[1043, 510, 61, "ice"], [1406, 445, 138, "stone"],
			[2085, 497, 61, "ice"], [2440, 401, 134, "stone"], [2997, 414, 122, "stone"],
			[1589, 411, 93, "bridge"], [1750, 440, 124, "stone"],
		],
		"wind": [
			[Rect2(926, 320, 246, 230), -38.0, 1.15, 2.25, 2.4, 0.0],
			[Rect2(1970, 314, 263, 230), 62.0, 1.25, 2.6, 2.2, 2.0],
		],
		"folding_bridge": [2034, 517, 140, "bridge"],
		"water": [],
		"icicles": [[735, 319, 531], [1245, 300, 508], [2321, 263, 494]],
		"far": [
			["ivy", 268, 587, 185], ["pine", 887, 575, 245], ["arch", 1550, 590, 333],
			["pine", 2134, 647, 329], ["arch", 2833, 537, 323],
		],
		"props": [
			["cave", 212, 572, 253], ["ivy", 543, 546, 60], ["pine", 940, 524, 148],
			["arch", 1468, 533, 208], ["cave", 1825, 440, 131], ["pine", 1996, 519, 212],
			["arch", 2640, 468, 295], ["ivy", 2875, 488, 72], ["pine", 3190, 487, 170],
		],
		"front": [["ivy", 0, 613, 111], ["pine", 1595, 586, 190], ["ivy", 2400, 521, 68], ["ivy", 3270, 536, 109]],
		"sites": [
			["rest", 1930, 519, "Aquecer-se", "hearth", 58],
			["guincho", 1480, 445, "Girar guincho", "winch", 103],
			["abrigo", 1825, 440, "Abrir esconderijo", "hearth", 31],
			["sino", 3121, 486, "Tocar sino", "bell", 138],
		],
		"tasks": [
			[Event.INTERACT, "guincho", "Suba à torre e gire o guincho do portão."],
			[Event.INTERACT, "sino", "Cruze a ponte restaurada até o posto além do portão."],
		],
		"gate": Vector2(2640, 468),
		"foes": [
			["VigiaDaGeadaDaGarganta", 563, 0, 435, 709],
			["ColossoDasGeadasDoGuincho", 1623, 1, 1512, 1840],
			["VigiaDaGeadaDoPosto", 2865, 0, 2720, 3035],
		],
	},
	"gelo3": {
		"art": "coroa", "width": 3110.0,
		"fault_lines": [1805.0, 1960.0, 2125.0, 2290.0, 2460.0, 2605.0],
		"ground": [
			[[0, 551], [306, 551], [462, 526], [635, 526], [752, 540]],
			[[883, 550], [983, 550], [1102, 529], [1420, 529], [1530, 545], [2010, 545],
				[2180, 529], [2638, 529], [2785, 513], [3110, 513]],
		],
		"platforms": [
			[391, 442, 152, "stone"], [795, 535, 49, "ice"], [1646, 447, 114, "stone"],
			[2715, 432, 122, "stone"],
		],
		"spikes": Rect2(777, 573, 81, 42),
		"water": [],
		"icicles": [[2821, 316, 513]],
		"far": [
			["arch", 320, 600, 418], ["arch", 860, 650, 275], ["arch", 1655, 605, 360],
			["arch", 2319, 631, 410], ["pine", 3050, 554, 275],
		],
		"props": [
			["wall", 258, 554, 276], ["stairs", 435, 532, 119], ["statue", 632, 533, 123],
			["arch", 1355, 530, 302], ["wall", 1777, 544, 268], ["statue", 2268, 535, 168], ["arch", 2694, 523, 277],
		],
		"front": [["ivy", 85, 605, 95], ["ivy", 1021, 592, 65], ["ivy", 2577, 577, 60], ["ivy", 3067, 567, 89]],
		"sites": [
			["rest", 1038, 540, "Aquecer-se", "hearth", 60],
			["braseiro", 1208, 529, "Acender braseiro", "hearth", 97],
			["sino", 2907, 513, "Restaurar selo", "seal", 167],
		],
		"tasks": [
			[Event.INTERACT, "braseiro", "Acenda o braseiro para abrir a fortaleza."],
			[Event.DEFEAT, "SoberanoDaGeada", "Derrote o Senhor do Abismo Gélido."],
		],
		"gate": Vector2(1355, 529),
		"sanctum_gate": Vector2(2694, 523),
		"foes": [
			["ColossoDasGeadasDoAtrio", 528, 1, 444, 699],
			["VigiaDaGeadaDasMuralhas", 1465, 0, 1396, 1531],
			["SoberanoDaGeada", 2154, 2, 1740, 2565],
		],
	},
}
