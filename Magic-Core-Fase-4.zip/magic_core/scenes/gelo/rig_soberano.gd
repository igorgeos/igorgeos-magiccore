extends "res://scenes/forest/rig/creature_motion.gd"

const Body := preload("res://scenes/gelo/corpo_soberano.gd")
const BLADE_LENGTH := 77.7
const VIEW_SIZE := 370.0
const VIEW_CENTER := 131.0
const SHOULDER := Vector2(828, 166)
const ELBOW := Vector2(833, 312)
const GAUNTLET := Vector2(856, 436)
const HIP := Vector2(859, 465)
const KNEE := Vector2(867, 589)
const ANKLE := Vector2(850, 770)
const MANTLE := Vector2(811, 162)
const TORSO := Vector2(865, 347)
const HEAD := Vector2(866, 124)
const LOAD := [
	[Vector2(-10, 3), -0.04, Vector2(-35, -154), Vector2(17, -125), -2.48],
	[Vector2(-4, -4), -0.025, Vector2(8, -208), Vector2(-7, -177), -1.68],
	[Vector2(-14, 6), -0.05, Vector2(-17, -115), Vector2(17, -131), 0.18],
]
const RELEASE := [
	[Vector2(13, 5), 0.045, Vector2(55, -109), Vector2(-32, -127), 0.44],
	[Vector2(9, 11), 0.055, Vector2(40, -75), Vector2(32, -93), 1.62],
	[Vector2(17, 6), 0.05, Vector2(53, -120), Vector2(-26, -119), 0.11],
]

var _model: Body
var _heading := 1.0
var _target_heading := 1.0
var _turn_time := 1.0
var _screen_sign := 1.0
var _projection := 1.0
var _grip := Vector2.ZERO
var _tip := Vector2.ZERO
var _shoulder := Vector2.ZERO
var _weapon_angle := 0.83
var _torso_pitch := 0.0
var _cloth_pitch := 0.0
var _old_grip := Vector2.ZERO
var _old_angle := 0.83
var _bound: bool


func setup(body) -> void:
	animal = body
	heading_for(body.side)
	_target_heading = _heading
	phase = 0.38
	stride = 87.0
	pose.resize(24)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(448, 448)
	viewport.transparent_bg = true
	viewport.own_world_3d = true
	viewport.gui_disable_input = true
	viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	add_child(viewport)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = VIEW_SIZE
	camera.position = Vector3(0, VIEW_CENTER, 325)
	camera.far = 640
	viewport.add_child(camera)
	camera.current = true
	_model = Body.new()
	viewport.add_child(_model)
	_model.build()
	var screen := Sprite2D.new()
	screen.texture = viewport.get_texture()
	screen.position.y = -VIEW_CENTER
	screen.scale = Vector2.ONE * VIEW_SIZE / viewport.size.x
	screen.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	add_child(screen)
	tick(0.0, 0.0)
	_bound = true


func heading_for(direction: float) -> void:
	_heading = 1.0 if direction >= 0 else -1.0


func impact(direction: Vector2, force: float) -> void:
	recoil_speed += Vector2(direction.x * _heading * 76.0, -20.0) * minf(force, 1.6)


func tick(dt: float, travel: float) -> void:
	if mode != animal.state:
		mode = animal.state
		transition = 0.0
		_old_grip = _grip
		_old_angle = _weapon_angle
	transition += dt
	clock = fposmod(clock + dt, 600.0)
	var motion := absf(travel) / maxf(0.001, dt)
	var gait := mode in [Mode.PURSUE, Mode.STRIKE, Mode.RECOVER] and motion > 5
	locomotion = move_toward(locomotion, float(gait), dt * 6.0)
	phase = fposmod(phase - travel * _heading / stride, 1.0)
	recoil_speed += (-87.0 * recoil - 16.0 * recoil_speed) * dt
	recoil += recoil_speed * dt
	_turn(dt)
	var t := clampf(float(animal.age) / maxf(animal.age + animal.time, 0.001), 0.0, 1.0)
	var ready := 0.0
	var swing := 0.0
	if mode == Mode.WINDUP:
		ready = smoothstep(0.0, 0.86, t)
	elif mode == Mode.STRIKE:
		swing = smoothstep(0.02, 0.78 if animal.attack == animal.Move.RAKE else 0.59, t)
		ready = 1.0 - swing
	elif mode == Mode.RECOVER:
		swing = 1.0 - smoothstep(0.00, 0.92, t)
	var wake := sin(PI * t) if animal.awakening else 0.0
	var stagger := sin(PI * sqrt(t)) if mode == Mode.HURT else 0.0
	var fall := smoothstep(0.0, 0.83, t) if mode == Mode.DEAD else 0.0
	var step := sin(phase * TAU) * locomotion
	var tilt := step * 0.026 - wake * 0.04 - stagger * 0.07
	var offset := Vector2(step * 1.9 - fall * 18.0, absf(step) * 3.1 + fall * 58.0) + recoil * 0.37
	var weapon := Body.at(GAUNTLET.x, GAUNTLET.y) + Vector2(step * 13, -wake * 51)
	var support := Vector2(-11.0 - step * 21, -103.0 - wake * 26)
	var angle := 0.83 + step * 0.16 - wake * 2.30
	if ready + swing > 0.0:
		var prepared: Array = LOAD[animal.attack]
		var delivered: Array = RELEASE[animal.attack]
		var prep_weight := ready / (ready + swing)
		var prep_offset: Vector2 = prepared[0]
		var hit_offset: Vector2 = delivered[0]
		var prep_grip: Vector2 = prepared[2]
		var strike_grip: Vector2 = delivered[2]
		var prep_support: Vector2 = prepared[3]
		var strike_support: Vector2 = delivered[3]
		offset += prep_offset * ready + hit_offset * swing
		tilt += prepared[1] * ready + delivered[1] * swing
		if animal.rupture:
			prep_grip.x -= 12.0
			prep_support.x += 15.0
		var strength := ready + swing
		weapon = weapon.lerp(strike_grip.lerp(prep_grip, prep_weight), strength)
		support = support.lerp(strike_support.lerp(prep_support, prep_weight), strength)
		angle = lerp_angle(angle, lerpf(prepared[4], delivered[4], 1.0 - prep_weight), strength)
	weapon += Vector2(-32, 82) * fall + recoil * 0.30
	angle = lerp_angle(angle, 0.15, fall)
	_torso_pitch = clampf(tilt, -0.07, 0.07) + fall * 1.19
	_cloth_pitch = lerpf(_cloth_pitch, step * 0.19 + swing * 0.25 + fall * 0.13, 1.0 - exp(-8.0 * dt))
	var static_profile := ready + swing + wake + stagger + fall + locomotion < 0.018 and recoil.length() < 1.2
	_model.set_profile_pose(static_profile)
	if static_profile:
		_grip = Body.at(GAUNTLET.x, GAUNTLET.y)
		_weapon_angle = 0.83
		_shoulder = Body.at(SHOULDER.x, SHOULDER.y)
	else:
		if _bound:
			var blend := smoothstep(0.0, 0.085, transition)
			weapon = _old_grip.lerp(weapon, blend)
			angle = lerp_angle(_old_angle, angle, blend)
		_assemble(weapon, support, angle, offset, step, fall)
	_model.pose("sword", _grip, _weapon_angle - PI * 0.5)
	_tip = _grip + Vector2.RIGHT.rotated(_weapon_angle) * BLADE_LENGTH
	pose[8] = Vector2(_tip.x * _screen_sign, _tip.y)
	pose[12] = Vector2(support.x * _screen_sign, support.y)
	modulate = Color.WHITE.lerp(Color("#edd6ce"), clampf(animal.receiver.flash * 1.5, 0.0, 0.23))
	if mode == Mode.DEAD:
		modulate.a = 1.0 - smoothstep(0.79, 1.0, t)


func _turn(dt: float) -> void:
	var desired: float = animal.side
	if desired != _target_heading:
		_target_heading = desired
		_turn_time = 0.0
	_turn_time = minf(1.0, _turn_time + dt / 0.25)
	if _turn_time >= 0.5:
		heading_for(_target_heading)
	_projection = 1.0 - 0.53 * sin(PI * _turn_time)
	_screen_sign = _heading * _projection
	_model.scale.x = _screen_sign


func _assemble(weapon: Vector2, support: Vector2, angle: float, offset: Vector2, step: float, fall: float) -> void:
	var torso := Body.at(TORSO.x, TORSO.y)
	var hip := Body.at(HIP.x, HIP.y)
	_model.pose("torso", torso + offset, _torso_pitch)
	_model.pose("head", _lean(Body.at(HEAD.x, HEAD.y), torso, offset), _torso_pitch * 0.58)
	_model.pose("cape", _lean(Body.at(MANTLE.x, MANTLE.y), torso, offset), _torso_pitch * 0.74 + _cloth_pitch)
	_shoulder = _lean(Body.at(SHOULDER.x, SHOULDER.y), torso, offset)
	var elbow := Body.at(ELBOW.x, ELBOW.y)
	var grip := Body.at(GAUNTLET.x, GAUNTLET.y)
	var shoulder := Body.at(SHOULDER.x, SHOULDER.y)
	_grip = _arm("a", _shoulder, weapon, shoulder.distance_to(elbow), elbow.distance_to(grip),
		(ELBOW - SHOULDER).angle(), (GAUNTLET - ELBOW).angle(), 1.0)
	_weapon_angle = angle
	_arm("b", _lean(Vector2(5, -177), torso, offset), support, 28.5, 36.6, 1.35, 1.06, 1.0)
	for limb in 2:
		var mark := "a" if limb == 0 else "b"
		var home := Body.at(ANKLE.x, ANKLE.y) + Vector2(7 if limb == 0 else -8, 0)
		var gait_phase := fposmod(phase + limb * 0.5, 1.0)
		var gait := step_offset(gait_phase, 0.66, 15.0) * locomotion * (1.0 - fall)
		var ankle := home + gait + Vector2((22 if limb == 0 else -18) * fall, 0)
		var socket := _lean(hip + Vector2(3 if limb == 0 else -4, 0), torso, offset)
		var knee := _joint(socket, ankle, 36.0, 51.0, -1.0)
		_model.pose("thigh_" + mark, socket, (knee - socket).angle() - (KNEE - HIP).angle())
		_model.pose("shin_" + mark, knee, (ankle - knee).angle() - (ANKLE - KNEE).angle())
		_model.pose("boot_" + mark, ankle, -gait.y * 0.014 + fall * (0.30 if limb == 0 else -0.20))


func _lean(point: Vector2, center: Vector2, offset: Vector2) -> Vector2:
	return center + (point - center).rotated(_torso_pitch) + offset


func _arm(mark: String, shoulder: Vector2, goal: Vector2, upper: float, lower: float,
		bind_upper: float, bind_lower: float, bend: float) -> Vector2:
	var reach := shoulder + (goal - shoulder).limit_length(upper + lower - 0.02)
	var joint := _joint(shoulder, reach, upper, lower, bend)
	_model.pose("upper_" + mark, shoulder, (joint - shoulder).angle() - bind_upper)
	_model.pose("lower_" + mark, joint, (reach - joint).angle() - bind_lower)
	return reach


func _joint(origin: Vector2, end: Vector2, first: float, second: float, bend: float) -> Vector2:
	var axis := origin.direction_to(end)
	var distance := maxf(origin.distance_to(end), 0.05)
	var stretch := maxf(1.0, distance / (first + second - 0.02))
	first *= stretch
	second *= stretch
	var length := (first * first - second * second + distance * distance) / (2.0 * distance)
	return origin + axis * length + axis.orthogonal() * bend * sqrt(maxf(0.0, first * first - length * length))


func attack_point(index: int) -> Vector2:
	var point := _tip if index == 8 else (_shoulder if index == 5 else _grip)
	return to_global(Vector2(point.x * _screen_sign, point.y))
