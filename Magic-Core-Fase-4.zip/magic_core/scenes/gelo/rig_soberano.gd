extends "res://scenes/forest/rig/creature_motion.gd"

const STEEL := Color("#687984")
const EDGE := Color("#aabdc4")
const DARK := Color("#202932")
const BRONZE := Color("#82725b")
const FROST := Color("#9fcfe2")

var _accents: Node2D


func setup(body) -> void:
	super(body)
	skin.modulate = Color("#afc4d9")
	_accents = Node2D.new()
	add_child(_accents)
	_accents.draw.connect(_draw_accents)
	_accents.queue_redraw()


func tick(dt: float, travel: float) -> void:
	super(dt, travel)
	if is_instance_valid(_accents):
		_accents.queue_redraw()


func guardiao() -> void:
	var progress := clampf(float(animal.age) / maxf(animal.age + animal.time, 0.001), 0.0, 1.0)
	var gait := sin(phase * TAU) * locomotion
	var ready := 0.0
	var attack_pose := 0.0
	if mode == Mode.WINDUP:
		ready = smoothstep(0.0, 0.81, progress)
	elif mode == Mode.STRIKE:
		attack_pose = smoothstep(0.0, 0.54 if animal.attack == animal.Move.STOMP else 0.76, progress)
		ready = 1.0 - attack_pose
	elif mode == Mode.RECOVER and not animal.awakening:
		attack_pose = 1.0 - smoothstep(0.05, 0.98, progress)
	var raising := sin(PI * progress) if animal.awakening else 0.0
	var stagger := sin(PI * sqrt(progress)) if mode == Mode.HURT else 0.0
	var slam: bool = animal.attack == animal.Move.STOMP
	var rush: bool = animal.attack == animal.Move.CHARGE
	var push := 21.0 if rush else 13.0
	torso(Vector2(ready * 12.0 - attack_pose * push + stagger * 13.0,
		absf(gait) * 3.5 + sin(clock * 1.8) - raising * 11.0 +
		attack_pose * (34.0 if slam else 7.0) + stagger * 12.0),
		0.22 * ready - (0.36 if slam or rush else 0.29) * attack_pose + 0.24 * stagger,
		0.13 * ready - 0.15 * raising)
	foot(13, phase, 0.68, 15.0, 1.0)
	foot(17, fposmod(phase + 0.5, 1.0), 0.68, 17.0, 1.0)

	var grip := pose[7] + Vector2(gait * 12.0, -raising * 23.0)
	var chamber := Vector2(-16, -133)
	var finish := Vector2(-96, -91)
	var chamber_angle := 1.95
	var finish_angle := -0.46
	if slam:
		chamber = Vector2(-40, -180) if animal.rupture else Vector2(-65, -181)
		finish = Vector2(-74, -51)
		chamber_angle = 1.30
		finish_angle = -1.28
	elif rush:
		chamber = Vector2(-29, -104)
		finish = Vector2(-110, -105)
		chamber_angle = 0.42
		finish_angle = 0.08
	grip = grip.lerp(chamber, ready).lerp(finish, attack_pose)
	grip = grip.lerp(Vector2(-52, -18), collapse)
	chain(5, 6, 7, grip)
	var angle := lerpf(lerpf(-0.96 + gait * 0.18 + raising * 0.83, chamber_angle, ready),
		finish_angle, attack_pose)
	angle = lerpf(angle, -0.12, collapse)
	pose[8] = pose[7] + Vector2.LEFT.rotated(angle) * 74.0
	arm(9, -0.12 * gait + 0.62 * ready - 0.43 * attack_pose,
		-0.16 * gait + 1.0 * ready - 0.64 * attack_pose, 0.35 * raising)
	pose[22].x += 8.0 * attack_pose - 4.0 * ready + 2.0 * gait
	pose[22].y -= 4.0 * attack_pose


func _draw_accents() -> void:
	# Coordinates follow the same wrist and blade tip used for hit detection.
	var axis := pose[7].direction_to(pose[8])
	var blade := Transform2D(axis, axis.orthogonal(), pose[7])
	_accents.draw_set_transform_matrix(blade)
	_poly([Vector2(-17,-3), Vector2(10,-4), Vector2(14,4), Vector2(-17,4)], DARK)
	_poly([Vector2(8,-13), Vector2(14,-11), Vector2(16,12), Vector2(7,14)], BRONZE)
	_poly([Vector2(13,-8), Vector2(60,-8), Vector2(73,-3), Vector2(74,1),
		Vector2(63,8), Vector2(16,8)], DARK)
	_poly([Vector2(16,-6), Vector2(60,-6), Vector2(72,-1), Vector2(62,6), Vector2(17,6)], STEEL)
	_accents.draw_line(Vector2(18,-5), Vector2(59,-5), EDGE, 1.7, true)
	_accents.draw_line(Vector2(20,1), Vector2(43,1), Color(FROST, 0.62 if animal.angry else 0.29), 1.5, true)

	var neck := pose[3].direction_to(pose[4])
	_accents.draw_set_transform_matrix(Transform2D(-neck.orthogonal(), neck, pose[4] + neck * 4.0))
	_poly([Vector2(-20,-4), Vector2(-22,13), Vector2(-12,6), Vector2(-7,18),
		Vector2(0,9), Vector2(9,16), Vector2(12,6), Vector2(19,11), Vector2(16,-6)], DARK)
	_poly([Vector2(-18,-3), Vector2(-20,10), Vector2(-11,4), Vector2(-7,15),
		Vector2(0,6), Vector2(8,13), Vector2(11,3), Vector2(16,8), Vector2(14,-4)], BRONZE)
	_accents.draw_line(Vector2(-16,-1), Vector2(12,-2), Color("#a68e72"), 1.4, true)
	_accents.draw_line(Vector2(-14,-12), Vector2(-6,-12), Color(FROST, 0.75 if animal.angry else 0.48), 2, true)


func _poly(points: Array[Vector2], tint: Color) -> void:
	_accents.draw_colored_polygon(PackedVector2Array(points), tint)


func attack_point(index: int) -> Vector2:
	return to_global(pose[index])
