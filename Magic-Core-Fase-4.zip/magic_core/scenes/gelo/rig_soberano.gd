extends "res://scenes/gelo/rig_de_gelo.gd"

const SovereignBody := preload("res://scenes/gelo/corpo_soberano.gd")
const LOAD := [
	[Vector2(-0.07, 0.025), -0.25, Vector2(-0.24, -0.68), Vector2(0.16, -0.53), -1.32],
	[Vector2(-0.045, -0.045), -0.16, Vector2(0.12, -1.02), Vector2(-0.13, -0.91), -0.18],
	[Vector2(-0.11, 0.10), -0.24, Vector2(-0.16, -0.52), Vector2(0.16, -0.51), 1.36],
]
const RELEASE := [
	[Vector2(0.10, 0.085), 0.42, Vector2(0.53, -0.49), Vector2(-0.24, -0.51), 2.05],
	[Vector2(0.09, 0.19), 0.49, Vector2(0.32, -0.34), Vector2(0.20, -0.42), 2.87],
	[Vector2(0.12, 0.09), 0.41, Vector2(0.40, -0.57), Vector2(-0.18, -0.44), 1.39],
]


func _create_model() -> Body:
	return SovereignBody.new()


func _build_model() -> void:
	model.build(true, true)


func _arm_holds_blade() -> bool:
	return true


func _weapons_reach() -> float:
	return 76.0


func _assemble(sprint: float, cycle: float, load_amount: float, strike_amount: float, death: float) -> void:
	var blade_angle := 2.53 + sin(phase * TAU) * locomotion * 0.16
	var pose_weight := maxf(load_amount, strike_amount)
	var t := clampf(float(animal.age) / maxf(animal.age + animal.time, 0.001), 0.0, 1.0)
	var recoil_pose := sin(PI * sqrt(t)) if mode == Mode.HURT else 0.0
	var awakening := sin(PI * t) if animal.awakening else 0.0

	# The inherited gait keeps the ankles on the ground while the hips and sword
	# arm shift into a separate, boss-specific pose.
	super(sprint, cycle, 0.0, 0.0, death)
	var near: Vector2 = pose[7]
	var far: Vector2 = pose[11]
	var offset := Vector2(-h * 0.08 * recoil_pose, h * 0.07 * recoil_pose - 9.0 * awakening)
	var twist := -0.21 * recoil_pose - 0.14 * awakening

	if pose_weight > 0.0:
		var load_pose: Array = LOAD[animal.attack]
		var hit_pose: Array = RELEASE[animal.attack]
		var drive := strike_amount / (load_amount + strike_amount)
		var windup: Vector2 = load_pose[2]
		var finish: Vector2 = hit_pose[2]
		var support_start: Vector2 = load_pose[3]
		var support_end: Vector2 = hit_pose[3]
		if animal.rupture:
			windup.x -= 0.14
			support_start.x += 0.22
		var load_offset: Vector2 = load_pose[0]
		var hit_offset: Vector2 = hit_pose[0]
		offset += load_offset.lerp(hit_offset, drive) * h * pose_weight
		twist += lerpf(load_pose[1], hit_pose[1], drive) * pose_weight
		near = near.lerp(windup.lerp(finish, drive) * h, pose_weight)
		far = far.lerp(support_start.lerp(support_end, drive) * h, pose_weight)
		blade_angle = lerpf(blade_angle, lerpf(load_pose[4], hit_pose[4], drive), pose_weight)
	near += Vector2(-14, -30) * awakening
	far += Vector2(16, -22) * awakening

	var hips := pose[0]
	for index in [0, 1, 2, 5, 9, 13, 17]:
		pose[index] = hips + (pose[index] - hips).rotated(twist) + offset
	_tilt += twist
	_arm(5, pose[5], near, 0.247, 0.255)
	_arm(9, pose[9], far, 0.205, 0.22)
	_blade_angle = lerpf(blade_angle, 1.45, death) - 1.78 * awakening
