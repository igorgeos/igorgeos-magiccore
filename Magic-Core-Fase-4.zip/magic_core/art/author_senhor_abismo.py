"""Rebuild the articulated ice boss: blender -b -t 4 --python art/author_senhor_abismo.py -- [asset.glb] [atlas.png]."""
from pathlib import Path
import math
import random
import sys
from collections import defaultdict

import bmesh
import bpy
from mathutils import Vector

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
project = Path(__file__).resolve().parents[1]
destination = Path(args[0]) if args else project / "assets/gelo/senhor_abismo.glb"
atlas_file = Path(args[1]) if len(args) > 1 else project / "art/material_abismo_atlas.png"
destination.parent.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
rng = random.Random(928340)
TAU = 2 * math.pi
atlas = bpy.data.images.load(str(atlas_file)) if atlas_file.is_file() else None


def rgb(value):
    channels = [int(value[i:i+2], 16)/255 for i in (0, 2, 4)]
    return tuple(c / 12.92 if c <= .04045 else ((c + .055) / 1.055)**2.4 for c in channels) + (1.,)


def mat(name, tone, metal=0., rough=.55, glow=0., enamel=False, quadrant=None):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = rgb(tone)
    material.use_backface_culling = not enamel
    nodes = material.node_tree.nodes
    pbr = nodes.get("Principled BSDF")
    pbr.inputs["Base Color"].default_value = material.diffuse_color
    pbr.inputs["Metallic"].default_value = metal
    pbr.inputs["Roughness"].default_value = rough
    if glow:
        pbr.inputs["Emission Color"].default_value = material.diffuse_color
        pbr.inputs["Emission Strength"].default_value = glow
    if atlas is not None and quadrant:
        texture = nodes.new("ShaderNodeTexImage")
        texture.image = atlas
        material.node_tree.links.new(texture.outputs["Color"], pbr.inputs["Base Color"])
    return material


steel = mat("Aço azul forjado", "28354b", .54, .59)
steel_hi = mat("Aço azulado das placas", "334765", .58, .53)
shadow = mat("Malha enegrecida", "101926", .29, .64)
joint = mat("Articulação escura", "171c2a", .24, .53)
edge = mat("Prata martelada", "9bafc6", .60, .43)
edge_dark = mat("Prata envelhecida", "5f748c", .59, .47)
gold = mat("Bronze antigo gravado", "ad8555", .64, .42)
recess = mat("Entalhes da armadura", "09121f", .30, .60)
fur = mat("Pelagem albina", "eef5ff", 0., .75)
fur_mid = mat("Pelagem prateada", "a4b6ce", 0., .77)
fur_dark = mat("Pelagem sombreada", "62758f", 0., .75)
wine = mat("Tecido vinho", "52223f", 0., .86, enamel=True)
wine_hi = mat("Fibras vinho", "733556", 0., .85, enamel=True)
purple = mat("Tecido ameixa", "3f1d3b", 0., .82, enamel=True)
embroidery = mat("Floco bordado", "a995bb", .08, .77)
ivory = mat("Crânios antigos", "c8a887", .03, .63)
eye = mat("Olhos ciano", "38bfff", .05, .22, 2.35)
hot = mat("Espinha glacial luminosa", "a5e8ff", .1, .27, 1.3)
ice = mat("Cristal glacial", "438de9", .48, .31, .19)
ice_shade = mat("Cristal glacial escuro", "194a9b", .52, .30)
ice_edge = mat("Aresta glacial", "6fb9ff", .45, .26, .55)
t_head = mat("Estudo pintado do elmo", "2c415a", .48, .51, quadrant="head")
t_chest = mat("Estudo pintado da couraça", "314b69", .44, .54, quadrant="chest")
t_fur = mat("Estudo de pelagem", "becadd", 0., .78, quadrant="fur")
t_cloth = mat("Estudo de tecido bordado", "582240", 0., .84, enamel=True, quadrant="cloth")
quadrants = {m.name: q for m, q in ((t_head, (0, .5)), (t_chest, (.5, .5)),
                                    (t_fur, (0, 0)), (t_cloth, (.5, 0)))}


def bvec(p):
    x, y, z = p
    return (x, -z, y)


class Part:
    def __init__(self, name):
        self.name = name
        self.verts, self.faces, self.mats, self.uvs, self.smooth = [], [], [], [], []

    def add(self, verts, faces, material, smooth=True, uv=None):
        base = len(self.verts)
        self.verts.extend(verts)
        self.faces.extend(tuple(base + i for i in f) for f in faces)
        self.mats.extend(material if isinstance(material, list) else [material] * len(faces))
        self.smooth.extend([smooth] * len(faces))
        if uv is None:
            uv = [((z + 45) / 90, (y + 55) / 120) for x, y, z in verts]
        self.uvs.extend(uv)

    def create(self, parent):
        mesh = bpy.data.meshes.new(self.name + "_mesh")
        mesh.from_pydata([bvec(p) for p in self.verts], [], self.faces)
        uv = mesh.uv_layers.new(name="Superfícies")
        material_indices = {}
        for polygon, material, smooth in zip(mesh.polygons, self.mats, self.smooth):
            if material.name not in material_indices:
                material_indices[material.name] = len(mesh.materials)
                mesh.materials.append(material)
            polygon.material_index = material_indices[material.name]
            polygon.use_smooth = smooth
            for index in polygon.loop_indices:
                u, v = self.uvs[mesh.loops[index].vertex_index]
                quad = quadrants.get(material.name)
                if quad is not None:
                    u = quad[0] + .027 + min(1, max(0, u)) * .446
                    v = quad[1] + .027 + min(1, max(0, v)) * .446
                uv.data[index].uv = u, v
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()
        mesh.validate()
        mesh.update()
        socket = bpy.data.objects.new(self.name, None)
        bpy.context.collection.objects.link(socket)
        socket.parent = parent
        item = bpy.data.objects.new(self.name + "_geometry", mesh)
        bpy.context.collection.objects.link(item)
        item.parent = socket
        return socket, item


def rings(part, profiles, material, count=20, smooth=True):
    # Y, center X, center Z, radial sizes X and Z; bevels define hard silhouettes.
    verts = [(cx + rx * math.cos(a * TAU / count), y, cz + rz * math.sin(a * TAU / count))
             for y, cx, cz, rx, rz in profiles for a in range(count)]
    faces = [tuple(range(count - 1, -1, -1))]
    for q in range(len(profiles) - 1):
        for j in range(count):
            bottom = q * count + j
            nextv = q * count + (j + 1) % count
            faces.append((bottom, nextv, nextv + count, bottom + count))
    faces.append(tuple(range((len(profiles) - 1)*count, len(profiles)*count)))
    part.add(verts, faces, material, smooth)


def ellip(part, center, radius, material, segments=16, levels=9):
    cx, cy, cz = center
    rx, ry, rz = radius
    profiles = []
    for r in range(levels):
        angle = math.pi * (.015 + .97 * r / (levels - 1))
        profiles.append((cy + math.cos(angle)*ry, cx, cz, math.sin(angle)*rx, math.sin(angle)*rz))
    rings(part, profiles, material, segments)


def strand(part, points, radii, material, sides=7, smooth=True):
    pts = list(map(Vector, points))
    verts = []
    direction = (pts[-1] - pts[0]).normalized()
    hint = Vector((0, 0, 1)) if abs(direction.z) < .89 else Vector((1, 0, 0))
    for k, (point, radius) in enumerate(zip(pts, radii)):
        tangent = (pts[min(k+1,len(pts)-1)] - pts[max(k-1,0)]).normalized()
        up = tangent.cross(hint).normalized()
        if up.length_squared < 1e-6:
            up = tangent.cross(Vector((0,1,0))).normalized()
        right = tangent.cross(up).normalized()
        rx, ry = radius if isinstance(radius, tuple) else (radius, radius)
        for j in range(sides):
            angle = TAU * j / sides
            verts.append(tuple(point + up * (rx * math.cos(angle)) + right * (ry * math.sin(angle))))
    faces = [tuple(range(sides - 1, -1, -1))]
    for k in range(len(pts)-1):
        for j in range(sides):
            a = k*sides+j
            b = k*sides+(j+1)%sides
            faces.append((a,b,b+sides,a+sides))
    faces.append(tuple(range((len(pts)-1)*sides,len(pts)*sides)))
    part.add(verts, faces, material, smooth)


def plate(part, points, bump, thickness, shell=steel, border=edge_dark, thin=1., uv_area=(0,0,1,1)):
    """Cambered shield plate with a raised center and closed back."""
    front = [Vector(p) for p in points]
    middle = sum(front, Vector()) / len(front)
    middle.x += bump
    back = [tuple(p - Vector((thickness, 0, 0))) for p in front]
    n = len(front)
    arr = [tuple(v) for v in front] + [tuple(middle)] + back
    faces = [(i,(i+1)%n,n) for i in range(n)]
    faces += [(i,n+1+i,n+1+(i+1)%n,(i+1)%n) for i in range(n)]
    faces.append(tuple(range(n+1,2*n+1)))
    minz, maxz = min(v[2] for v in arr), max(v[2] for v in arr)
    miny, maxy = min(v[1] for v in arr), max(v[1] for v in arr)
    left, bottom, right, top = uv_area
    uv = [(left+(right-left)*(v[2]-minz)/(maxz-minz),
           bottom+(top-bottom)*(v[1]-miny)/(maxy-miny)) for v in arr]
    part.add(arr, faces, shell, True, uv)
    if border:
        rim = [tuple(p + Vector((.38,0,0))) for p in front]
        strand(part, rim + [rim[0]], [thin]*(n+1), border, sides=6)


def stripe(part, points, radius=.85, material=gold):
    strand(part, points, [radius]*len(points), material, sides=6)


def skull(part, pos, large=True):
    x,y,z = pos
    mult = 1 if large else .81
    ellip(part,(x,y,z),(4.7*mult,5.2*mult,4.45*mult),ivory)
    rings(part,[(y-7*mult,x+.8,z,2,2.9),(y-5*mult,x+.9,z,2.6,3.45),(y-2*mult,x+.6,z,2.8,3.75)],ivory,14)
    for side in (-1,1):
        ellip(part,(x+4.26*mult,y+.3,z+1.65*mult*side),(1.18,1.35,1.22),recess,12,7)
        ellip(part,(x+4.4*mult,y-2.15,z+.46*side),(.48,.72,.43),recess,10,6)
        stripe(part,[(x+3.4,y-4.4,z+side*.95),(x+3.2,y-6.1,z+side*.95)],.23,recess)


keys = "torso head cape hem upper_a upper_b lower_a lower_b thigh_a thigh_b shin_a shin_b boot_a boot_b sword".split()
parts = {key:Part(key) for key in keys}
p = parts["torso"]
rings(p,[(-17,0,0,15,20),(-11,0,0,18,24),(-4,1,0,21,28),(7,2,0,19,24),(16,1,0,21,24),
         (28,0,0,23,28),(39,-1,0,23,32),(47,-2,0,21,34),(54,-2,0,17,28),(59,-1,0,10,14)],shadow,24)
rings(p,[(0,1,0,17,22),(7,1,0,18,23),(15,1,0,18,24),(27,0,0,22,27),
         (43,-1,0,23,33),(49,-1,0,21,30),(55,-1,0,13,22)],steel,26)
# Gorget and overlapping chevrons of the breastplate.
rings(p,[(44,0,0,13,13),(48,0,0,15,15),(51,0,0,15,15),(56,0,0,13,12),
         (61,0,0,11,10),(66,0,0,10,9.5)],steel_hi)
rings(p,[(59,0,0,11.5,10.3),(61,0,0,11,10),(62,0,0,10,9.7)],edge_dark)
plate(p,[(14,53,-24),(18,50,-27),(23,37,-19),(24,26,0),
         (23,37,19),(18,50,27),(14,53,24),(23,44,0)],6.5,3.2,t_chest if atlas else steel_hi,gold,1.0,(.10,.47,.90,.94))
for idx,(y,width,depth) in enumerate(((32,18,21),(21,17,20),(11,18,19))):
    plate(p,[(depth-3,y+7,-width),(depth,y+4,-width+3),(depth+3,y-5,0),
             (depth,y+4,width-3),(depth-3,y+7,width),(depth+1,y+9,0)],2,3,t_chest if atlas else steel,gold if idx==0 else edge_dark,.72,
          (.16,.33-idx*.107,.84,.55-idx*.107))
for sign in (-1,1):
    stripe(p,[(24,41,12*sign),(25,36,9*sign),(27,33,5*sign),(27,36,3*sign),(26,38,6*sign)],.7,gold)
    stripe(p,[(15,46,26*sign),(18,38,27*sign),(17,27,22*sign),(18,17,20*sign)],.72,edge_dark)
    for k in range(3):
        y = 8 - k*8
        plate(p,[(13,y+1,sign*14),(12,y+4,sign*24),(13,y-8,sign*26),
                 (16,y-13,sign*18),(18,y-7,sign*12)],1.5,3,steel_hi,edge_dark,.78)
    skull(p,(18,51,25*sign),sign>0)
    for i in range(3):
        stripe(p,[(20-i*.3,43,sign*(25+i*2.4)),(22-i*.5,36-i*2.4,sign*(27+i*2.1)),
                  (20-i*.6,33-i*3.1,sign*(28+i*2.1))],.55,gold)
rings(p,[(-7,0,0,21,27),(-5,0,0,22,28),(1,0,0,22,28),(3,0,0,21,27)],gold)
rings(p,[(-5,0,0,22.5,28.1),(-4,0,0,23,28.2),(-1,0,0,23,28.2),(1,0,0,22.5,28.1)],shadow)
plate(p,[(22,3,-7),(24,0,-9),(25,-8,0),(24,0,9),(22,3,7),(23,6,0)],2.5,4,steel_hi,gold,.9)
stripe(p,[(21,-13,-8),(23,-28,-8),(23,-41,-5),(23,-51,-2)],1.0,embroidery)
panel=[(20,-6,-9),(23,-25,-8),(22,-44,-9),(21,-50,-5),(22,-45,-2),(22,-58,1),
       (21,-46,4),(22,-51,7),(23,-25,10),(20,-6,9)]
p.add(panel,[tuple(range(len(panel)))],wine,True)

p=parts["head"]
rings(p,[(-13,4,0,6.5,7),(-9,4,0,9.5,9.5),(-3,3,0,12,12),(4,1,0,13.8,13),
         (11,0,0,14,13),(17,-.7,0,13,11.8),(22,-1.5,0,9,8),(25,-2.8,0,4,5.5)],steel,22)
plate(p,[(9,12,-12),(13,9,-9.5),(15,5,-2),(16,5,0),(15,5,2),(13,9,9.5),
         (9,12,12),(13,3,12),(10,-8,8),(12,-16,0),(10,-8,-8),(13,3,-12)],3,1.6,
      t_head if atlas else shadow,None,uv_area=(.22,.13,.78,.66))
for sign in (-1,1):
    stripe(p,[(11,13,sign*12),(15,8,sign*6),(17,5,sign*1.65)],1.65,edge)
    stripe(p,[(13.7,8.7,sign*9.5),(15.4,7.7,sign*5.5),(16.8,5.3,sign*2.25)],1.15,eye)
    stripe(p,[(11,1,sign*10),(12,-6,sign*5),(14.7,-12,sign*1.5)],1.1,edge_dark)
    strand(p,[(-8,9,sign*8),(-5,19,sign*12),(-9,28,sign*13),(-7,42,sign*15),
              (-4,49,sign*16)],[3.5,3.3,2.6,1.35,.05],edge,9)
    strand(p,[(4,12,sign*7),(5,20,sign*8.3),(3,27,sign*9),(5,37,sign*10)],
           [2.7,2.35,1.43,.08],edge_dark,9)
    strand(p,[(-10,6,sign*9),(-11,15,sign*12.5),(-13,21,sign*14)],
           [2.4,1.9,.08],edge_dark,8)
strand(p,[(14,2,0),(15,11,0),(13,20,0),(12,29,0),(10,38,0)],[2.2,2.4,2.15,1.5,.08],edge,9)
stripe(p,[(17,6,0),(16,-1,0),(14.5,-13,0)],.94,edge_dark)

for side, marker in ((1,"a"),(-1,"b")):
    p = parts["upper_"+marker]
    rings(p,[(-42,0,0,7.4,7.9),(-38,0,0,9,9),(-28,0,0,10,10),(-18,0,0,11,10.5),
             (-8,-1,side,13,13),(-2,-2,side*2,12,12),(5,-3,side*2,7.6,8)],joint,18)
    # Pauldrons have curved cross-sections, an inner lip and sloped outer cap.
    rings(p,[(-18,-2,side*3,15,13),(-14,-2,side*4,17,15.7),(-8,-3,side*6,18,16),
             (-2,-4,side*6,18.5,15),(6,-5,side*5,15,12),(10,-5,side*4,10,10),
             (12,-5,side*4,4,8)],steel,24)
    # Overlapping shield plates with pointed outer hems and etched borders.
    for row in range(3):
        y=6-7*row
        plate(p,[(7,y+4,-6*side),(11,y+5,2*side),(10,y+2,12*side),
                 (5,y-4,20*side),(10,y-8,15*side),(14,y-7,7*side),(14,y-4,-1*side)],
              2.3,1.7,t_chest if atlas and row==0 else steel_hi,
              gold if row==0 else edge_dark,.74,(.04,.61,.39,.91))
    for row in range(3):
        off=row*5
        line=[]
        for i in range(13):
            theta=math.pi * i/12
            line.append((-4+math.cos(theta)*(19-row*1.6), -7-off-math.sin(theta)*3.1,
                         side*(5+math.sin(theta)*(17-row*1.3))))
        stripe(p,line,.84 if row==0 else .62,gold if row==0 else edge_dark)
    for row in range(2):
        y=-24-row*7
        plate(p,[(4,y+3,-8),(9,y,-6),(11,y-5,0),(9,y,6),(4,y+3,8),(7,y+5,0)],
            1.1,1.3,steel,edge_dark,.52)

    p = parts["lower_"+marker]
    rings(p,[(-30,0,0,6,6.7),(-25,0,0,8,8),(-17,0,0,9.5,10),(-10,-1,0,11.5,11),
             (-2,-1,0,12.5,11.7),(6,-2,0,10,10),(8,-2,0,7.4,7.5)],steel,20)
    plate(p,[(10,6,-6),(11,0,-8),(10,-12,-8),(7,-26,-5),(6,-29,0),
             (7,-26,5),(10,-12,8),(11,0,8),(10,6,6),(14,8,0)],2.1,1.8,steel_hi,gold,.72)
    for inset in range(2):
        z=side*(4+inset*2)
        stripe(p,[(10.5,-3,z),(12,-11,z),(9.4,-20,z*.8)],.52,edge_dark)
    rings(p,[(-29,0,0,6.8,7.1),(-28,0,0,7.3,7.8),(-25,0,0,7.2,7.6)],gold,16)
    ellip(p,(-.3,-34.5,0),(7.7,8.7,7.1),joint)
    for digit in range(4):
        z=(digit-1.5)*3.1
        if side>0:
            # A closed fist centered on the rig's sword socket Y=-35.06.
            pts=[(4,-30.7,z),(6,-34.9,z),(4.3,-39.8,z),(-.2,-40.7,z)]
        else:
            pts=[(3,-35,z),(5,-40.3,z),(3.2,-45.5,z)]
        strand(p,pts,[2.12]* (len(pts)-1)+[1.24],steel_hi,7)
    strand(p,[(-5,-32,-4),(-5.2,-36,-5.7),(-2.2,-39.3,-5.2)],[2.7,2.2,1.56],steel,7)

    p = parts["thigh_"+marker]
    rings(p,[(-37,0,0,8.6,8.5),(-34,0,0,10.3,10.4),(-23,0,0,11.6,11.3),
             (-11,0,0,12.5,11.6),(-3,0,0,12.7,12.2),(3,0,0,10,10.5)],shadow,20)
    for row in range(2):
        y=-3-12*row
        plate(p,[(8,y+4,-11),(11,y-4,-12),(13,y-14,-8),(14,y-17,0),
                 (13,y-14,8),(11,y-4,12),(8,y+4,11),(13,y+5,0)],2.1,2,steel if row else steel_hi,gold if row==0 else edge_dark,.66)

    p = parts["shin_"+marker]
    rings(p,[(-52,-1,0,7.7,7.7),(-47,0,0,8.2,8.4),(-34,-1,0,9.4,9.4),(-24,-2,0,10.2,11.5),
             (-15,-2,0,11,12),(-5,-1,0,11,11),(3,0,0,9,9)],joint,20)
    plate(p,[(8,8,-8),(11,5,-12),(14,-3,-11),(16,-10,-4),(17,-14,0),
             (16,-10,4),(14,-3,11),(11,5,12),(8,8,8),(15,10,0)],3,3,steel_hi,gold,.83)
    plate(p,[(9,-14,-9),(12,-23,-10),(10,-34,-8),(8,-43,-6),(10,-50,0),
            (8,-43,6),(10,-34,8),(12,-23,10),(9,-14,9),(14,-18,0)],3,2.6,steel,edge_dark,.92)
    stripe(p,[(14,-20,0),(14,-27,0),(13,-36,0),(11,-46,0)],.58,edge_dark)
    for z in (-1,1):
        stripe(p,[(12,-19,z*6),(12,-26,z*5),(10,-35,z*4)],.59,gold)

    p = parts["boot_"+marker]
    rings(p,[(-11.95,7,0,18.5,11.1),(-10.9,7,0,20,12),(-7.3,7,0,20,11.6),(-4,6.6,0,18,11.2),
             (0,3.6,0,14.8,10.6),(4,1.2,0,11.5,9.4),(9,-.7,0,9,8.5)],shadow,24)
    for row in range(4):
        x=4+row*5.2
        y=3-row*2.1
        width=11.0-row*.70
        path=[(x-4,y-4,-width),(x,y-1,-width*.83),(x+2,y+.8,-width*.48),(x+2,y+2,0),
              (x+2,y+.8,width*.48),(x,y-1,width*.83),(x-4,y-4,width)]
        strand(p,path,[2.3]*(len(path)),steel if row %2 else steel_hi,8)
        stripe(p,[(a+1.7,b+.45,c) for a,b,c in path],.72,edge_dark)

def cape_x(depth,z):
    curl = math.sin(.17*z+depth*.015)*(3.2+depth*.024)
    return -11 - .231*depth - 4*(abs(z)/47)**1.65 + curl


def cape_patch(part,first,end,rows,pivot_x,pivot_y):
    columns=36
    verts, uvs, faces = [],[],[]
    for row in range(rows+1):
        t=row/rows
        depth=first+(end-first)*t
        spread=38 + .07*depth
        for col in range(columns+1):
            q=(col/columns)*2-1
            z=q*spread
            tear=(9.7*math.sin(13.3*math.pi*q) + 4.2*math.sin(23.6*math.pi*q+2.7)) * t**4 if first else 0
            length=depth+tear
            verts.append((cape_x(length,z)-pivot_x,-length-pivot_y,z))
            uvs.append((col/columns,.94-length/157*.92))
    for row in range(rows):
        for col in range(columns):
            if first and row>rows*.46:
                w=row/rows
                # Tall nicks and three internal holes toward the ragged hem.
                d=min(abs(col-c) for c in (4,13,24,31))
                if (d==0 and w > (.79 + col%5*.036)) or (
                        col in (7,8,19,25,26,27) and (row+3*col)%17 in (1,2,3) and w>.73):
                    continue
            a=row*(columns+1)+col
            faces.append((a,a+1,a+columns+2,a+columns+1))
    part.add(verts,faces,t_cloth if atlas else wine,True,uvs)


p=parts["cape"]
cape_patch(p,0,65,20,0,0)
cape_patch(parts["hem"],65,142,41,-15,-65)
# Soft mantle over the shoulders. Curved closed tufts sit over its textured body.
ellip(p,(-.6,1,0),(23,13.5,43),t_fur if atlas else fur_dark,24,12)
for row in range(6):
    n=19 if row>1 else 16
    for col in range(n):
        u=col/(n-1)*2-1
        z=u*(39+row*.76)+rng.uniform(-1.5,1.5)
        x=13-row*5.8-abs(u)*4+rng.uniform(-1.5,1.5)
        y=11-row*3.35-abs(u)**1.26*8+rng.uniform(-.95,1.1)
        width=rng.uniform(2.3,4.25)
        length=rng.uniform(13,21)+row*.96
        dz=(u*.64+rng.uniform(-.17,.17))*length*.57
        tip=(x-length*.82,y-length*.67,z+dz)
        strands=[(x,y,z),(x-length*.20,y+.5,z+dz*.15),(x-length*.57,y-length*.30,z+dz*.65),tip]
        tone=(fur,fur_mid,fur,fur_mid,fur_dark)[(row+col*3)%5]
        strand(p,strands,[(width,width*.59),(width*.87,width*.48),(width*.44,width*.23),(.07,.04)],tone,6)
for side in (-1,1):
    for i in range(6):
        z=side*(28+i*2.05)
        strand(p,[(8-i*3,8-1.2*i,z),(-.5-i*3,4.5-i,z*1.09),(-10-i*3,-9-i,z*1.23),
                  (-19-i*3,-16-i,z*1.26)],[3.2,3.0,1.35,.07],fur if i%2==0 else fur_mid,7)
# Sweep shorter top locks over each shoulder and leave the forward rims visible.
for side in (-1,1):
    for i in range(9):
        x=8-i*2.35
        root=(x,9-i*.29,side*(28+i*.85))
        strand(p,[root,(x-3,7,side*(36+i*.65)),(x-8,-1-i*.42,side*(43+i*.55)),
                  (x-13,-7-i*.50,side*(46.5+i*.53))],
               [(3.7,2.9),(3.4,2.4),(2.0,1.22),(.05,.03)],
               fur if i%3 else fur_mid,7)
# Preserve the hand-painted snowflake; a sculpted thin stitch is the no-atlas fallback.
if not atlas:
    center=Vector((cape_x(36,0)-.65,-36,0))
    for i in range(6):
        angle=i*TAU/6
        delta=Vector((0,math.cos(angle),math.sin(angle)))
        perpendicular=Vector((0,delta.z,-delta.y))
        stripe(p,[center,center+delta*11],.52,embroidery)
        for j in (-1,1):
            stripe(p,[center+delta*7,center+delta*8.7+perpendicular*j*2.4],.40,embroidery)

p=parts["sword"]
rings(p,[(-14,0,0,4.2,4.2),(-10,0,0,4.5,4.5),(12,0,0,4.5,4.5),(15.5,0,0,5,5)],joint,16)
for y in (-10,-5,0,5,10):
    rings(p,[(y-.9,0,0,4.7,4.65),(y-.1,0,0,4.86,4.8),(y+.8,0,0,4.69,4.65)],edge_dark,16)
ellip(p,(0,16,0),(5.8,7,5.4),edge_dark,14,8)
for side in (-1,1):
    strand(p,[(0,-17,0),(8*side,-18,0),(13*side,-14,0),(19*side,-13,0),(23*side,-9,0)],
           [4.8,4,3.6,2.2,.10],gold,8)
    strand(p,[(7*side,-19,0),(11*side,-22,0),(16*side,-23,0),(19*side,-27,0)],
           [4,3.4,2,.12],edge,8)
    strand(p,[(3*side,-19,3),(8*side,-14,3),(13*side,-13,2.5),(16*side,-10,2)],
           [1.75,1.48,1.05,.05],edge_dark,7)
ellip(p,(0,-18,4.4),(3.8,5.4,2.3),hot,12,8)
# A long four-faced solid crystal. Each edge has irregular teeth and a beveled shoulder.
taper=[(-21,9.5),(-28,10.6),(-34,11.4),(-37,8.85),(-44,10.7),(-46,8.45),(-53,9.35),
       (-57,7.7),(-62,8.95),(-66,6.85),(-73,7.1),(-81,5),(-90,2.45),(-96,.09)]
blade=[]
for k,(y,w) in enumerate(taper):
    z=5.45*(1-((y+21)/75)**2)
    blade += [(-w,y,0),(0,y,z),(w,y,0),(0,y,-z)]
blade_faces=[(3,2,1,0)]
blade_mats=[ice_shade]
for row in range(len(taper)-1):
    for facet in range(4):
        idx=row*4+facet
        nxt=row*4+(facet+1)%4
        blade_faces.append((idx,nxt,nxt+4,idx+4))
        blade_mats.append((ice,ice_shade,ice,ice_shade)[facet])
blade_faces.append(tuple(range(len(blade)-4,len(blade))))
blade_mats.append(ice_edge)
p.add(blade,blade_faces,blade_mats,False)
for side in (-1,1):
    spine=[]
    edge_path=[]
    for y,w in taper:
        z=5.45*(1-((y+21)/75)**2)
        spine.append((0,y,(z+.24)*side))
        edge_path.append((w*side,y,0))
    strand(p,spine,[.96*(1-.92*k/(len(spine)-1)) for k in range(len(spine))],hot,7)
    strand(p,edge_path,[1.04*(1-.88*k/(len(edge_path)-1)) for k in range(len(edge_path))],ice_edge,6)
    for k,d in enumerate((34,46,57,67,76)):
        z=5.5*(1-((d-21)/75)**2)
        stripe(p,[(0,-d+2,z*side),(2.2*side,-d,(z-.8)*side),(4.3*side,-d+3,(z-2.3)*side)],.57,hot)

root=bpy.data.objects.new("Senhor_do_Abismo",None)
bpy.context.collection.objects.link(root)
for part in parts.values():
    part.create(root)
assert len(root.children)==15
mesh_objects=[obj for obj in bpy.context.scene.objects if obj.type=="MESH"]
face_count=sum(len(obj.data.polygons) for obj in mesh_objects)
print(f"MODEL {len(root.children)} sockets | {len(mesh_objects)} meshes | {face_count} faces | atlas={str(atlas_file) if atlas else 'none'}",flush=True)
bpy.ops.export_scene.gltf(filepath=str(destination),export_format="GLB",
                         export_yup=True,export_texcoords=True,export_normals=True,
                         export_materials="EXPORT",export_cameras=False,export_lights=False,
                         export_animations=False)
assert destination.stat().st_size>250000
print(f"EXPORTED {destination}",flush=True)
