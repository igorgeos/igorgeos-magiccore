extends SceneTree

const Foe := preload("res://scenes/forest/foe.gd")
const Hit := preload("res://systems/combat/ancestral_impact.gd")
const Light := preload("res://characters/player/strikes/horizontal.tres")
const Heavy := preload("res://characters/player/strikes/descendente.tres")
const DT := 1.0 / 60.0


func _initialize() -> void:
	run.call_deferred()
	create_timer(22.0).timeout.connect(func(): quit(2))


func run() -> void:
	var campaign = root.get_node("Campaign")
	assert(campaign.start(1) == OK)
	for id in ["mata1", "mata2", "mata3", "mata4", "mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage() == OK)
	assert(campaign.open_chapter("gelo") == OK and campaign.enter_stage("gelo1"))
	assert(change_scene_to_file(campaign.stage_data("gelo1").scene) == OK)
	await scene_changed
	await physics_frame
	var world = current_scene
	var watch = world.foes[0]
	var colossus = world.foes[1]
	for creature in [watch, colossus]:
		creature.suspend(true)
		assert(creature.rig.model is Node3D)
		assert(creature.rig._viewport.own_world_3d and creature.rig._viewport.transparent_bg)
		assert(creature.rig.model.bones.size() == 24)
		assert(creature.rig._screen.scale.x > 0.0)
	assert(colossus.height > watch.height * 1.32)
	assert(colossus.receiver.max_health > watch.receiver.max_health)
	var watch_run := check_gait(watch, 142.0)
	var colossus_walk := check_gait(colossus, 55.0)
	assert(watch_run > colossus_walk * 1.4)
	for creature in [watch, colossus]:
		creature.side = -1.0
		var passed_front := false
		for frame in 25:
			creature.rig.tick(DT, -0.8)
			assert(creature.rig.model.transform.basis.determinant() > 0.99)
			assert(creature.rig.transform.determinant() > 0.99)
			if absf(creature.rig.yaw) < 0.18:
				passed_front = true
				var a: Vector2 = creature.rig.attack_point(5)
				var b: Vector2 = creature.rig.attack_point(9)
				assert(absf(a.x - b.x) > (46.0 if creature.heavy else 22.0))
				assert(absf(creature.rig._joints[15].y - creature.rig._joints[19].y) > 8.0)
		assert(passed_front and creature.rig.yaw < -0.96)
		check_joints(creature)
	for move in [Foe.Move.RAKE, Foe.Move.CHARGE]:
		assert(check_attack(watch, move) > 22.0)
	var crush := check_attack(colossus, Foe.Move.RAKE)
	var sweep := check_attack(colossus, Foe.Move.CHARGE)
	var stamp := check_attack(colossus, Foe.Move.STOMP)
	assert(crush > 38.0 and sweep > 38.0 and stamp > 51.0)
	for move in [Foe.Move.RAKE, Foe.Move.CHARGE]:
		check_contact(world, watch, move, 68.0)
	for move in [Foe.Move.RAKE, Foe.Move.CHARGE, Foe.Move.STOMP]:
		check_contact(world, colossus, move, 102.0)
	check_impact(watch, colossus)
	print("PASS criaturas de gelo: giro em volume, articulações, passada, corrida, cinco contatos únicos e impacto.")
	root.get_node("Preferences").stop_audio()
	current_scene.queue_free()
	await create_timer(0.35).timeout
	quit()


func check_joints(creature) -> void:
	var rig = creature.rig
	for connection in [["neck", "ribcage", "head"], ["upper_a", "shoulder_a", "elbow_a"],
			["lower_a", "elbow_a", "hand_a"], ["shin_a", "knee_a", "boot_a"],
			["upper_b", "shoulder_b", "elbow_b"], ["lower_b", "elbow_b", "hand_b"],
			["shin_b", "knee_b", "boot_b"]]:
		var link: Node3D = rig.model.bones[connection[0]]
		var begin: Node3D = rig.model.bones[connection[1]]
		var end: Node3D = rig.model.bones[connection[2]]
		assert(link.position.is_equal_approx(begin.position))
		var endpoint := link.transform * Vector3.UP
		assert(endpoint.distance_to(end.position) < 4.0)
	assert(rig.model.bones["hand_a"].position.is_equal_approx(rig._joints[7]))
	assert(rig._joints[7].distance_to(rig._joints[8]) > 19.0)


func check_gait(creature, speed: float) -> float:
	creature.side = 1.0
	creature.change(Foe.State.PURSUE)
	var highest := 0.0
	for frame in 120:
		creature.rig.tick(DT, speed * DT)
		var front: Vector2 = creature.rig.pose[15]
		var far: Vector2 = creature.rig.pose[19]
		assert(front.is_finite() and far.is_finite() and minf(front.y, far.y) <= -8.0)
		highest = maxf(highest, -minf(front.y, far.y))
	var length := 82.0 if creature.heavy else 95.0
	var support := 0.71 if creature.heavy else 0.47
	var start: Vector3 = creature.rig._step(0.15, length, support, 1.0)
	var next: Vector3 = creature.rig._step(0.15 + speed * DT / length, length, support, 1.0)
	assert(is_equal_approx(start.x - next.x, speed * DT) and start.y == 0.0 and next.y == 0.0)
	return highest


func check_attack(creature, move: int) -> float:
	creature._prepare(move, 1.0, 0.65)
	for frame in 39:
		advance_pose(creature)
	var windup: Vector2 = creature.rig.pose[8]
	creature.time = 0.0
	creature._choose_action(Vector2(66, 0))
	assert(creature.state == Foe.State.STRIKE and creature.time > 0.0)
	var extent := 0.0
	while creature.time > 0.0:
		advance_pose(creature)
		extent = maxf(extent, windup.distance_to(creature.rig.pose[8]))
	creature.change(Foe.State.RECOVER, creature._recovery_time())
	assert(creature.time >= 0.6)
	for frame in 20:
		advance_pose(creature)
	return extent


func advance_pose(creature) -> void:
	creature.age += DT
	creature.time -= DT
	creature.rig.tick(DT, 0.0)


func check_contact(world, creature, move: int, distance: float) -> void:
	var start_x: float = creature.position.x + distance
	world._move_hero(Vector2(start_x, world.surface_at(start_x)))
	world.life.invulnerability = 0.0
	world.life.current = world.life.capacity
	creature._prepare(move, 1.0, 0.6)
	for frame in 36:
		advance_pose(creature)
	creature.time = 0.0
	creature._choose_action(Vector2(distance, 0))
	creature.apply_attack()
	assert(world.life.current == world.life.capacity, "O preparo e o início do golpe não acertam.")
	var health_after_contact := -1
	while creature.time > 0.0:
		advance_pose(creature)
		creature.apply_attack()
		if creature.spent and health_after_contact < 0:
			health_after_contact = world.life.current
		world.life.invulnerability = 0.0
	assert(health_after_contact >= 0 and health_after_contact < world.life.capacity,
		"Golpe sem contato na distância de teste: %s" % move)
	assert(world.life.current == health_after_contact, "Cada golpe só pode acertar uma vez.")


func impact(profile: Resource, target, intensity: float, sequence: int) -> Hit:
	var hit := Hit.new(profile, Vector2(470, -18), 1.0, target.receiver.impact_resistance,
		intensity, true, Vector2.ZERO)
	hit.sequence = sequence
	hit.source_id = 42
	return hit


func check_impact(watch, colossus) -> void:
	watch.change(Foe.State.PURSUE)
	colossus.change(Foe.State.WINDUP, 0.75)
	var weak := impact(Light, colossus, 0.64, 1)
	assert(colossus.receiver.receive_strike(weak))
	assert(colossus.state == Foe.State.WINDUP and colossus.velocity.x == 0.0)
	assert(not colossus.receiver.receive_strike(impact(Light, colossus, 0.64, 2)))
	assert(watch.receiver.receive_strike(impact(Heavy, watch, 1.4, 1)))
	assert(watch.state == Foe.State.HURT and absf(watch.velocity.x) > 60.0)
	var watch_reaction: float = watch.rig.recoil_speed.length()
	var colossus_reaction: float = colossus.rig.recoil_speed.length()
	assert(watch_reaction > colossus_reaction * 2.0)
	colossus.armor = 0.0
	assert(colossus.receiver.receive_strike(impact(Heavy, colossus, 1.6, 3)))
	assert(colossus.state == Foe.State.HURT)
	watch.armor = 0.0
	var final_hit := impact(Heavy, watch, 1.4, 2)
	final_hit.damage = watch.receiver.health
	assert(watch.receiver.receive_strike(final_hit))
	assert(watch.state == Foe.State.DEAD and watch.receiver.collision_layer == 0)
	var upright: Vector2 = watch.rig.pose[2]
	for frame in 36:
		advance_pose(watch)
	assert(watch.rig.pose[2].y > upright.y + 15.0)
