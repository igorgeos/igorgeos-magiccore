extends SceneTree
# Cross the terrain using movement, jumps and interactions, from the regular spawn.
func _initialize() -> void:
	call_deferred("run")
	create_timer(110).timeout.connect(func(): quit(1))

func run() -> void:
	var campaign = root.get_node("Campaign")
	if campaign.has_saved(): quit(2); return
	assert(campaign.start(1)==OK)
	for level in 4:
		assert(campaign.enter_stage("mata%d"%(level+1)))
		change_scene_to_file(campaign.stage_data(campaign.stage).scene)
		await process_frame
		await process_frame
		var world = current_scene
		var player = world._player
		player.run_latched = true
		player.touch_axis = 1
		for tick in 2100:
			await physics_frame
			if world.ended: break
			player.touch_axis = 1
			if player.is_on_floor() and tick%4==0: player.request_jump()
			if world.nearby>=0:
				var key: String = world.sites[world.nearby].key
				if key in ["exit","echo","seal","winch","bolt"]: world.activate()
		print("Travessia ",level+1," x=",player.position.x," hp=",world.hp," ações=",world.used)
		assert(world.won)
	print("PASS: as quatro rotas até o santuário são transitáveis a partir do início.")
	root.get_node("Preferences").stop_audio()
	current_scene.queue_free()
	await create_timer(0.28).timeout
	quit()
