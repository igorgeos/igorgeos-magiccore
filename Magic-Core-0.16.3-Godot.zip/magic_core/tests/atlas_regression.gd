extends SceneTree

const MENU := "res://scenes/menu/main_menu.tscn"
var campaign: Node

func frames(n: int) -> void:
	for i in n:
		await process_frame

func _initialize() -> void:
	run.call_deferred()

func tap(button: Button) -> void:
	var mouse := InputEventMouseButton.new()
	mouse.position = button.get_global_rect().get_center()
	mouse.button_index = MOUSE_BUTTON_LEFT
	mouse.pressed = true
	root.push_input(mouse,true)
	mouse.pressed = false
	root.push_input(mouse,true)
	await frames(4)

func finger(point: Vector2, down: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.position = point
	event.index = 0
	event.pressed = down
	root.push_input(event,true)

func run() -> void:
	campaign = root.get_node("Campaign")
	# This integration test owns its slots; run with an isolated user-data directory.
	if campaign.has_saved():
		printerr("Use um perfil de teste vazio.")
		quit(2)
		return
	create_timer(35).timeout.connect(func(): quit(1))
	root.get_node("Preferences").values.reduced_motion = true
	root.size = Vector2i(1280,720)
	change_scene_to_file(MENU)
	await frames(5)
	current_scene._open_option(current_scene.Carousel.PLAY_INDEX)
	await frames(40)
	assert(current_scene.scene_file_path == campaign.ATLAS and campaign.active_slot == 1)
	var atlas = current_scene
	var ocean = atlas.ocean
	assert(ocean.shores.size() == 5)
	for index in [1,2,3,4,0]:
		var point: Vector2 = ocean.labels[index]*ocean.zoom+ocean.offset+Vector2(0,8)
		finger(point,true)
		finger(point,false)
		await frames(3)
		assert(atlas.selected == index and not atlas.map_open)
		assert(atlas.paper.get_node("AbrirCarta").disabled == (index!=0))
		ocean.focus_at(1.0,ocean.PAGE*0.5)
	ocean.focus_at(1.6,ocean.PAGE*0.5)
	var old_offset: Vector2 = ocean.offset
	finger(Vector2(610,300),true)
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = Vector2(710,350)
	drag.relative = Vector2(100,50)
	root.push_input(drag,true)
	finger(drag.position,false)
	await frames(3)
	assert(ocean.offset != old_offset and atlas.selected == 0)
	await tap(atlas.paper.get_node("AbrirCarta"))
	assert(atlas.map_open)
	await frames(32)
	await tap(atlas.paper.get_node("Fase3"))
	assert(atlas.paper.get_node("Entrar").disabled and not campaign.enter_stage("mata3"))
	assert(not campaign.unlocked(campaign.stage_data("mata2")))
	await tap(atlas.paper.get_node("Fase1"))
	await frames(26)
	await tap(atlas.paper.get_node("Entrar"))
	assert(current_scene.scene_file_path.ends_with("forest.tscn"))
	await frames(26)
	current_scene._go_back()
	await frames(6)
	assert(current_scene.map_open and campaign.completed.is_empty())
	await tap(current_scene.paper.get_node("Entrar"))
	current_scene._player.position = current_scene.sites.back().point
	await frames(4)
	await tap(current_scene.interact)
	assert(current_scene.won)
	current_scene._go_back()
	await frames(12)
	assert(current_scene.map_open and campaign.completed == ["mata1"])
	campaign.leave()
	assert(campaign.resume(1)==OK and campaign.completed == ["mata1"])
	assert(not campaign.unlocked(campaign.stage_data("mata3")))
	assert(campaign.unlocked(campaign.stage_data("mata2")))
	for id in ["mata2","mata3","mata4","mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage()==OK)
	assert(campaign.open_chapter("gelo")==OK)
	# Recreate a v13 slot in the disposable profile: the old release had
	# already unlocked the ice chapter once mata5 was completed.
	var legacy := ConfigFile.new()
	assert(legacy.load("user://campanha_1.cfg")==OK)
	legacy.erase_section_key("atlas","seals")
	assert(legacy.save("user://campanha_1.cfg")==OK)
	assert(campaign.resume(1)==OK)
	assert(campaign.open_chapter("gelo")==OK)
	campaign.leave()
	assert(campaign.resume(1)==OK and campaign.chapter=="gelo")
	assert(campaign.start(2)==OK and campaign.completed.is_empty() and campaign.chapter=="mata")
	assert(not campaign.enter_stage("gelo1"))
	# Magic Core 14 allowed completing the second route before the first.
	var prior := ConfigFile.new()
	assert(prior.load("user://campanha_2.cfg")==OK)
	prior.set_value("atlas","completed",["mata2"])
	assert(prior.save("user://campanha_2.cfg")==OK)
	assert(campaign.resume(2)==OK)
	assert(campaign.completed == ["mata2"])
	assert(campaign.unlocked(campaign.stage_data("mata2")) and not campaign.unlocked(campaign.stage_data("mata3")))
	await tap(current_scene.paper.get_node("Voltar"))
	assert(not current_scene.map_open)
	await tap(current_scene.paper.get_node("Voltar"))
	assert(current_scene.scene_file_path == MENU)
	print("PASS Atlas: menu, cartas, bloqueios, travessia, retorno, conclusão, slots e recarga.")
	root.get_node("Preferences").stop_audio()
	await create_timer(0.27).timeout
	quit()
