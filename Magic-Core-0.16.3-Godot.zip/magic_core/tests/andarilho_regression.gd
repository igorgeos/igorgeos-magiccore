extends SceneTree
## Run with isolated XDG_DATA_HOME on Linux. Pass -- 30fps to repeat with a 30 FPS cap.

const Adaptive := preload("res://characters/player/adaptive_motion.gd")
const Motion := preload("res://characters/player/motion.gd")
const ROOM := "res://scenes/world/test_world.tscn"

var actor: CharacterBody2D
var target: Area2D
var figure: Node2D
var hud: Control
var wheel: Control
var pose: RefCounted


func _initialize() -> void:
	_test.call_deferred()
	create_timer(32.0).timeout.connect(func() -> void: quit(1))


func _test() -> void:
	var preferences := root.get_node("Preferences")
	preferences.values.fps = 30 if OS.get_cmdline_user_args().has("30fps") else 60
	preferences.apply()
	assert(change_scene_to_file(ROOM) == OK)
	await process_frame
	await process_frame
	actor = current_scene.get_node("Personagem")
	target = current_scene.get_node("Alvo")
	figure = actor.get_node("Visual")
	hud = current_scene.get_node("Interface/Comandos")
	wheel = current_scene.get_node("Interface/Arsenal")
	pose = figure.pose
	await _ticks(12, true)

	var height_min: float = pose.neck.y
	var height_max := height_min
	var idle_x := actor.position.x
	for i in range(130):
		await _ticks(1, true)
		height_min = minf(height_min, pose.neck.y)
		height_max = maxf(height_max, pose.neck.y)
	assert(height_max - height_min > 1.0 and is_equal_approx(actor.position.x, idle_x))
	assert(pose.adaptive.phase == Adaptive.Phase.GROUND)

	for sign: float in [1.0, -1.0]:
		await _exercise_ground(sign)
	await _exercise_turn()
	print("PASS: repouso, caminhada e corrida à esquerda e à direita, apoios no chão e brace na reversão.")

	await _exercise_jump(false)
	await _exercise_jump(true)
	print("PASS: salto parado e em corrida, decolagem imediata, subida, ápice, descida e recuperação no pouso.")

	await _exercise_gear()
	assert(actor.can_attack())
	await _exercise_jump(true)
	assert(actor.can_attack())
	for sign: float in [1.0, -1.0]:
		actor.position.x = target.position.x - 82.0 * sign
		actor.reset_physics_interpolation()
		_touch(0, _point(&"right" if sign > 0.0 else &"left"), true)
		await _ticks(2, true)
		_touch(0, _point(&"right" if sign > 0.0 else &"left"), false)
		await _ticks(7, true)
		var before: int = target.health
		_tap(1, _point(&"attack"))
		var landed := false
		for tick in range(33):
			await _ticks(1, true)
			if not landed and target.health < before:
				var progress: float = actor.strike_progress()
				var profile = actor.current_strike()
				assert(profile != null and progress >= profile.active_start and progress <= profile.active_end)
				landed = true
		assert(landed and target.health == before - 1)
	print("PASS: saque, guarda reversível, cintura, boca, mão durante corrida e salto armados, acerto único nos dois sentidos.")

	preferences.values.hud_size = 150
	preferences.apply()
	for resolution: Vector2 in [Vector2(1280, 720), Vector2(1560, 720), Vector2(940, 530), Vector2(656, 360)]:
		hud.size = resolution
		wheel.size = resolution
		hud._layout()
		wheel._layout()
		for key: StringName in hud.centers:
			var point := _point(key)
			assert(Rect2(Vector2.ZERO, resolution).has_point(point) and hud._hit(point) == key)
		_touch(0, _point(&"left"), true)
		assert(actor.touch_axis == -1.0)
		_touch(0, _point(&"left"), true, true)
		assert(is_zero_approx(actor.touch_axis))
		_touch(1, _point(&"right"), true)
		_tap(2, _point(&"arsenal"))
		assert(wheel.visible and actor.controls_locked and is_zero_approx(actor.touch_axis))
		_tap(2, wheel._center)
		assert(hud.visible and not actor.controls_locked and is_zero_approx(actor.touch_axis))
	print("PASS: multitoque, cancelamento, modo Arsenal, HUD ampliado e áreas de toque em quatro tamanhos.")
	preferences.stop_audio()
	await create_timer(0.12).timeout
	quit()


func _exercise_ground(sign: float) -> void:
	var key := &"right" if sign > 0.0 else &"left"
	actor.position.x = 420.0 if sign > 0.0 else 860.0
	actor.reset_physics_interpolation()
	_touch(0, _point(key), true)
	assert(actor.touch_axis == sign)
	await _ticks(14, true)
	assert(absf(actor.velocity.x - actor.walk_speed * sign) < 0.1)
	var anchors := 0
	var before_x := 0.0
	var was_support := false
	for i in range(76):
		await _ticks(1, true)
		var x := figure.to_global(pose.front_ankle).x
		var support: bool = pose._phase > 0.035 and pose._phase < 0.36 and pose._stride > 0.999
		if support and was_support:
			assert(absf(x - before_x) < 0.09)
			anchors += 1
		before_x = x
		was_support = support
	assert(anchors >= 12)
	_tap(1, _point(&"run"))
	assert(actor.run_latched and actor.touch_axis == sign)
	await _ticks(34, true)
	assert(absf(actor.velocity.x - actor.run_speed * sign) < 0.1 and pose.run_blend > 0.95)
	var suspension := false
	before_x = 0.0
	was_support = false
	anchors = 0
	for i in range(53):
		await _ticks(1, true)
		var x := figure.to_global(pose.front_ankle).x
		var support: bool = pose._phase > 0.04 and pose._phase < 0.23
		if support and was_support:
			assert(absf(x - before_x) < 0.09)
			anchors += 1
		before_x = x
		was_support = support
		suspension = suspension or (pose.front_ankle.y < -10.0 and pose.rear_ankle.y < -10.0)
	assert(suspension and anchors >= 5)
	_touch(0, _point(key), false)
	_tap(1, _point(&"run"))
	await _ticks(22, true)
	assert(is_zero_approx(actor.velocity.x) and is_zero_approx(actor.touch_axis))


func _exercise_turn() -> void:
	actor.position.x = 580.0
	actor.reset_physics_interpolation()
	_tap(1, _point(&"run"))
	_touch(0, _point(&"right"), true)
	await _ticks(40, true)
	var old_speed := actor.velocity.x
	var near_before := figure.to_global(pose.front_ankle).x
	var far_before := figure.to_global(pose.rear_ankle).x
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = _point(&"left")
	root.push_input(drag, true)
	assert(actor.touch_axis == -1.0)
	await _ticks(1, true)
	assert(figure.transform.x.x < 0.0 and actor.velocity.x < old_speed and pose.adaptive.hard_turn)
	var near: bool = pose._turn_foot == 0
	var planted_now := figure.to_global(pose.front_ankle if near else pose.rear_ankle).x
	assert(absf(planted_now - (near_before if near else far_before)) < 0.35)
	var reached := false
	for i in range(10):
		await _ticks(1, true)
		if pose.hand_brace > 0.68:
			reached = true
			assert(pose.front_hand.distance_to(pose.mouth) < 9.0)
	assert(reached and actor.velocity.x < 0.0)
	for key: StringName in [&"right", &"left", &"right", &"left"]:
		drag = InputEventScreenDrag.new()
		drag.index = 0
		drag.position = _point(key)
		root.push_input(drag, true)
		await _ticks(2, true)
		assert(figure.transform.x.x == (1.0 if key == &"right" else -1.0))
	_touch(0, _point(&"left"), false)
	_tap(1, _point(&"run"))
	await _ticks(28, true)


func _exercise_jump(running: bool) -> void:
	actor.position.x = 500.0
	actor.reset_physics_interpolation()
	if running:
		_tap(2, _point(&"run"))
		_touch(0, _point(&"right"), true)
		await _ticks(42, true)
	var start_y := actor.position.y
	_tap(1, _point(&"jump"))
	await _ticks(1, true)
	assert(not actor.is_on_floor() and actor.position.y < start_y)
	assert(pose.adaptive.phase == Adaptive.Phase.IMPULSE)
	assert(not running or (actor.touch_axis > 0.0 and actor.velocity.x > actor.walk_speed))
	var phases := {}
	var max_recovery := 0.0
	for tick in range(64):
		await _ticks(1, true)
		phases[pose.adaptive.phase] = true
		max_recovery = maxf(max_recovery, pose.adaptive.landing)
	assert(actor.is_on_floor() and max_recovery > 0.50)
	for phase in [Adaptive.Phase.IMPULSE, Adaptive.Phase.ASCENT, Adaptive.Phase.APEX, Adaptive.Phase.DESCENT, Adaptive.Phase.LANDING]:
		assert(phases.has(phase))
	if running:
		_touch(0, _point(&"right"), false)
		_tap(2, _point(&"run"))
	await _ticks(24, true)


func _exercise_gear() -> void:
	_tap(1, _point(&"arsenal"))
	assert(wheel.visible and not hud.visible)
	_tap(1, wheel._center + Vector2(145.0, 0.0) * wheel._unit)
	assert(actor.weapon_selected)
	await _check_transition(true, 56)
	assert(actor.can_attack())
	_tap(1, _point(&"arsenal"))
	_tap(1, wheel._center - Vector2(145.0, 0.0) * wheel._unit)
	assert(not actor.weapon_selected)
	await _check_transition(false, 50)
	assert(is_zero_approx(actor.weapon_progress))
	actor.select_weapon(true)
	await _check_transition(true, 23)
	actor.select_weapon(false)
	await _check_transition(false, 32)
	assert(is_zero_approx(actor.weapon_progress))
	actor.select_weapon(true)
	await _check_transition(true, 56)


func _check_transition(drawing: bool, count: int) -> void:
	var previous: float = actor.weapon_progress
	var grip: Vector2 = pose.grip
	for i in range(count):
		await _ticks(1, true)
		var amount: float = actor.weapon_progress
		assert(amount >= previous if drawing else amount <= previous)
		assert(grip.distance_to(pose.grip) < 9.0, "grip jump at %.3f -> %.3f, from %s to %s" % [previous, amount, grip, pose.grip])
		previous = amount
		grip = pose.grip


func _ticks(count: int, verify_anchors: bool) -> void:
	for i in range(count):
		await physics_frame
		if verify_anchors:
			_check_anchors()


func _check_anchors() -> void:
	var belt := figure.get_node("Cintura") as Marker2D
	var mouth := figure.get_node("Cintura/BocaBainha") as Marker2D
	var grip := figure.get_node("Empunhadura") as Marker2D
	assert(belt.position.distance_to(pose.hip) < 5.30 and belt.position.distance_to(pose.socket) < 0.002)
	assert(mouth.global_position.distance_to(figure.to_global(pose.mouth)) < 0.004)
	assert(grip.global_position.distance_to(figure.to_global(pose.grip)) < 0.004)
	assert(absf((pose.keeper - pose.mouth).cross(pose.axis)) < 0.005)
	if actor.weapon_progress >= Motion.REACH:
		assert(pose.front_hand.distance_to(pose.grip) < 0.002)
	if actor.weapon_progress <= Motion.CLEAR:
		assert(figure.blade_tip().distance_to(pose.mouth) < 0.004)
	if actor.is_on_floor():
		assert((pose.mouth + pose.axis * 56.0).y < -0.8, "sheath toe %s at hip %s, socket %s, axis %s, landing %s" % [pose.mouth + pose.axis * 56.0, pose.hip, pose.socket, pose.axis, pose.adaptive.landing])
		assert(pose.front_ankle.y <= -5.7 and pose.rear_ankle.y <= -5.7)


func _point(key: StringName) -> Vector2:
	return hud._origin + hud.centers[key] * hud._unit


func _tap(index: int, point: Vector2) -> void:
	_touch(index, point, true)
	_touch(index, point, false)


func _touch(index: int, point: Vector2, pressed: bool, canceled := false) -> void:
	var input := InputEventScreenTouch.new()
	input.index = index
	input.position = point
	input.pressed = pressed
	input.canceled = canceled
	root.push_input(input, true)
