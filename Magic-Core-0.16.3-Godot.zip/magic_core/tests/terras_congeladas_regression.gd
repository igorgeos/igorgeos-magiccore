extends SceneTree

const ATLAS := "res://scenes/atlas/atlas.tscn"
const ICE := preload("res://scenes/gelo/gelo_fragil.gd")
const TOOTH := preload("res://scenes/gelo/estalactite.gd")
const FOE := preload("res://scenes/forest/foe.gd")
var campaign: Node
var world: Node2D
var hero: CharacterBody2D


func _initialize() -> void:
	run.call_deferred()
	create_timer(125.0).timeout.connect(func(): quit(2))


func frames(count: int) -> void:
	for tick in count:
		await physics_frame


func tap(button: Button) -> void:
	assert(button.visible and not button.disabled)
	var finger := InputEventScreenTouch.new()
	finger.position = button.get_global_rect().get_center()
	finger.index = 0
	finger.pressed = true
	root.push_input(finger, true)
	finger.pressed = false
	root.push_input(finger, true)
	await frames(6)


func map_enter(id: String) -> void:
	assert(current_scene.scene_file_path == ATLAS and current_scene.map_open)
	var atlas = current_scene
	var stages: Array = campaign.region("gelo").stages
	for i in stages.size():
		if stages[i].id == id:
			await tap(atlas.paper.get_node("Fase%d" % (i + 1)))
			break
	var enter := atlas.paper.get_node("Entrar") as Button
	assert(enter.text.begins_with("Entrar na fase"))
	await tap(enter)
	assert(current_scene.scene_file_path == campaign.stage_data(id).scene)
	world = current_scene
	hero = world._player
	assert(world.stage_id == id and world.life.current == 100 and hero.is_on_floor())
	assert(world.progress.cursor == 0 and not world.ended)
	assert(not world.stable_shelves.is_empty() and not world.foes.is_empty())
	assert(world._mission.get_global_rect().encloses(world._objective.get_global_rect()))
	for piece: Polygon2D in world.scenery.find_children("*", "Polygon2D", true, false):
		assert(piece.texture != null and not Geometry2D.triangulate_polygon(piece.polygon).is_empty())


func reach(x: float, standing_on := INF, jump := false) -> void:
	if jump:
		assert(hero.is_on_floor(), "O salto deve sair de um apoio.")
		hero.run_latched = true
		hero.touch_axis = signf(x - hero.position.x)
		hero.request_jump()
		await frames(2)
		assert(not hero.is_on_floor())
	for tick in 900:
		if world.ended:
			break
		var error := x - hero.position.x
		hero.run_latched = absf(error) > 78.0 or not hero.is_on_floor()
		hero.touch_axis = signf(error) if absf(error) > 8.0 else 0.0
		if absf(error) <= 11.0 and hero.is_on_floor() and absf(hero.velocity.x) < 88.0:
			if is_inf(standing_on) or absf(hero.position.y - standing_on) < 4.0:
				hero.touch_axis = 0.0
				await frames(4)
				return
		await physics_frame
	assert(false, "Falha em %s, tentando chegar a %s / %s, posição %s, vida %s" % [
		world.stage_id, x, standing_on, hero.position, world.life.current,
	])


func use_site(key: String) -> void:
	assert(world._nearest == key, "Interação %s a partir de %s: %s" % [key, hero.position, world._nearest])
	await tap(world.interact)


func result_button(caption: String) -> Button:
	for child: Button in world._hud.find_children("*", "Button", true, false):
		if child.text == caption:
			return child
	return null


func return_from_result() -> void:
	var back := result_button("Voltar ao mapa")
	assert(back != null)
	await tap(back)
	assert(current_scene.map_open)


func porto() -> void:
	await map_enter("gelo1")
	assert(world.brittle_ice.size() == 1)
	assert(world.route.water.size() == 2)
	var coast := await coast_distance(275.0)
	var glide := await coast_distance(385.0)
	assert(glide > coast + 12.0 and glide < 55.0, "O gelo deve prolongar a frenagem moderadamente.")
	await reach(524)
	assert(not hero.slippery_ground and hero._ground_slip == 0.0)
	await reach(536)
	await use_site("lanterna")
	assert(world.progress.cursor == 1 and "gelo1" not in campaign.completed)
	await reach(961)
	await reach(1122, 562.0, true)
	assert(world.brittle_ice[0].state == ICE.State.CRACKING)
	await frames(65)
	assert(world.brittle_ice[0].state == ICE.State.BROKEN)
	assert(world.life.current < 100 and hero.position.x < 1000.0)
	await frames(190)
	assert(world.brittle_ice[0].state == ICE.State.SOLID)
	await reach(961)
	await reach(973, 465.0, true)
	await reach(1121, 432.0, true)
	await reach(1306, 476.0, true)
	await reach(1469)
	await use_site("rest")
	assert(world.life.current > 78 and world.sites.rest.used)
	await reach(1900)
	await use_site("farol")
	await reach(2070)
	await reach(2200, 527.0, true)
	await reach(2301, 538.0, true)
	await reach(2720)
	await use_site("sino")
	assert(world.won and "gelo1" in campaign.completed)
	await return_from_result()
	assert(campaign.unlocked(campaign.stage_data("gelo2")))
	print("PASS Passagem: frenagem comparada, rota alta, gelo quebradiço, cura e posto de vigilância.")


func coast_distance(start_x: float) -> float:
	world._move_hero(Vector2(start_x, world.surface_at(start_x)))
	hero.run_latched = false
	hero.touch_axis = 1.0
	await frames(22)
	var release := hero.position.x
	hero.touch_axis = 0.0
	await frames(32)
	return hero.position.x - release


func passo() -> void:
	await map_enter("gelo2")
	assert(world.icicles.size() == 3 and is_instance_valid(world._gate))
	await reach(735)
	await frames(87)
	assert(world.icicles[0].state == TOOTH.State.SHATTERED and world.life.current < 100)
	await reach(951)
	var lane = world._wind_lanes[0]
	lane.clock = lane.warning_time - 0.48
	await frames(5)
	assert(lane.phase == lane.Phase.WARNING and hero.wind_velocity == 0.0)
	var calm_x := hero.position.x
	await frames(60)
	assert(lane.phase == lane.Phase.GUST and hero.wind_velocity < 0.0 and hero.position.x < calm_x - 3.0)
	await reach(951)
	await reach(1068, 510.0, true)
	await reach(1193, 508.0, true)
	await reach(1377)
	assert(world._nearest != "guincho")
	await reach(1480, 445.0, true)
	await use_site("guincho")
	await frames(55)
	assert(not is_instance_valid(world._gate) and world.progress.cursor == 1)
	await reach(1617, 411.0, true)
	await reach(1825, 440.0, true)
	await use_site("abrigo")
	assert(world.sites.abrigo.used and world.progress.cursor == 1)
	await reach(1988)
	await reach(2099, 517.0)
	await reach(2224, 502.0, true)
	await reach(3121)
	await use_site("sino")
	assert(world.won and not campaign.unlocked(campaign.region("brasa")))
	await return_from_result()
	print("PASS Abismo: pré-aviso, deslocamento pela rajada, abrigo opcional e ponte com colisão.")


func defeat_guardian() -> void:
	var boss = world._boss
	hero.select_weapon(true)
	await frames(56)
	var enraged := false
	var previous_hero_health: int = world.life.current
	var previous_boss_health: int = boss.receiver.health
	for tick in 3500:
		if not is_instance_valid(boss):
			break
		var gap: Vector2 = boss.position - hero.position
		hero.run_latched = absf(gap.x) > 150.0
		enraged = enraged or boss.angry
		if boss.state == FOE.State.DEAD:
			hero.touch_axis = 0.0
		elif boss.state == FOE.State.WINDUP or boss.state == FOE.State.STRIKE:
			hero.run_latched = true
			if boss.rupture:
				var escape := signf(hero.position.x - boss._cracks[0]) if not boss._cracks.is_empty() else 0.0
				hero.touch_axis = escape if escape != 0.0 else -signf(gap.x)
			elif boss.attack == FOE.Move.STOMP:
				hero.touch_axis = 0.0
				if boss.state == FOE.State.STRIKE and boss.age > 0.04 and hero.is_on_floor():
					hero.request_jump()
			else:
				var safe_distance := 222.0 if boss.attack == FOE.Move.CHARGE else 198.0
				hero.touch_axis = -signf(gap.x) if absf(gap.x) < safe_distance else 0.0
				if boss.attack == FOE.Move.CHARGE and boss.state == FOE.State.WINDUP and boss.time < 0.26:
					hero.request_jump()
		else:
			hero.touch_axis = signf(gap.x) if absf(gap.x) > 62.0 else 0.0
			if absf(gap.x) < 82.0 and (hero.current_strike() == null or hero.strike_link_open()):
				hero.request_attack()
		await physics_frame
		if is_instance_valid(boss) and (world.life.current != previous_hero_health or boss.receiver.health != previous_boss_health):
			previous_hero_health = world.life.current
			previous_boss_health = boss.receiver.health
			print("Soberano: golpe=", boss.attack, " distância=", snappedf(absf(gap.x), 0.1),
				" PV ", previous_hero_health, "/", previous_boss_health)
		assert(not world.ended or world.won, "Andarilho derrotado no confronto com o Soberano.")
	assert(not is_instance_valid(boss) and enraged and world.progress.cursor == 2, "O Soberano deve ser derrotado no limite do teste.")


func coroa() -> void:
	await map_enter("gelo3")
	await reach(713)
	await reach(818, 535.0, true)
	await reach(930, 550.0, true)
	await reach(1208)
	await use_site("braseiro")
	await frames(55)
	assert(not is_instance_valid(world._gate) and world.progress.cursor == 1)
	assert(is_instance_valid(world._sanctum_gate))
	await reach(1820)
	await frames(34)
	world._hurt(100, 0.0, true)
	assert(world.ended and not world.won)
	assert("gelo3" not in campaign.read_slot(campaign.active_slot).completed)
	await frames(6)
	await tap(result_button("Tentar chefe de novo"))
	world = current_scene
	hero = world._player
	assert(not world.ended and world.life.current == 100 and world._arena_retry_available())
	assert(absf(hero.position.x - world.route.arena_retry_x) < 5.0 and hero.is_on_floor())
	assert(world.progress.cursor == 1 and world.sites.braseiro.used and not is_instance_valid(world._gate))
	assert(is_instance_valid(world._sanctum_gate))
	assert(world._boss.receiver.health == world._boss.receiver.max_health)
	await defeat_guardian()
	assert("gelo3" in campaign.read_slot(campaign.active_slot).completed)
	assert("gelo3" in campaign.read_slot(campaign.active_slot).seals)
	assert(world.won and "gelo3" in campaign.seals and campaign.unlocked(campaign.region("brasa")))
	await return_from_result()
	print("PASS Fortaleza: cisterna, preparação, dois portões, revanche imediata, avanço automático e selo persistente.")


func run() -> void:
	campaign = root.get_node("Campaign")
	var preferences = root.get_node("Preferences")
	if campaign.has_saved():
		quit(2)
		return
	var fps := 30 if "30" in OS.get_cmdline_user_args() else 60
	preferences.values.reduced_motion = true
	preferences.values.large_text = true
	preferences.values.hud_size = 150
	preferences.values.fps = fps
	preferences.apply()
	root.size = Vector2i(2340, 1080) if fps == 30 else Vector2i(1920, 1080)
	assert(campaign.start(1) == OK and campaign.open_chapter("gelo") != OK)
	for id in ["mata1", "mata2", "mata3", "mata4", "mata5"]:
		assert(campaign.enter_stage(id) and campaign.finish_stage() == OK)
	assert(campaign.open_chapter("gelo") == OK)
	assert(not campaign.unlocked(campaign.stage_data("gelo2")))
	campaign.return_to_map = true
	assert(change_scene_to_file(ATLAS) == OK)
	await frames(6)
	await map_enter("gelo1")
	var before: Array = campaign.completed.duplicate()
	world._go_back()
	await frames(5)
	assert(current_scene.map_open and campaign.completed == before)
	await map_enter("gelo1")
	for fall in 5:
		await reach(957)
		hero.run_latched = false
		hero.touch_axis = 1.0
		await frames(43)
		hero.touch_axis = 0.0
		await frames(6)
		if world.ended:
			break
	assert(world.ended and not world.won and campaign.completed == before)
	await tap(result_button("Reiniciar fase"))
	assert(current_scene.life.current == 100 and not current_scene.ended)
	current_scene._go_back()
	await frames(5)
	await porto()
	await passo()
	await coroa()
	campaign.leave()
	assert(campaign.resume(1) == OK and campaign.chapter == "gelo")
	assert(campaign.completed.slice(-3) == ["gelo1", "gelo2", "gelo3"])
	assert(campaign.unlocked(campaign.region("brasa")) and not campaign.unlocked(campaign.region("ruina")))
	print("PASS salvamento e toque das Terras Congeladas em ", root.size, " / ", fps, " FPS.")
	preferences.stop_audio()
	current_scene.queue_free()
	await create_timer(0.28).timeout
	quit()
