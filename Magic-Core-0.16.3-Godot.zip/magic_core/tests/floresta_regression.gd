extends SceneTree

var campaign
var scene
var actor

func _initialize() -> void:
	call_deferred("run")
	create_timer(150).timeout.connect(func(): quit(2))

func ticks(n: int) -> void:
	for i in n: await physics_frame

func at(point: Vector2) -> void:
	actor.position = point
	actor.velocity = Vector2.ZERO
	actor.reset_physics_interpolation()
	actor.reset_attack_sweep()
	await ticks(4)

func visit(key: String) -> void:
	for marker in scene.sites:
		if marker.key==key:
			await at(marker.point)
			assert(scene.interact.visible)
			scene.interact.pressed.emit()
			return
	assert(false)

func level(n: int) -> void:
	assert(campaign.enter_stage("mata%d"%n))
	assert(change_scene_to_file(campaign.stage_data(campaign.stage).scene)==OK)
	await ticks(5)
	scene = current_scene
	actor = scene._player
	assert(actor.is_on_floor() and scene.hp==100)

func fight(foe) -> void:
	var x: float = foe.position.x - 65
	await at(Vector2(x, scene.surface_at(x) - 2))
	actor.select_weapon(true)
	await ticks(56)
	for i in 1000:
		if not is_instance_valid(foe) or foe.receiver.health<=0: break
		if foe.kind==2 and foe.state==foe.State.WINDUP and foe.time<0.20:
			if foe.attack==1: actor.request_jump()
			else:
				actor.position.x = foe.position.x-foe.side*160
				actor.reset_attack_sweep()
		if foe.kind==2 and foe.state==foe.State.STRIKE:
			await ticks(1)
			continue
		if i%14==0:
			# Keep the sword facing the same intended contact while the enemy recoils.
			var approach: float = foe.position.x - 71
			var floor: float = scene.surface_at(approach)
			if is_finite(floor) and absf(actor.position.y - floor) > 14.0:
				actor.position.y = floor - 1.0
			actor.position.x = approach
			actor.reset_attack_sweep()
			actor.touch_axis = 1
		if i%14==1:
			actor.touch_axis = 0
			actor.request_attack()
		await ticks(1)
		assert(scene.hp>0)
	assert(not is_instance_valid(foe) or foe.receiver.health==0)
	await ticks(50)

func run() -> void:
	campaign = root.get_node("Campaign")
	if campaign.has_saved(): quit(2); return
	assert(campaign.start(1)==OK)
	assert(not campaign.unlocked(campaign.stage_data("mata2")))
	await level(1)
	var foe = scene.foes[0]
	await at(foe.position-Vector2(52,0))
	await ticks(160)
	assert(scene.hp<100 and foe.count>0)
	assert(scene.life.capacity==100)
	var health: int = scene.hp
	scene.hurt(5,0)
	var after: int = scene.hp
	scene.hurt(5,0)
	assert(scene.hp==after and after<=health)
	await at(Vector2(1190,540))
	await visit("rest")
	assert(scene.hp>after and scene.used.has("rest"))
	var treated: int = scene.hp
	scene.activate()
	assert(scene.hp==treated)
	await fight(foe)
	var other = scene.foes[0]
	await at(other.position-Vector2(30,0))
	await ticks(32)
	await at(Vector2(2050,540))
	await ticks(20)
	assert(other.memory>0 and not other.spotted)
	while scene.hp>0:
		scene.hurt(35,0)
		await ticks(54)
	assert(scene.ended and not scene.won and campaign.completed.is_empty())
	var restart = scene._hud.find_children("*","Button",true,false)
	var restarted := false
	for btn in restart:
		if btn.text=="Reiniciar fase":
			btn.pressed.emit()
			restarted=true
			break
	assert(restarted)
	await ticks(8)
	scene=current_scene
	actor=scene._player
	assert(scene.hp==100)
	await visit("exit")
	assert(scene.won)
	await level(2)
	await at(Vector2(478,479))
	assert(actor.is_on_floor())
	actor.request_jump()
	await ticks(10)
	assert(actor.position.y<447)
	await at(Vector2(715,760))
	assert(actor.position.y<600 and scene.hp==80)
	await visit("trail")
	var deck_count: int = scene.ledges.size()
	await visit("bridge")
	await ticks(55)
	assert(scene.ledges.size()==deck_count+1 and scene.used.has("bridge"))
	await visit("exit")
	assert(scene.won)
	await level(3)
	await visit("seal")
	assert(not scene.ended)
	await visit("secret")
	await visit("echo")
	await visit("seal")
	assert(scene.won)
	await level(4)
	await at(Vector2(1950,540))
	actor.touch_axis = 1
	await ticks(50)
	actor.touch_axis = 0
	assert(actor.position.x<2005 and actor.is_on_wall())
	await visit("bolt")
	assert(is_instance_valid(scene.gate) and not scene.used.has("bolt"))
	await visit("winch")
	await visit("bolt")
	var initial_height: float = scene.gate.position.y
	await ticks(19)
	assert(scene.gate.position.y<initial_height)
	await ticks(40)
	assert(not is_instance_valid(scene.gate))
	await fight(scene.foes[1])
	await visit("exit")
	await level(5)
	var boss = scene.foes[0]
	var actual_hits := 0
	# Wait in range and verify the character is safe until the active motion.
	for pattern in 3:
		await at(boss.position-Vector2(65,0))
		for i in 260:
			await ticks(1)
			if boss.state==boss.State.WINDUP and boss.attack==pattern: break
		assert(boss.state==boss.State.WINDUP and boss.attack==pattern)
		var before: int = scene.hp
		while boss.state == boss.State.WINDUP and boss.time > 0.06:
			await ticks(1)
		assert(scene.hp == before)
		await ticks(39)
		if scene.hp < before:
			actual_hits += 1
		await at(boss.position-Vector2(265,0))
		await ticks(64)
	assert(actual_hits >= 2 and scene.hp > 0)
	await level(5)
	boss = scene.foes[0]
	await fight(boss)
	assert(scene.won and campaign.seals.has("mata5"))
	scene._go_back()
	await ticks(7)
	assert(current_scene.map_open)
	campaign.leave()
	assert(campaign.resume(1)==OK and campaign.completed.size()==5 and campaign.open_chapter("gelo")==OK)
	print("PASS: cinco fases, dano real, memória, queda, cura, morte, reinício, espada, mecanismos, chefe, vitória persistida e retorno.")
	root.get_node("Preferences").stop_audio()
	await ticks(14)
	quit()
