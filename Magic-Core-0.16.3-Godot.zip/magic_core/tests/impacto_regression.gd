extends SceneTree
## Run in a disposable profile. Pass -- 30fps to repeat with the lower draw cap.

const ROOM := "res://scenes/world/test_world.tscn"
const Strike := preload("res://characters/player/sword_strike.gd")
const Impact := preload("res://systems/combat/ancestral_impact.gd")
const Receiver := preload("res://systems/combat/impact_receiver.gd")
const Trace := preload("res://characters/player/strike_trace.gd")

var actor: CharacterBody2D
var target: Receiver
var figure: Node2D
var hud: Control
var wheel: Control


func _initialize() -> void:
	_run.call_deferred()
	create_timer(40.0).timeout.connect(func() -> void: quit(1))


func _run() -> void:
	var prefs := root.get_node("Preferences")
	prefs.values.fps = 30 if OS.get_cmdline_user_args().has("30fps") else 60
	prefs.values.hud_size = 150
	prefs.apply()
	await _room()
	_check_formula()
	var quick := await _measure(0, 1.0)
	var upward := await _measure(1, -1.0)
	var heavy := await _measure(2, 1.0)
	assert(quick.x > 3.0 and quick.y < 2.5)
	assert(upward.y > 5.0 and upward.y > quick.y)
	assert(heavy.z > upward.z * 2.0 and heavy.z > quick.z * 2.0)
	print("PASS: deslocamento lateral, elevação e compressão por tipo. ", quick, " | ", upward, " | ", heavy)
	await _no_contact()
	await _input_during_pause()
	print("PASS: contato confirmado, janela física, alvo derrubado, rastro curto e micropausa local com multitoque.")
	prefs.stop_audio()
	await create_timer(0.2).timeout
	quit()


func _room() -> void:
	assert(change_scene_to_file(ROOM) == OK)
	await process_frame
	await process_frame
	actor = current_scene.get_node("Personagem")
	target = current_scene.get_node("Alvo")
	figure = actor.get_node("Visual")
	hud = current_scene.get_node("Interface/Comandos")
	wheel = current_scene.get_node("Interface/Arsenal")
	await _ticks(5)
	_tap(1, &"arsenal")
	_touch(2, wheel._center + Vector2(145.0, 0.0) * wheel._unit, true)
	_touch(2, wheel._center + Vector2(145.0, 0.0) * wheel._unit, false)
	await _ticks(55)
	assert(actor.can_attack())


func _check_formula() -> void:
	var profile: Strike = actor.sword_combo[2]
	var velocity := Vector2(370, 590)
	var a := Impact.new(profile, velocity, 1.0, 0.2, 1.0, true, Vector2(130, 0))
	var b := Impact.new(profile, velocity, 1.0, 0.2, 1.0, true, Vector2(130, 0))
	var mirror := Impact.new(profile, Vector2(-370, 590), -1.0, 0.2, 1.0, true, Vector2(-130, 0))
	var resistant := Impact.new(profile, velocity, 1.0, 1.9, 1.0, true, Vector2(130, 0))
	var airborne := Impact.new(profile, velocity, 1.0, 0.2, 1.0, false, Vector2(130, 0))
	var glancing := Impact.new(profile, velocity * 0.15, 1.0, 0.2, 1.0, true, Vector2(130, 0))
	var gentle := Impact.new(profile, velocity, 1.0, 0.2, 0.45, true, Vector2(130, 0))
	assert(a.direction == b.direction and a.strength == b.strength and a.pause == b.pause)
	assert(is_equal_approx(a.direction.x, -mirror.direction.x) and is_equal_approx(a.direction.y, mirror.direction.y))
	assert(resistant.strength < a.strength and airborne.strength < a.strength and glancing.strength < a.strength)
	assert(gentle.strength < a.strength and gentle.pause < a.pause and gentle.damage == a.damage)
	a.source_id = 975
	a.sequence = 1
	assert(target.receive_strike(a))
	assert(not target.receive_strike(a) and target.health == 2)
	print("PASS: força determinística, espelhamento, resistência, velocidade, estado, intensidade e rejeição de duplicata.")


func _measure(index: int, side: float) -> Vector3:
	await _room()
	var profile: Strike = actor.sword_combo[index]
	actor.sword_combo = [profile] as Array[Strike]
	await _aim(side)
	var point := target.position
	_tap(1, &"attack")
	var peak := Vector3.ZERO
	var counted := false
	var previous_phase := 0.0
	var held_frames := 0
	var trace_seen := false
	for i in range(71):
		await _ticks(1)
		var phase: float = actor.strike_progress()
		assert(target.position.y <= point.y + 0.01)
		peak.x = maxf(peak.x, (target.position.x - point.x) * side)
		peak.y = maxf(peak.y, point.y - target.position.y)
		peak.z = maxf(peak.z, target.compression)
		var trace = figure._trace
		assert(trace._count <= Trace.CAPACITY)
		trace_seen = trace_seen or trace._count > 1
		if target.health == 2 and not counted:
			assert(phase >= profile.active_start and previous_phase <= profile.active_end)
			assert(actor._contact_pause > 0 and not trace._contacts.is_empty())
			counted = true
		if phase > 0.0 and phase == previous_phase:
			held_frames += 1
		previous_phase = phase
	assert(counted and trace_seen and target.health == 2 and held_frames in [1, 2, 3, 4])
	assert(figure._trace._count == 0 and figure._trace._contacts.is_empty())
	assert(target.position.distance_to(point) < 0.03 and is_zero_approx(target.compression))
	assert(actor.strike_progress() < 0.0)
	return peak


func _no_contact() -> void:
	await _room()
	await _aim(1.0)
	var middle := target.position
	target.set_anchor(middle + Vector2(269, 0))
	_tap(1, &"attack")
	var wake := false
	for i in range(30):
		await _ticks(1)
		wake = wake or figure._trace._count > 0
		assert(figure._trace._contacts.is_empty() and is_zero_approx(actor._contact_pause))
	assert(wake and target.health == 3 and not actor.get_node("Contato").playing)
	target.set_anchor(middle)
	assert(target.take_hit(3))
	_tap(1, &"attack")
	for i in range(32):
		await _ticks(1)
		assert(target.health == 0 and figure._trace._contacts.is_empty() and is_zero_approx(actor._contact_pause))
	assert(target.respawn > 0.0 and not actor.get_node("Contato").playing)
	await _ticks(47)
	assert(target.health == 3)


func _input_during_pause() -> void:
	await _room()
	var original: Strike = actor.sword_combo[0]
	actor.sword_combo[0] = original.duplicate()
	actor.sword_combo[0].chain_open = 0.32
	actor.hitstop_intensity = 1.5
	await _aim(1.0)
	_tap(1, &"attack")
	for i in range(16):
		await _ticks(1)
		if actor._contact_pause > 0:
			break
	assert(actor._contact_pause > 0 and actor.strike_link_open())
	var frozen: float = actor.strike_progress()
	var stance := actor.position
	var target_position := target.position
	var hud_before: float = hud.direction
	_touch(0, _point(&"right"), true)
	_tap(2, &"attack")
	_tap(3, &"jump")
	assert(hud.direction != hud_before and actor.touch_axis > 0.0)
	await _ticks(1)
	assert(actor.strike_progress() == frozen and actor.position == stance)
	assert(target.position == target_position and Engine.time_scale == 1.0 and hud.visible)
	for i in range(44):
		await _ticks(1)
		if not actor.is_on_floor():
			break
	assert(not actor.is_on_floor())
	var linked := false
	for i in range(39):
		await _ticks(1)
		linked = linked or actor.current_strike() == actor.sword_combo[1]
	assert(linked)
	_touch(0, _point(&"right"), false)


func _aim(side: float) -> void:
	actor.position.x = target.position.x - 82.0 * side
	actor.reset_physics_interpolation()
	var p := _point(&"right" if side > 0.0 else &"left")
	_touch(0, p, true)
	await _ticks(1)
	_touch(0, p, false)
	await _ticks(7)
	assert(figure.transform.x.x == side)


func _point(key: StringName) -> Vector2:
	return hud._origin + hud.centers[key] * hud._unit


func _tap(index: int, action: StringName) -> void:
	var p := _point(action)
	_touch(index, p, true)
	_touch(index, p, false)


func _touch(index: int, point: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = point
	event.pressed = pressed
	root.push_input(event, true)


func _ticks(count: int) -> void:
	for i in range(count):
		await physics_frame
