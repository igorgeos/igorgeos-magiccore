extends SceneTree

func _initialize() -> void:
	check.call_deferred()

func check() -> void:
	var campaign = root.get_node("Campaign")
	assert(campaign.start(1)==OK)
	assert(campaign.enter_stage("mata1"))
	change_scene_to_file(campaign.stage_data("mata1").scene)
	await process_frame
	await process_frame
	var host = current_scene
	for kind in 3:
		var body = preload("res://scenes/forest/foe.gd").new()
		body.kind=kind
		body.hero=host._player
		host.add_child(body)
		body.set_physics_process(false)
		var rig=body.rig
		assert(rig.get_child_count()==1 and rig.skin.get_bone_count()==23)
		var parts=rig.skin.find_children("*","Polygon2D",false,false)
		var textures=[]
		for part in parts: textures.append(part.texture.get_instance_id())
		assert(textures.size()==5)
		for attack in (3 if kind==2 else 1):
			body.attack=attack
			var start: Vector2
			var peak:=0.0
			for state in [body.State.PURSUE,body.State.WINDUP,body.State.STRIKE,body.State.RECOVER,body.State.HURT,body.State.DEAD]:
				body.change(state,0.7)
				if state==body.State.WINDUP: start=rig.pose[8]
				for frame in 42:
					body.age+=1.0/60
					body.time-=1.0/60
					rig.tick(1.0/60,-1.1 if state==body.State.PURSUE else 0.0)
					if state==body.State.STRIKE: peak=maxf(peak,rig.pose[8].distance_to(start))
					for i in parts.size():
						assert(parts[i].visible and parts[i].texture.get_instance_id()==textures[i])
					for point in rig.pose: assert(point.is_finite())
			print("Criatura ",kind," golpe ",attack," percurso mínimo da extremidade ",peak)
			assert(peak>10)
		body.queue_free()
	host._player.touch_axis=0
	root.get_node("Preferences").stop_audio()
	current_scene.queue_free()
	await create_timer(0.32).timeout
	print("PASS: esqueleto único e as mesmas cinco superfícies durante passos, golpes, recuperação, dano e queda.")
	quit()
