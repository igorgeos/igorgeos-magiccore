extends Node

const Story := preload("res://systems/story.gd")
const LocalConfig := preload("res://systems/local_config.gd")
const SLOT_COUNT := 3
const SCHEMA := 1
const EMPTY := "empty"
const SAVED := "saved"
const UNREADABLE := "unreadable"

const ATLAS := "res://scenes/atlas/atlas.tscn"
var regions: Array = JSON.parse_string(FileAccess.get_file_as_string("res://scenes/atlas/regions.json"))
var completed: Array = []
var seals: Array = []
var chapter := "mata"
var visited_atlas := false
var stage := ""
var chart_zoom := 1.0
var chart_offset := Vector2.ZERO
var chart_slot := 0
var chart_region := ""
var return_to_map := false

func region(id: String) -> Dictionary:
	for item in regions:
		if item.id == id:
			return item
	return {}

func stage_data(id: String) -> Dictionary:
	for part in regions:
		for item in part.stages:
			if item.id == id:
				return item
	return {}

func unlocked(item: Dictionary) -> bool:
	if item.is_empty():
		return false
	if not item.has("stages") and item.id in completed:
		return true
	for prerequisite in item.requires:
		var record := seals if item.has("stages") else completed
		if prerequisite not in record:
			return false
	return true

func open_chapter(id: String) -> Error:
	if not unlocked(region(id)):
		return ERR_UNAVAILABLE
	return _write_checkpoint(active_slot, checkpoint, completed, id, true, seals)

func enter_stage(id: String) -> bool:
	var part := region(chapter)
	var item := stage_data(id)
	if not unlocked(part) or not unlocked(item) or item not in part.stages:
		return false
	stage = id
	return_to_map = true
	return true

func finish_stage() -> Error:
	if stage.is_empty() or not enter_stage(stage):
		return ERR_UNAVAILABLE
	var next := completed.duplicate()
	if stage not in next:
		next.append(stage)
	var earned := seals.duplicate()
	if stage_data(stage).get("final_challenge", false) and stage not in earned:
		earned.append(stage)
	return _write_checkpoint(active_slot, checkpoint, next, chapter, true, earned)

func quick_start() -> Error:
	if active_slot > 0:
		return OK
	var latest := 0
	var stamp := -1
	var vacant := 0
	for slot in range(1, SLOT_COUNT + 1):
		var data := read_slot(slot)
		if data.state == SAVED:
			var time := FileAccess.get_modified_time(_path(slot))
			if time > stamp:
				stamp = time
				latest = slot
		elif data.state == EMPTY and vacant == 0:
			vacant = slot
	if latest > 0:
		return resume(latest)
	return start(vacant) if vacant > 0 else ERR_FILE_CORRUPT

var show_saved_on_entry := false
var active_slot := 0
var checkpoint := ""


func read_slot(slot: int) -> Dictionary:
	if not _in_range(slot) or not FileAccess.file_exists(_path(slot)):
		return {"state": EMPTY}
	var config := ConfigFile.new()
	if config.load(_path(slot)) != OK:
		return {"state": UNREADABLE}
	var saved_checkpoint: Variant = config.get_value("campanha", "checkpoint", "")
	if config.get_value("campanha", "versao", 0) != SCHEMA or not Story.CHECKPOINTS.has(saved_checkpoint):
		return {"state": UNREADABLE}
	var legacy: Array = []
	var marks: Variant = config.get_value("atlas", "completed", [])
	if marks is Array and not config.has_section_key("atlas","seals"):
		for part in regions:
			for id in part.requires:
				if id in marks:
					legacy.append(id)
	return {
		"seals": config.get_value("atlas","seals",legacy),
		"state": SAVED,
		"visited_atlas": config.get_value("atlas", "visited", false),
		"completed": config.get_value("atlas", "completed", []),
		"chapter": config.get_value("atlas", "chapter", "mata"),
		"checkpoint": saved_checkpoint,
		"updated": str(config.get_value("campanha", "atualizado", "")),
	}


func has_saved() -> bool:
	for slot in range(1, SLOT_COUNT + 1):
		if read_slot(slot).state != EMPTY:
			return true
	return false


func start(slot: int, replace := false) -> Error:
	if not _in_range(slot):
		return ERR_INVALID_PARAMETER
	if not replace and read_slot(slot).state != EMPTY:
		return ERR_ALREADY_EXISTS
	return _write_checkpoint(slot, Story.FIRST)


func resume(slot: int) -> Error:
	var data := read_slot(slot)
	if data.state != SAVED:
		return ERR_FILE_CORRUPT if data.state == UNREADABLE else ERR_FILE_NOT_FOUND
	active_slot = slot
	checkpoint = data.checkpoint
	visited_atlas = data.visited_atlas == true
	completed = data.completed if data.completed is Array else []
	seals = data.seals if data.seals is Array else []
	chapter = str(data.chapter)
	if not unlocked(region(chapter)):
		chapter = "mata"
	stage = ""
	return_to_map = false
	return OK


func advance() -> Error:
	if not _in_range(active_slot) or not Story.CHECKPOINTS.has(checkpoint):
		return ERR_UNCONFIGURED
	var destination: String = Story.CHECKPOINTS[checkpoint].next
	if destination.is_empty():
		return ERR_UNAVAILABLE
	return _write_checkpoint(active_slot, destination, completed, chapter, visited_atlas, seals)


func leave() -> void:
	active_slot = 0
	checkpoint = ""
	completed = []
	seals = []
	chapter = "mata"
	stage = ""
	return_to_map = false


func _write_checkpoint(slot: int, destination: String, marks: Array = [], region_id := "mata", visited := false, earned: Array = []) -> Error:
	if not _in_range(slot):
		return ERR_INVALID_PARAMETER
	var now := Time.get_datetime_dict_from_system()
	var date := "%02d/%02d/%04d às %02d:%02d" % [
		now.day, now.month, now.year, now.hour, now.minute,
	]
	var config := ConfigFile.new()
	config.set_value("campanha", "versao", SCHEMA)
	config.set_value("campanha", "checkpoint", destination)
	config.set_value("campanha", "atualizado", date)
	config.set_value("atlas", "completed", marks)
	config.set_value("atlas", "seals", earned)
	config.set_value("atlas", "chapter", region_id)
	config.set_value("atlas", "visited", visited)
	var error := LocalConfig.write(config, _path(slot))
	if error == OK:
		active_slot = slot
		checkpoint = destination
		completed = marks
		seals = earned
		chapter = region_id
		visited_atlas = visited
	return error


func _in_range(slot: int) -> bool:
	return slot >= 1 and slot <= SLOT_COUNT


func _path(slot: int) -> String:
	return "user://campanha_%d.cfg" % slot
