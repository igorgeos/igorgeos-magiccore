extends RefCounted


static func write(config: ConfigFile, path: String) -> Error:
	var temporary := path + ".tmp"
	var error := config.save(temporary)
	if error != OK:
		return error
	# O arquivo anterior permanece disponível até a substituição.
	return DirAccess.rename_absolute(
		ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(path))
