extends Node

signal changed

const LocalConfig := preload("res://systems/local_config.gd")
const FILE := "user://preferencias.cfg"
const NAVIGATION_PATH := "res://audio/giro_do_selo.ogg"
const HUD_MIN := 100
const HUD_MAX := 150
const DEFAULTS := {
	"music": 55, "effects": 70, "navigation": 70, "fps": 60, "visual_quality": 2,
	"brightness": 100, "reduced_motion": false, "vibration": true, "large_text": false,
	"high_contrast": false, "hud_size": HUD_MIN, "swipe_enabled": true, "swipe_sensitivity": 1,
	"menu_previous": KEY_LEFT, "menu_next": KEY_RIGHT, "menu_confirm": KEY_ENTER, "menu_back": KEY_ESCAPE,
}
const MENU_ACTIONS := {
	"menu_previous": "ui_left", "menu_next": "ui_right",
	"menu_confirm": "ui_accept", "menu_back": "ui_cancel",
}

var values := DEFAULTS.duplicate()
var _ambience: AudioStreamPlayer
var _navigation: AudioStreamPlayer
var _confirm: AudioStreamPlayer


func _ready() -> void:
	var config := ConfigFile.new()
	if config.load(FILE) == OK:
		for key in DEFAULTS:
			var stored: Variant = config.get_value("preferencias", key, DEFAULTS[key])
			if typeof(stored) == typeof(DEFAULTS[key]):
				values[key] = stored
		if not config.has_section_key("preferencias", "navigation"):
			values.navigation = values.effects
		for key in ["music", "navigation", "effects"]:
			values[key] = clampi(values[key], 0, 100)
		values.fps = 30 if values.fps == 30 else 60
		values.visual_quality = clampi(values.visual_quality, 0, 2)
		values.swipe_sensitivity = clampi(values.swipe_sensitivity, 0, 2)
		values.brightness = clampi(values.brightness, 60, 125)
		values.hud_size = clampi(values.hud_size, HUD_MIN, HUD_MAX)
	_ambience = AudioStreamPlayer.new()
	var ambience_stream := load("res://audio/vale_noturno.ogg") as AudioStreamOggVorbis
	if ambience_stream != null:
		ambience_stream.loop = true
	_ambience.stream = ambience_stream
	add_child(_ambience)
	_navigation = AudioStreamPlayer.new()
	if ResourceLoader.exists(NAVIGATION_PATH, "AudioStream"):
		_navigation.stream = load(NAVIGATION_PATH) as AudioStream
	add_child(_navigation)
	_confirm = AudioStreamPlayer.new()
	_confirm.stream = load("res://audio/selo.ogg") as AudioStream
	add_child(_confirm)
	apply()


func apply() -> void:
	Engine.max_fps = values.fps
	_ambience.volume_linear = values.music / 100.0
	_navigation.volume_linear = values.navigation / 100.0
	_confirm.volume_linear = values.effects / 100.0
	for action in MENU_ACTIONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		InputMap.action_erase_events(action)
		var keyboard := InputEventKey.new()
		keyboard.physical_keycode = values[action]
		InputMap.action_add_event(action, keyboard)
		for event in InputMap.action_get_events(MENU_ACTIONS[action]):
			if not event is InputEventKey:
				InputMap.action_add_event(action, event)
	changed.emit()


func start_ambience() -> void:
	if _ambience.stream != null and not _ambience.playing:
		_ambience.play()


func stop_audio() -> void:
	_ambience.stop()
	_navigation.stop()
	_confirm.stop()


func navigation_feedback() -> void:
	if values.navigation > 0 and _navigation.stream != null:
		_navigation.play()


func feedback(haptic := false) -> void:
	if values.effects > 0 and _confirm.stream != null:
		_confirm.play()
	if haptic and values.vibration and OS.has_feature("android"):
		Input.vibrate_handheld(24)


func save() -> Error:
	var config := ConfigFile.new()
	for key in values:
		config.set_value("preferencias", key, values[key])
	return LocalConfig.write(config, FILE)


func text_size(base: int) -> int:
	return roundi(base * 1.16) if values.large_text else base


func art_tint(base := 1.0) -> Color:
	var brightness: float = values.brightness / 100.0 * base
	if values.high_contrast:
		brightness *= 0.54
	return Color(brightness, brightness, brightness, 1.0)
