extends RefCounted

const FIRST := "sino"
const CHAPTERS := {
	"passagem": {"title": "Capítulo I · A passagem do sino", "label": "Capítulo I", "length": 3},
}
const INTRO := "Na noite em que o sino do reino se partiu, o Núcleo foi selado sob a montanha. Agora, sob as ruínas, uma luz voltou a arder.\n\nO chamado chega quando você ainda está na estrada. A única passagem para a montanha cruza a velha ponte do sino."
const CHECKPOINTS := {
	"sino": {
		"chapter": "passagem",
		"title": "O sino sem badalo",
		"body": "A chuva apagou as pegadas na ponte, mas não o risco azul que atravessa as pedras. Sob a torre partida, o sino toca uma vez. Seu badalo está no chão, a alguns passos de você.",
		"action": "Seguir o risco azul",
		"next": "selo",
		"page": 1,
	},
	"selo": {
		"chapter": "passagem",
		"title": "O selo sob a ponte",
		"body": "O risco termina num selo de ferro embutido no parapeito. Entre os nomes gravados, há um que você reconhece. É o seu, escrito na mesma mão que assinou o decreto para enterrar o Núcleo.",
		"action": "Descer ao santuário",
		"next": "santuario",
		"page": 2,
	},
	"santuario": {
		"chapter": "passagem",
		"title": "A porta do santuário",
		"body": "Atrás do parapeito, uma escada desce até uma porta de pedra. A luz passa pela fechadura. Do outro lado, alguém repete seu nome e pede que você deixe o sino tocar de novo.",
		"action": "",
		"next": "",
		"page": 3,
	},
}
