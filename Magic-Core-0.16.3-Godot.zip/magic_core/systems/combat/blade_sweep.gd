extends RefCounted

const TARGET_LAYER := 4
const SAMPLE_SPACING := 5.0
const MAX_SAMPLES := 11
const Strike := preload("res://characters/player/sword_strike.gd")
const Receiver := preload("res://systems/combat/impact_receiver.gd")

var _hit_targets := {}
var _shape := RectangleShape2D.new()
var _query := PhysicsShapeQueryParameters2D.new()
var _previous_grip := Vector2.ZERO
var _previous_tip := Vector2.ZERO
var _has_previous := false
var _probe_length := -1.0
var _record_trail: Callable
var _record_contact: Callable


func _init(record_trail: Callable, record_contact: Callable) -> void:
	_record_trail = record_trail
	_record_contact = record_contact
	_query.shape = _shape
	_query.collision_mask = TARGET_LAYER
	_query.collide_with_bodies = false
	_query.collide_with_areas = true


func begin() -> void:
	_hit_targets.clear()
	reset_position()


func reset_position() -> void:
	_has_previous = false


func advance(space: PhysicsDirectSpaceState2D, profile: Strike, previous: float, progress: float,
		grip: Vector2, tip: Vector2, delta: float) -> void:
	if not _has_previous:
		_previous_grip = grip
		_previous_tip = tip
		_has_previous = true
	if progress > previous and profile.active_end > profile.active_start 			and previous < profile.active_end and progress >= profile.active_start:
		var enter := clampf(inverse_lerp(previous, progress, profile.active_start), 0.0, 1.0)
		var exit := clampf(inverse_lerp(previous, progress, profile.active_end), 0.0, 1.0)
		_sweep(space, grip, tip, enter, exit, previous <= profile.active_start, delta)
	_previous_grip = grip
	_previous_tip = tip


func _sweep(space: PhysicsDirectSpaceState2D, grip: Vector2, tip: Vector2,
		enter: float, exit: float, include_start: bool, delta: float) -> void:
	var origin := _previous_tip - _previous_grip
	var current := tip - grip
	var base_angle := origin.angle()
	var angle_change := wrapf(current.angle() - base_angle, -PI, PI)
	var base_length := origin.length()
	var current_length := current.length()
	var length_change := current_length - base_length
	var shift := grip - _previous_grip
	var travel := shift.length() + absf(angle_change) * maxf(base_length, current_length) + absf(length_change)
	var intervals := clampi(ceili(travel * (exit - enter) / SAMPLE_SPACING), 1, MAX_SAMPLES - 1)
	var inv_delta := 1.0 / maxf(delta, 0.0001)
	var translation := shift * inv_delta
	var angular_rate := angle_change * inv_delta
	var radial_rate := length_change * inv_delta
	for i in range(0 if include_start else 1, intervals + 1):
		var at := lerpf(enter, exit, float(i) / intervals)
		var handle := _previous_grip + shift * at
		var axis := Vector2.from_angle(base_angle + angle_change * at)
		var length := base_length + length_change * at
		_probe(space, handle, axis, length, translation + axis * radial_rate * 0.82, angular_rate)
		if i % 2 == 0 or i == intervals:
			_record_trail.call(handle, handle + axis * length, (1.0 - at) * delta)


func _probe(space: PhysicsDirectSpaceState2D, grip: Vector2, axis: Vector2, length: float,
		translation: Vector2, angular_rate: float) -> void:
	var base := grip + axis * length * 0.13
	var tip := grip + axis * length
	if not is_equal_approx(_probe_length, length):
		_probe_length = length
		_shape.size = Vector2(length * 0.87 + 5.0, 10.0)
	_query.transform = Transform2D(axis.angle(), (base + tip) * 0.5)
	for candidate in space.intersect_shape(_query):
		var target := candidate.collider as Receiver
		if not is_instance_valid(target) or _hit_targets.has(candidate.collider_id) or not target.can_receive_strike():
			continue
		var owner := target.shape_find_owner(candidate.shape)
		var center := target.to_global(target.shape_owner_get_transform(owner).origin)
		var point := Geometry2D.get_closest_point_to_segment(center, base, tip)
		var contact_velocity := translation + (point - grip).orthogonal() * angular_rate
		if _record_contact.call(target, point, contact_velocity):
			_hit_targets[candidate.collider_id] = true
