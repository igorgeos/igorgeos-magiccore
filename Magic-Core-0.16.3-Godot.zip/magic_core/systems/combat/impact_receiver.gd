extends Area2D
## Base for targets on the combat layer. Position and collider follow the same bounded recoil.

const Impact := preload("res://systems/combat/ancestral_impact.gd")

@export_range(1, 100, 1) var max_health := 3
@export_range(0.0, 3.0, 0.05) var impact_resistance := 0.35
@export_range(0.4, 20.0, 0.1) var respawn_delay := 1.2

var health := 3
var flash := 0.0
var respawn := 0.0
var lean := 0.0
var compression := 0.0
var offset := Vector2.ZERO

var _anchor := Vector2.ZERO
var _origin_offset := Vector2.ZERO
var _origin_lean := 0.0
var _origin_compression := 0.0
var _kick := Vector2.ZERO
var _tilt := 0.0
var _squash := 0.0
var _age := 0.0
var _recovery := 0.0
var _pause := 0.0
var _contact_tick := -1
var _latest_hit := {}


func _ready() -> void:
	_anchor = position
	health = max_health


func set_anchor(point: Vector2) -> void:
	_anchor = point
	position = _anchor + offset
	reset_physics_interpolation()


func can_receive_strike() -> bool:
	return health > 0


func take_hit(amount: int) -> bool:
	if health <= 0 or amount <= 0:
		return false
	health = maxi(0, health - amount)
	flash = 0.132
	if health == 0:
		respawn = respawn_delay
	queue_redraw()
	return true


func receive_strike(hit: Impact) -> bool:
	if hit.sequence <= _latest_hit.get(hit.source_id, -1) or not take_hit(hit.damage):
		return false
	_latest_hit[hit.source_id] = hit.sequence
	_origin_offset = offset
	_origin_lean = lean
	_origin_compression = compression
	_kick = hit.direction * hit.strength * 272.0
	_tilt = hit.direction.x * hit.strength * 0.14
	_squash = hit.compression
	_recovery = hit.recovery
	_age = 0.0
	_pause = hit.pause
	_contact_tick = Engine.get_physics_frames()
	return true


func _physics_process(delta: float) -> void:
	if flash <= 0.0 and respawn <= 0.0 and _age >= _recovery:
		return
	# A receiver processed after the attacker must hold for the same ticks.
	if Engine.get_physics_frames() == _contact_tick:
		return
	flash = maxf(0.0, flash - delta)
	if respawn > 0.0:
		respawn = maxf(0.0, respawn - delta)
		if respawn <= 0.0:
			health = max_health
	if _pause > 0.0:
		_pause = maxf(0.0, _pause - delta)
	elif _age < _recovery:
		_age = minf(_age + delta, _recovery)
		var fraction := _age / _recovery
		var rest := (1.0 - fraction) * (1.0 - fraction)
		var impulse := smoothstep(0.0, 0.22, fraction) * (1.0 - smoothstep(0.34, 1.0, fraction))
		offset = (_origin_offset + _kick * _age) * rest
		offset.x = clampf(offset.x, -24.0, 24.0)
		offset.y = clampf(offset.y, -24.0, 0.0)
		lean = _origin_lean * rest + _tilt * impulse
		compression = _origin_compression * rest + _squash * smoothstep(0.0, 0.16, fraction) * (1.0 - smoothstep(0.23, 0.86, fraction))
		position = _anchor + offset
	queue_redraw()
