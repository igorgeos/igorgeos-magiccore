extends RefCounted

const Strike := preload("res://characters/player/sword_strike.gd")

var source_id: int
var sequence: int
var damage: int
var point: Vector2
var direction: Vector2
var strength: float
var pause: float
var compression: float
var recovery: float


func _init(profile: Strike, contact_velocity: Vector2, side: float, resistance: float,
		intensity: float, grounded: bool, attacker_velocity: Vector2) -> void:
	var guide := Vector2(side * profile.impact_axis.x, profile.impact_axis.y).normalized()
	direction = guide.lerp(contact_velocity.normalized(), 0.19).normalized()
	damage = profile.damage
	var speed := smoothstep(85.0, 910.0, contact_velocity.length())
	var momentum := smoothstep(35.0, 265.0, maxf(0.0, attacker_velocity.x * side))
	var footing := 1.0 + 0.10 * momentum if grounded else 0.89 + 0.06 * momentum
	var force := profile.impact_force * lerpf(0.76, 1.13, speed) * footing * intensity
	strength = clampf(force / (1.0 + maxf(0.0, resistance) * 0.58), 0.0, 1.65)
	pause = minf(0.059, profile.impact_pause * smoothstep(0.0, 1.0, strength + strength * 0.35))
	compression = clampf(profile.impact_compression * strength, 0.0, 0.27)
	recovery = profile.impact_recovery
