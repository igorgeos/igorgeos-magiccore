extends Button
## An interaction remains available while another finger holds a movement control.

var _finger := -1


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT:
			_finger = -1
		NOTIFICATION_VISIBILITY_CHANGED:
			if not is_visible_in_tree():
				_finger = -1


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.device == InputEvent.DEVICE_ID_EMULATION:
		accept_event()
		return
	if event is not InputEventScreenTouch or disabled:
		return
	accept_event()
	if event.pressed and not event.canceled:
		if _finger < 0:
			_finger = event.index
	elif _finger == event.index:
		_finger = -1
		if not event.canceled and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit()
