extends RefCounted

const SERIF := preload("res://assets/fonts/prompt_font.ttf")
const INK := Color("#0b1420")
const TEXT := Color("#eee5d5")
const MUTED := Color("#c0c9d5")
const BLUE := Color("#86b5db")
const METAL := Color("#8b7961")


static func panel(fill: Color, border: Color, corners := 8) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(corners)
	style.content_margin_left = 15
	style.content_margin_right = 15
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style


static func button(caption: String, primary := false, instance: Button = null) -> Button:
	var node := instance if instance else Button.new()
	node.text = caption
	node.custom_minimum_size = Vector2(110, 54)
	node.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	node.add_theme_font_size_override("font_size", Preferences.text_size(22))
	node.add_theme_color_override("font_color", TEXT)
	var normal := Color("#263a50") if primary else Color("#131f2c")
	node.add_theme_stylebox_override("normal", panel(normal, Color("#63758a")))
	node.add_theme_stylebox_override("hover", panel(Color("#2b4258"), BLUE))
	node.add_theme_stylebox_override("pressed", panel(Color("#0a1421"), BLUE))
	var focus := panel(Color.TRANSPARENT, Color("#ddd0aa"))
	focus.set_border_width_all(2)
	node.add_theme_stylebox_override("focus", focus)
	return node


static func label(caption: String, font_size: int, color: Color) -> Label:
	var node := Label.new()
	node.text = caption
	node.add_theme_font_size_override("font_size", Preferences.text_size(font_size))
	node.add_theme_color_override("font_color", color)
	return node
