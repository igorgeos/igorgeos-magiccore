extends Control

signal selected(equip: bool)
signal dismissed

const Art := preload("res://ui/hud_art.gd")
const SHEATH := preload("res://characters/player/bainha_vigia.res")
const OUTER := 196.0
const INNER := 72.0
var _selection := 1
var _center := Vector2.ZERO
var _unit := 1.0


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	mouse_filter = Control.MOUSE_FILTER_STOP
	focus_mode = Control.FOCUS_ALL
	resized.connect(_layout)
	Preferences.changed.connect(_layout)
	_layout()
	hide()


func open(current: bool) -> void:
	_selection = 0 if current else 1
	_layout()
	show()
	grab_focus()
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_left"):
		_select(0)
	elif event.is_action_pressed("ui_right"):
		_select(1)
	elif event.is_action_pressed("ui_accept"):
		selected.emit(_selection == 1)
	elif event is InputEventScreenTouch and event.pressed:
		_choose_at(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if event.device != InputEvent.DEVICE_ID_EMULATION:
			_choose_at(event.position)
	elif event is InputEventMouseMotion and event.device != InputEvent.DEVICE_ID_EMULATION:
		var local: Vector2 = (event.position - _center) / _unit
		if local.length() >= INNER and local.length() <= OUTER:
			_select(int(local.x >= 0.0))
	else:
		return
	accept_event()


func _choose_at(point: Vector2) -> void:
	var local := (point - _center) / _unit
	if local.length() < INNER or local.length() > OUTER:
		dismissed.emit()
		return
	selected.emit(local.x >= 0.0)


func _select(index: int) -> void:
	_selection = index
	queue_redraw()


func _layout() -> void:
	var safe := Art.safe_rect(self)
	_unit = Art.hud_scale(safe.size, Vector2(446, 480))
	_center = safe.get_center() + Vector2(0, 20 * _unit)
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.024, 0.043, 0.050, 0.90))
	draw_set_transform(_center, 0.0, Vector2.ONE * _unit)
	var c := Vector2.ZERO
	Art.fit(self, Art.DIAL, c, Vector2.ONE * (OUTER * 2.0 + 32.0))
	for i in range(2):
		var left := i == 0
		var angle := PI if left else 0.0
		var active := _selection == i
		var tint := Art.MINT if active else Art.BRASS
		_sector(c, angle, active)
		var slot := c + Vector2.LEFT * (119.0 if left else -119.0)
		if left:
			draw_set_transform(_center + (slot + Vector2(0, -12)) * _unit, deg_to_rad(-31), Vector2.ONE * _unit)
			draw_texture_rect(SHEATH, Rect2(-43,-6,86,13), false)
			draw_set_transform(_center, 0.0, Vector2.ONE * _unit)
		else:
			Art.fit(self, Art.SYMBOLS[&"attack"], slot - Vector2(0, 16), Vector2(68, 68))
		Art.words(self, "Guardar" if left else "Espada", slot + Vector2(0, 42), 23, tint, true, true)
	Art.fit(self, Art.PORTRAIT, c - Vector2(0, 9), Vector2(87, 87))
	Art.words(self, "Fechar", c + Vector2(0, 51), 17, Art.PAPER)
	Art.fit(self, Art.PLATE, c - Vector2(0, 222), Vector2(285, 49))
	Art.words(self, "Arsenal", c - Vector2(0, 213), 29, Art.PAPER, true, true)


func _sector(center: Vector2, middle: float, active: bool) -> void:
	var outline := PackedVector2Array()
	var span := PI * 0.5 - 0.08
	for i in range(37):
		var theta := middle - span + 2.0 * span * i / 36.0
		outline.append(center + Vector2.from_angle(theta) * (OUTER - 12.0))
	for i in range(36, -1, -1):
		var theta := middle - span + 2.0 * span * i / 36.0
		outline.append(center + Vector2.from_angle(theta) * INNER)
	draw_colored_polygon(outline, Color("#233a39") if active else Color("#1b2428"))
	outline.append(outline[0])
	draw_polyline(outline, Art.MINT if active else Color("#615644"), 1.3, true)
