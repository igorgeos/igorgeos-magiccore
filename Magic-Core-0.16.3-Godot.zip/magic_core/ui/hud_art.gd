extends RefCounted

const PORTRAIT := preload("res://assets/hud/andarilho.res")
const PLATE := preload("res://assets/hud/placa.res")
const DIAL := preload("res://assets/hud/mostrador.res")
const SHIELD := preload("res://assets/hud/escudo.res")
const ROCKER := preload("res://assets/hud/direcional.res")
const SYMBOLS := {
	&"run": preload("res://assets/hud/correr.res"),
	&"jump": preload("res://assets/hud/pular.res"),
	&"attack": preload("res://assets/hud/atacar.res"),
	&"arsenal": preload("res://assets/hud/armas.res"),
	&"back": preload("res://assets/hud/voltar.res"),
}
const PAPER := Color("#f3e7cb")
const MINT := Color("#91e1d3")
const BRASS := Color("#b69d72")
const INK := Color("#142026")
const SERIF := preload("res://assets/fonts/prompt_font.ttf")


static func safe_rect(node: Control) -> Rect2:
	var rect := Rect2(Vector2.ZERO, node.size)
	if OS.has_feature("mobile"):
		var area := DisplayServer.get_display_safe_area()
		if area.has_area():
			var to_view := node.get_viewport().get_screen_transform().affine_inverse()
			var safe := (to_view * Rect2(area)).intersection(rect)
			if safe.has_area():
				return safe
	return rect


static func hud_scale(safe_size: Vector2, footprint: Vector2) -> float:
	var preferred: float = Preferences.values.hud_size / 100.0
	return maxf(0.1, minf(preferred, minf(safe_size.x / footprint.x, safe_size.y / footprint.y)))


static func fit(node: CanvasItem, texture: Texture2D, center: Vector2, box: Vector2, tint := Color.WHITE) -> void:
	var src := texture.get_size()
	var fitted := src * minf(box.x / src.x, box.y / src.y)
	node.draw_texture_rect(texture, Rect2(center - fitted * 0.5, fitted), false, tint)


static func words(node: CanvasItem, caption: String, baseline: Vector2, px: int, color: Color,
		center := true, title := false) -> void:
	var font := SERIF if title else ThemeDB.fallback_font
	var pixels := Preferences.text_size(px)
	if Preferences.values.high_contrast and color != MINT:
		color = Color.WHITE
	var pos := baseline
	if center:
		pos.x -= font.get_string_size(caption, HORIZONTAL_ALIGNMENT_LEFT, -1, pixels).x * 0.5
	node.draw_string_outline(font, pos, caption, HORIZONTAL_ALIGNMENT_LEFT, -1, pixels, 3, Color("#101516"))
	node.draw_string(font, pos, caption, HORIZONTAL_ALIGNMENT_LEFT, -1, pixels, color)
