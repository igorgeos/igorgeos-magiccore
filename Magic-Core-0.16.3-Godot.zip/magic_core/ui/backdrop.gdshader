shader_type canvas_item;
render_mode unshaded;

uniform sampler2D artwork : filter_linear, repeat_disable;
uniform float aspect = 1.77778;
uniform bool opening = false;

void fragment() {
	vec2 p = UV;
	vec2 source = p;
	float ratio = aspect / 1.77778;
	if (opening) {
		// The opening uses the castle side of the landscape; its title is a separate layer.
		source.x = 0.018 + p.x * 0.752;
		float height = min(1.0, 0.752 / ratio);
		source.y = 0.43 + (p.y - 0.5) * height;
	} else {
		// Preserve the title area on wide screens, reflecting only the outer scenery.
		source.x = 0.5 + (p.x - 0.5) * ratio;
		source.x = 1.0 - abs(1.0 - abs(source.x));
	}
	vec3 art = texture(artwork, source).rgb;
	float shade = smoothstep(0.17, 0.72, length((p - vec2(0.5, 0.37)) * vec2(1.05, 0.85)));
	float ground = smoothstep(0.39, 0.94, p.y);
	float ink = opening ? (0.64 + shade * 0.22 + ground * 0.10)
		: (0.13 + shade * 0.31 + ground * 0.44);
	art = mix(art, vec3(dot(art, vec3(0.25, 0.58, 0.17))), opening ? 0.29 : 0.16);
	COLOR = vec4(mix(art, vec3(0.017, 0.029, 0.052), clamp(ink, 0.0, 0.97)), 1.0);
}
