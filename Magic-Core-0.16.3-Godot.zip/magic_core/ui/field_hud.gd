extends Control

signal chosen(action: StringName)
signal direction_changed(axis: float)

const Art := preload("res://ui/hud_art.gd")
const CAPTIONS := {&"run": "Correr", &"jump": "Pular", &"attack": "Atacar", &"arsenal": "Armas"}
const INPUTS := {&"left": &"player_left", &"right": &"player_right", &"jump": &"player_jump",
	&"attack": &"player_attack", &"run": &"player_run"}
const HOTKEYS := {&"left": "A", &"right": "D", &"jump": "Espaço", &"attack": "J", &"run": "Shift", &"arsenal": "Q"}
const FRAME := {&"run": Vector2(83, 90), &"jump": Vector2(86, 93),
	&"attack": Vector2(126, 126), &"arsenal": Vector2(72, 77)}
const MOUSE_POINTER := -1

var direction := 0.0
var centers := {}
var _pointers := {}
var _keys := {}
var _hover: StringName = &""
var _weapon_text := "Espada na bainha"
var _progress := 0.0
var _run_mode := false
var _pace := 0.0
var _strike := -1.0
var _link_open := false
var _touch := false
var _origin := Vector2.ZERO
var _unit := 1.0
var _space := Vector2.ZERO


func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_touch = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	resized.connect(_layout)
	visibility_changed.connect(clear_pointers)
	get_window().focus_exited.connect(clear_pointers)
	Preferences.changed.connect(_layout)
	_layout()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		clear_pointers()


func _layout() -> void:
	var safe := Art.safe_rect(self)
	_origin = safe.position
	_unit = Art.hud_scale(safe.size, Vector2(740, 470))
	_space = safe.size / _unit
	var w := _space.x
	var h := _space.y
	centers = {
		&"left": Vector2(76, h - 74), &"right": Vector2(171, h - 74),
		&"run": Vector2(284, h - 82), &"attack": Vector2(w - 96, h - 105),
		&"jump": Vector2(w - 231, h - 81), &"arsenal": Vector2(w - 211, h - 187),
		&"back": Vector2(w - 89, 59),
	}
	clear_pointers()
	queue_redraw()


func clear_pointers() -> void:
	_pointers.clear()
	_hover = &""
	_update_direction()


func set_status(weapon_text: String, progress: float, run_mode: bool, pace: float, strike: float, link_open: bool) -> void:
	var change := weapon_text != _weapon_text or _progress != progress or run_mode != _run_mode
	change = change or not is_equal_approx(pace, _pace) or strike != _strike or link_open != _link_open
	_pace = pace
	_strike = strike
	_link_open = link_open
	_weapon_text = weapon_text
	_progress = progress
	_run_mode = run_mode
	for key: StringName in INPUTS:
		var down := Input.is_action_pressed(INPUTS[key])
		if _keys.get(key, false) != down:
			_keys[key] = down
			change = true
	if change:
		queue_redraw()


func _hit(point: Vector2) -> StringName:
	var p := (point - _origin) / _unit
	if centers.is_empty():
		return &""
	for key: StringName in centers:
		var diff: Vector2 = (p - centers[key]).abs()
		if key == &"back":
			if diff.x <= 66 and diff.y <= 33:
				return key
		elif key == &"left" or key == &"right":
			if diff.x < 48 and diff.y <= 45:
				return key
		else:
			var bounds: Vector2 = FRAME[key] * 0.5 + Vector2(4, 4)
			if diff.x <= bounds.x and diff.y <= bounds.y + 8:
				return key
	return &""


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	var local := make_input_local(event)
	if local is InputEventScreenTouch:
		_pointer(local.index, local.position, local.pressed and not local.canceled)
	elif local is InputEventScreenDrag:
		_drag(local.index, local.position)
	elif local is InputEventMouseButton and local.device != InputEvent.DEVICE_ID_EMULATION and local.button_index == MOUSE_BUTTON_LEFT:
		_pointer(MOUSE_POINTER, local.position, local.pressed)
	elif local is InputEventMouseMotion and local.device != InputEvent.DEVICE_ID_EMULATION:
		var over := _hit(local.position)
		if over != _hover:
			_hover = over
			queue_redraw()
		_drag(MOUSE_POINTER, local.position)


func _pointer(id: int, point: Vector2, down: bool) -> void:
	if not down:
		if _pointers.erase(id):
			_update_direction()
			get_viewport().set_input_as_handled()
		return
	var key := _hit(point)
	if key == &"" or _pointers.has(id):
		return
	get_viewport().set_input_as_handled()
	_pointers[id] = key
	_update_direction()
	if key != &"left" and key != &"right":
		chosen.emit(key)


func _drag(id: int, point: Vector2) -> void:
	if not _pointers.has(id):
		return
	var previous: StringName = _pointers[id]
	if previous not in [&"left", &"right", &"neutral"]:
		return
	var next := _hit(point)
	if next not in [&"left", &"right"]:
		next = &"neutral"
	if previous != next:
		_pointers[id] = next
		_update_direction()
	get_viewport().set_input_as_handled()


func _update_direction() -> void:
	var axis := float(_held(&"right")) - float(_held(&"left"))
	if axis != direction:
		direction = axis
		direction_changed.emit(direction)
	queue_redraw()


func _held(key: StringName) -> bool:
	return _pointers.find_key(key) != null


func _lit(key: StringName) -> bool:
	return _held(key) or _keys.get(key, false) or (key == &"run" and _run_mode)


func _draw() -> void:
	if centers.is_empty():
		return
	draw_set_transform(_origin, 0.0, Vector2.ONE * _unit)
	_draw_identity()
	_draw_back()
	_draw_rocker()
	_draw_action_track()
	for key: StringName in [&"run", &"jump", &"arsenal", &"attack"]:
		_draw_action(key)


func _draw_identity() -> void:
	var p := Vector2(67, 64)
	draw_texture_rect(Art.PLATE, Rect2(64, 28, 303, 75), false)
	Art.fit(self, Art.PORTRAIT, p, Vector2(94, 94))
	Art.words(self, "Andarilho", Vector2(123, 61), 28, Art.PAPER, false, true)
	Art.words(self, _weapon_text, Vector2(124, 86), 17, Color("#dbceb3"), false)
	if _progress > 0.0 and _progress < 1.0:
		draw_line(Vector2(125, 93), Vector2(293, 93), Color("#38413c"), 2.0)
		draw_line(Vector2(125, 93), Vector2(125 + 168 * _progress, 93), Art.MINT, 2.0)


func _draw_back() -> void:
	var c: Vector2 = centers[&"back"]
	draw_texture_rect(Art.PLATE, Rect2(c - Vector2(68, 24), Vector2(136, 48)), false)
	Art.fit(self, Art.SYMBOLS[&"back"], c - Vector2(39, 0), Vector2(25, 27))
	Art.words(self, "Voltar", c + Vector2(8, 6), 17, Art.MINT if _hover == &"back" else Art.PAPER)


func _draw_rocker() -> void:
	var left: Vector2 = centers[&"left"]
	var right: Vector2 = centers[&"right"]
	# A small hinged link ties the run switch to the direction rocker.
	var hinge := (left + right) * 0.5 + Vector2(110, 0)
	draw_polyline(PackedVector2Array([hinge - Vector2(6,0), hinge + Vector2(9,0),
		hinge + Vector2(16,-8), centers[&"run"]]), Art.BRASS.darkened(0.24), 2.0, true)
	draw_texture_rect(Art.ROCKER, Rect2((left + right) * 0.5 - Vector2(107, 43), Vector2(214, 86)), false)
	var dial := (left + right) * 0.5 + Vector2(0, 30)
	draw_arc(dial, 13, PI + 0.29, TAU - 0.29, 18, Art.BRASS, 1.0, true)
	var needle := Vector2.from_angle(lerpf(PI + 0.29, TAU - 0.29, _pace))
	draw_line(dial, dial + needle * 13.5, Art.MINT, 1.7, true)
	draw_circle(dial, 2.3, Art.BRASS, true, -1, true)
	for key: StringName in [&"left", &"right"]:
		var c: Vector2 = centers[key]
		var dir := -1 if key == &"left" else 1
		var color := Art.MINT if _lit(key) else Art.PAPER
		var offset := Vector2(0, -2 if _touch else -7)
		var tip := c + Vector2(9 * dir, 0) + offset
		draw_colored_polygon(PackedVector2Array([tip, tip + Vector2(-20 * dir, -12),
			tip + Vector2(-14 * dir, 0), tip + Vector2(-20 * dir, 12)]), color)
		if not _touch:
			Art.words(self, HOTKEYS[key], c + Vector2(0, 20), 13, color)


func _draw_action_track() -> void:
	var c: Vector2 = centers[&"attack"]
	var start := deg_to_rad(160.0)
	var end := deg_to_rad(235.0)
	draw_arc(c, 86.0, start, end, 35, Color("#5d5849"), 2.0, true)
	for i in range(5):
		var radial := Vector2.from_angle(lerpf(start, end, i / 4.0))
		draw_line(c + radial * 83.0, c + radial * 89.0, Art.BRASS, 1.2, true)
	var fraction := _strike if _strike >= 0.0 else _progress
	if fraction > 0.0:
		var end_active := lerpf(start, end, fraction)
		var ink := Art.BRASS if _link_open else Art.MINT
		draw_arc(c, 86.0, start, end_active, 35, ink, 2.7 if _link_open else 2.0, true)
		var tip := c + Vector2.from_angle(end_active) * 86.0
		draw_circle(tip, 4.2 if _link_open else 2.9, Art.PAPER, true, -1.0, true)


func _draw_action(key: StringName) -> void:
	var c: Vector2 = centers[key]
	var bounds: Vector2 = FRAME[key]
	var lit := _lit(key)
	var accent := Art.MINT if lit else Art.PAPER
	var pressed := _held(key)
	var box := bounds * (0.95 if pressed and not Preferences.values.reduced_motion else 1.0)
	var primary := key == &"attack"
	var skin := Art.DIAL if primary else Art.SHIELD
	Art.fit(self, skin, c, box, Color(0.83, 1.0, 0.96) if lit else Color.WHITE)
	var side := box.y * 0.48
	Art.fit(self, Art.SYMBOLS[key], c - Vector2(0, box.y * 0.12), Vector2(side, side), Color.WHITE)
	var base := c + Vector2(0, box.y * 0.25)
	var caption: String = "Andar" if key == &"run" and _run_mode else CAPTIONS[key]
	Art.words(self, caption, base, 21 if primary else 17, accent)
	if lit or _hover == key:
		var at := c + Vector2(0, box.y * 0.39)
		draw_line(at - Vector2(10, 0), at + Vector2(10, 0), accent, 2.8, true)
	if not _touch:
		Art.words(self, HOTKEYS[key], c + Vector2(0, bounds.y * 0.5 + 16), 13, Art.PAPER)
