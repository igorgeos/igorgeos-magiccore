extends ColorRect

const BACKDROP := preload("res://ui/backdrop.gdshader")


func configure(artwork: Texture2D, opening: bool) -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shader_material := ShaderMaterial.new()
	shader_material.shader = BACKDROP
	shader_material.set_shader_parameter("artwork", artwork)
	shader_material.set_shader_parameter("opening", opening)
	material = shader_material
	resized.connect(_update_aspect)
	_update_aspect()


func _update_aspect() -> void:
	(material as ShaderMaterial).set_shader_parameter("aspect", size.x / maxf(size.y, 1.0))
