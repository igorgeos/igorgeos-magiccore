extends "res://scenes/forest/rig/creature_motion.gd"

const Body := preload("res://scenes/gelo/corpo_soberano.gd")
const PROFILE := 0.59
const VIEW_SIZE := 370.0
const VIEW_CENTER := 131.0
const SHOULDER := Vector2(828, 166)
const ELBOW := Vector2(833, 312)
const GAUNTLET := Vector2(856, 436)
const HIP := Vector2(859, 465)
const ANKLE := Vector2(850, 770)
const MANTLE := Vector2(811, 162)
const TORSO := Vector2(865, 347)
const HEAD := Vector2(866, 124)
const THIGH_LENGTH := 35.0
const SHIN_LENGTH := 50.8
const PLANT_LIMIT := 42.0
const LOAD := [
	[Vector2(-10, 3), -0.04, Vector2(-35, -154), Vector2(17, -125), -2.48],
	[Vector2(-4, -4), -0.025, Vector2(8, -208), Vector2(-7, -177), -1.68],
	[Vector2(-14, 6), -0.05, Vector2(-17, -115), Vector2(17, -131), 0.18],
]
const RELEASE := [
	[Vector2(13, 5), 0.045, Vector2(55, -109), Vector2(-32, -127), 0.44],
	[Vector2(9, 11), 0.055, Vector2(27, -96), Vector2(32, -93), 1.56],
	[Vector2(17, 6), 0.05, Vector2(53, -120), Vector2(-26, -119), 0.11],
]

var _model: Body
var _heading := 1.0
var _target_heading := 1.0
var _turn_time := 1.0
var _yaw := -PROFILE
var _turn_from := -PROFILE
var _grip := Vector2.ZERO
var _shoulder := Vector2.ZERO
var _support_grip := Vector2.ZERO
var _weapon_angle := 0.83
var _torso_pitch := 0.0
var _cloth_pitch := 0.0
var _cloth_force := 0.0
var _cloth_phase := 0.0
var _old_grip := Vector2.ZERO
var _old_angle := 0.83
var _bound: bool
var _plant_x := Vector2.ZERO
var _swing_foot := -1
var _swing_time := 0.0
var _swing_duration := 0.20
var _swing_from := 0.0
var _swing_to := 0.0
var _previous_foot := 1


func setup(body) -> void:
	animal = body
	heading_for(body.side)
	_target_heading = _heading
	_yaw = _yaw_for(_heading)
	_turn_from = _yaw
	phase = 0.38
	stride = 87.0
	pose.resize(24)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(448, 448)
	viewport.transparent_bg = true
	viewport.msaa_3d = Viewport.MSAA_2X
	viewport.own_world_3d = true
	viewport.gui_disable_input = true
	viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	add_child(viewport)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = VIEW_SIZE
	camera.position = Vector3(0, VIEW_CENTER, 325)
	camera.far = 640
	viewport.add_child(camera)
	camera.current = true
	_light_volume(viewport)
	_model = Body.new()
	viewport.add_child(_model)
	_model.construct()
	var screen := Sprite2D.new()
	screen.texture = viewport.get_texture()
	screen.position.y = -VIEW_CENTER
	screen.scale = Vector2.ONE * VIEW_SIZE / viewport.size.x
	screen.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	add_child(screen)
	tick(0.0, 0.0)
	_bound = true


func _light_volume(viewport: SubViewport) -> void:
	var background := WorldEnvironment.new()
	var environment := Environment.new()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#b6c8df")
	environment.ambient_light_energy = 0.68
	background.environment = environment
	viewport.add_child(background)
	_light(viewport, Color("#eef2ff"), 2.20, Vector3(-0.36, -0.70, -0.62))
	_light(viewport, Color("#a0bcf0"), 0.94, Vector3(0.70, -0.11, -0.70))
	_light(viewport, Color("#bbd7ff"), 1.48, Vector3(0.17, -0.66, 0.73))


func _light(viewport: SubViewport, tint: Color, energy: float, direction: Vector3) -> void:
	var light := DirectionalLight3D.new()
	light.light_color = tint
	light.light_energy = energy
	light.shadow_enabled = false
	viewport.add_child(light)
	light.look_at(direction, Vector3.UP)


func heading_for(direction: float) -> void:
	_heading = 1.0 if direction >= 0 else -1.0


func impact(direction: Vector2, force: float) -> void:
	recoil_speed += Vector2(direction.x * _heading * 76.0, -20.0) * minf(force, 1.6)


func tick(dt: float, travel: float) -> void:
	if mode != animal.state:
		mode = animal.state
		transition = 0.0
		_old_grip = _grip
		_old_angle = _weapon_angle
	transition += dt
	clock = fposmod(clock + dt, 600.0)
	var motion := absf(travel) / maxf(0.001, dt)
	var gait := mode in [Mode.PURSUE, Mode.STRIKE, Mode.RECOVER] and motion > 5
	locomotion = move_toward(locomotion, float(gait), dt * 6.0)
	phase = fposmod(phase - travel * _heading / stride, 1.0)
	recoil_speed += (-87.0 * recoil - 16.0 * recoil_speed) * dt
	recoil += recoil_speed * dt
	_turn(dt)
	var t := clampf(float(animal.age) / maxf(animal.age + animal.time, 0.001), 0.0, 1.0)
	var ready := 0.0
	var swing := 0.0
	if mode == Mode.WINDUP:
		ready = smoothstep(0.0, 0.86, t)
	elif mode == Mode.STRIKE:
		if animal.attack == animal.Move.STOMP:
			swing = smoothstep(0.015, float(animal.LANDING), float(animal.age))
		else:
			swing = smoothstep(0.02, 0.78 if animal.attack == animal.Move.RAKE else 0.59, t)
		ready = 1.0 - swing
	elif mode == Mode.RECOVER:
		swing = 1.0 - smoothstep(0.00, 0.92, t)
	var wake := sin(PI * t) if animal.awakening else 0.0
	var stagger := sin(PI * sqrt(t)) if mode == Mode.HURT else 0.0
	var fall := smoothstep(0.0, 0.83, t) if mode == Mode.DEAD else 0.0
	var step := sin(phase * TAU) * locomotion
	var tilt := step * 0.026 - wake * 0.04 - stagger * 0.07
	var sprint_sink := smoothstep(110.0, 310.0, motion) * 9.0
	var offset := Vector2(step * 1.9 - fall * 18.0, absf(step) * 3.1 + sprint_sink + fall * 58.0) + recoil * 0.37
	var weapon := Body.at(GAUNTLET.x, GAUNTLET.y) + Vector2(step * 13, -wake * 51)
	var support := Vector2(-11.0 - step * 21, -103.0 - wake * 26)
	var angle := 0.83 + step * 0.16 - wake * 2.30
	if ready + swing > 0.0:
		var prepared: Array = LOAD[animal.attack]
		var delivered: Array = RELEASE[animal.attack]
		var prep_weight := ready / (ready + swing)
		var prep_offset: Vector2 = prepared[0]
		var hit_offset: Vector2 = delivered[0]
		var prep_grip: Vector2 = prepared[2]
		var strike_grip: Vector2 = delivered[2]
		var prep_support: Vector2 = prepared[3]
		var strike_support: Vector2 = delivered[3]
		offset += prep_offset * ready + hit_offset * swing
		tilt += prepared[1] * ready + delivered[1] * swing
		if animal.rupture:
			prep_grip.x -= 12.0
			prep_support.x += 15.0
		var strength := ready + swing
		weapon = weapon.lerp(strike_grip.lerp(prep_grip, prep_weight), strength)
		support = support.lerp(strike_support.lerp(prep_support, prep_weight), strength)
		angle = lerp_angle(angle, lerpf(prepared[4], delivered[4], 1.0 - prep_weight), strength)
	weapon += Vector2(-32, 82) * fall + recoil * 0.30
	angle = lerp_angle(angle, 0.15, fall)
	_torso_pitch = clampf(tilt, -0.07, 0.07) + fall * 1.19
	_cloth_pitch = lerpf(_cloth_pitch, step * 0.19 + swing * 0.25 + fall * 0.13, 1.0 - exp(-8.0 * dt))
	var cloth_target := (0.48 + 0.25 * locomotion + 0.35 * swing + 0.22 * wake) * (1.0 - fall)
	_cloth_force = lerpf(_cloth_force, cloth_target, 1.0 - exp(-6.0 * dt))
	_cloth_phase = fposmod(_cloth_phase + dt * (3.4 + 2.4 * locomotion + 1.4 * swing), TAU)
	_model.cape_wave(_cloth_phase, _cloth_force)
	if _bound:
		var blend := smoothstep(0.0, 0.085, transition)
		weapon = _old_grip.lerp(weapon, blend)
		angle = lerp_angle(_old_angle, angle, blend)
	_assemble(weapon, support, angle, offset)
	_model.pose("sword", _grip, _weapon_angle - PI * 0.5)
	_legs(offset, fall, dt, travel)
	pose[8] = _model.sword_point()
	pose[12] = _model.project_3d(Vector3(_support_grip.x, -_support_grip.y, -34))
	modulate = Color.WHITE.lerp(Color("#edd6ce"), clampf(animal.receiver.flash * 1.5, 0.0, 0.23))
	if mode == Mode.DEAD:
		modulate.a = 1.0 - smoothstep(0.79, 1.0, t)


func _yaw_for(direction: float) -> float:
	return -PROFILE if direction > 0 else -PI + PROFILE


func _turn(dt: float) -> void:
	var desired: float = animal.side
	if desired != _target_heading:
		_target_heading = desired
		_turn_from = _yaw
		_turn_time = 0.0
	_turn_time = minf(1.0, _turn_time + dt / 0.26)
	var rotation_fraction := smoothstep(0.0, 1.0, _turn_time)
	_yaw = lerpf(_turn_from, _yaw_for(_target_heading), rotation_fraction)
	if _turn_time >= 0.5:
		heading_for(_target_heading)
	_model.rotation.y = _yaw


func _assemble(weapon: Vector2, support: Vector2, angle: float, offset: Vector2) -> void:
	var torso := Body.at(TORSO.x, TORSO.y)
	_model.pose("torso", torso + offset, _torso_pitch)
	_model.pose("head", _lean(Body.at(HEAD.x, HEAD.y), torso, offset), _torso_pitch * 0.58)
	var mantle := _lean(Body.at(MANTLE.x, MANTLE.y) + Vector2(2, -7), torso, offset)
	var mantle_pitch := _torso_pitch * 0.74 + _cloth_pitch
	_model.pose("cape", mantle, mantle_pitch)
	_model.pose("hem", mantle + Vector2(-15, 65).rotated(mantle_pitch), mantle_pitch + _cloth_pitch * 0.38)
	_shoulder = _lean(Body.at(SHOULDER.x, SHOULDER.y), torso, offset)
	var elbow := Body.at(ELBOW.x, ELBOW.y)
	var grip := Body.at(GAUNTLET.x, GAUNTLET.y)
	var shoulder := Body.at(SHOULDER.x, SHOULDER.y)
	_grip = _arm("a", _shoulder, weapon, shoulder.distance_to(elbow), elbow.distance_to(grip), 1.0)
	_weapon_angle = angle
	_support_grip = _arm("b", _lean(shoulder, torso, offset), support, 39.0, 35.0, 1.0)


func _legs(offset: Vector2, fall: float, dt: float, travel: float) -> void:
	var origin_x: float = animal.position.x
	var ankle_rest := Body.at(ANKLE.x, ANKLE.y)
	var rest := [
		Vector3(ankle_rest.x + 7, -ankle_rest.y, 15.5),
		Vector3(ankle_rest.x - 8, -ankle_rest.y, -15.5),
	]
	var home := Vector2(
		origin_x + _model.project_3d(rest[0]).x,
		origin_x + _model.project_3d(rest[1]).x)
	if not _bound:
		_plant_x = home
	var height := _foot_lift(home, dt, travel) * (1.0 - fall)
	var torso := Body.at(TORSO.x, TORSO.y)
	var hip := Body.at(HIP.x, HIP.y)
	for limb in 2:
		var mark := "a" if limb == 0 else "b"
		var depth := 15.5 if limb == 0 else -15.5
		var ankle: Vector3 = rest[limb]
		var planted_offset := clampf(_plant_x[limb] - home[limb], -PLANT_LIMIT, PLANT_LIMIT)
		ankle += _model.basis.inverse() * Vector3(planted_offset, 0, 0)
		ankle.x += (22.0 if limb == 0 else -18.0) * fall
		if animal.is_on_floor():
			var boot_x := origin_x + _model.project_3d(ankle + Vector3(8, 0, 0)).x
			var floor_y: float = animal.floor_at.call(boot_x)
			if is_finite(floor_y):
				ankle.y += clampf(float(animal.position.y) - floor_y, -8.0, 8.0)
		var lift := height if limb == _swing_foot else 0.0
		ankle.y += lift
		var upper := _lean(hip + Vector2(3 if limb == 0 else -4, 0), torso, offset)
		var socket := Vector3(upper.x, -upper.y, depth)
		var knee := _knee(socket, ankle)
		_model.leg_segment("thigh_" + mark, socket, knee, THIGH_LENGTH)
		_model.leg_segment("shin_" + mark, knee, ankle, SHIN_LENGTH)
		_model.boot("boot_" + mark, ankle, lift * 0.011 + fall * (0.30 if limb == 0 else -0.20))


func _foot_lift(home: Vector2, dt: float, travel: float) -> float:
	if _swing_foot >= 0:
		_swing_time = minf(1.0, _swing_time + dt / _swing_duration)
		_plant_x[_swing_foot] = lerpf(_swing_from, _swing_to, smoothstep(0.0, 1.0, _swing_time))
		if _swing_time < 1.0:
			return sin(PI * _swing_time) * 14.0
		_previous_foot = _swing_foot
		_swing_foot = -1
	if mode == Mode.DEAD:
		return 0.0
	var lag := _plant_x - home
	var foot := 0 if absf(lag.x) >= absf(lag.y) else 1
	if absf(absf(lag.x) - absf(lag.y)) < 2.0:
		foot = 1 - _previous_foot
	var speed := absf(travel) / maxf(dt, 0.001)
	var moving := speed > 8.0
	if absf(lag[foot]) > (16.0 if moving else 23.0):
		_swing_foot = foot
		_swing_time = 0.0
		_swing_duration = clampf(0.21 * pow(95.0 / maxf(speed, 95.0), 0.55), 0.10, 0.21)
		_swing_from = _plant_x[foot]
		var lead := minf(31.0, speed * _swing_duration * 1.20) if moving else 0.0
		_swing_to = home[foot] + signf(travel) * lead
	return 0.0


func _knee(hip: Vector3, ankle: Vector3) -> Vector3:
	var axis := hip.direction_to(ankle)
	var distance := maxf(hip.distance_to(ankle), 0.05)
	var stretch := maxf(1.0, distance / (THIGH_LENGTH + SHIN_LENGTH - 0.02))
	var thigh := THIGH_LENGTH * stretch
	var shin := SHIN_LENGTH * stretch
	var along := (thigh * thigh - shin * shin + distance * distance) / (2.0 * distance)
	var forward := (Vector3.RIGHT - axis * axis.x).normalized()
	return hip + axis * along + forward * sqrt(maxf(0.0, thigh * thigh - along * along))


func _lean(point: Vector2, center: Vector2, offset: Vector2) -> Vector2:
	return center + (point - center).rotated(_torso_pitch) + offset


func _arm(mark: String, shoulder: Vector2, goal: Vector2, upper: float, lower: float, bend: float) -> Vector2:
	var reach := shoulder + (goal - shoulder).limit_length(upper + lower - 0.02)
	var joint := _joint(shoulder, reach, upper, lower, bend)
	_model.pose("upper_" + mark, shoulder, (joint - shoulder).angle() - PI * 0.5)
	_model.pose("lower_" + mark, joint, (reach - joint).angle() - PI * 0.5)
	return reach


func _joint(origin: Vector2, end: Vector2, first: float, second: float, bend: float) -> Vector2:
	var axis := origin.direction_to(end)
	var distance := maxf(origin.distance_to(end), 0.05)
	var stretch := maxf(1.0, distance / (first + second - 0.02))
	first *= stretch
	second *= stretch
	var length := (first * first - second * second + distance * distance) / (2.0 * distance)
	return origin + axis * length + axis.orthogonal() * bend * sqrt(maxf(0.0, first * first - length * length))


func attack_point(index: int) -> Vector2:
	if index == 5:
		return to_global(_model.projected(_shoulder, true))
	return to_global(_model.sword_point(index == 8))
