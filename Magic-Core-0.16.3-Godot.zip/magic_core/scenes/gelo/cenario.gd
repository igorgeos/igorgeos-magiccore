extends Node2D

const ASSETS := "res://assets/gelo/"
const MIST := preload("res://assets/forest/cerracao.webp")
const HORIZON_DRIFT := 0.18
const VIEW_HEIGHT := 720.0
const SHELF_LIP := {"ice": 0.13, "stone": 0.15, "bridge": 0.38}

var storm := 0.0
var _art: String
var _width: float
var _water: Array
var _background: Sprite2D
var _far: Node2D
var _props: Node2D
var _front: Node2D
var _weather: Node2D
var _lake: Texture2D
var _texture_cache: Dictionary
var _clock := 0.0
var _paint_in := 0.0
var _horizon := 0.0
var _view_width := 1280.0
var _still := false
var _quality := 2


func setup(route: Dictionary) -> void:
	_art = route.art
	_width = route.width
	_water = route.water
	if not _water.is_empty():
		_lake = texture("lake")
	_background = Sprite2D.new()
	_background.texture = texture(_art)
	_background.z_index = -10
	add_child(_background)
	_far = _layer(-7)
	_weather = _layer(-5)
	_weather.draw.connect(_paint_weather)
	_props = _layer(-2)
	_front = _layer(3)
	for spec in route.far:
		prop(spec[0], Vector2(spec[1], spec[2]), spec[3], _far).modulate = Color("#627483bb")
	for spec in route.props:
		prop(spec[0], Vector2(spec[1], spec[2]), spec[3], _props).modulate = Color("#bec7cb")
	for spec in route.front:
		prop(spec[0], Vector2(spec[1], spec[2]), spec[3], _front).modulate = Color("#56636dcc")
	apply_preferences()


func _layer(depth: int) -> Node2D:
	var layer := Node2D.new()
	layer.z_index = depth
	add_child(layer)
	return layer


func apply_preferences() -> void:
	_background.modulate = Preferences.art_tint(0.9)
	_still = Preferences.values.reduced_motion
	_quality = Preferences.values.visual_quality
	_weather.queue_redraw()


func size_for_view(visible_width: float) -> void:
	_view_width = visible_width
	var span := visible_width + HORIZON_DRIFT * maxf(0.0, _width - visible_width) + 18.0
	var source := _background.texture.get_size()
	_background.scale = Vector2.ONE * maxf(span / source.x, (VIEW_HEIGHT + 12.0) / source.y)
	_weather.queue_redraw()


func align(center: float) -> void:
	_horizon = center
	var scroll := center - _width * 0.5
	_background.position = Vector2(center - scroll * HORIZON_DRIFT, VIEW_HEIGHT * 0.5)
	_far.position.x = scroll * 0.27
	_front.position.x = -scroll * 0.065


func advance(delta: float) -> void:
	_clock += delta
	if _art == "passo":
		var interval := fposmod(_clock, 12.0)
		storm = smoothstep(6.0, 7.8, interval) * (1.0 - smoothstep(9.0, 11.8, interval))
	_paint_in -= delta
	if _paint_in <= 0.0:
		_paint_in = 1.0 / 24.0
		_weather.queue_redraw()


func texture(id: String) -> Texture2D:
	if not _texture_cache.has(id):
		_texture_cache[id] = load(ASSETS + id + ".webp")
	return _texture_cache[id]


func prop(id: String, foot: Vector2, height: float, layer: Node2D = null) -> Sprite2D:
	var sprite := Sprite2D.new()
	sprite.texture = texture(id)
	var size := sprite.texture.get_size()
	sprite.centered = false
	sprite.offset = Vector2(-size.x * 0.5, -size.y)
	sprite.position = foot
	sprite.scale = Vector2.ONE * height / size.y
	var holder := layer if layer != null else self
	holder.add_child(sprite)
	return sprite


func shelf(material: String, surface: Vector2, width: float) -> Sprite2D:
	var slab := Sprite2D.new()
	slab.texture = texture(material)
	var source := slab.texture.get_size()
	var ratio := width / source.x
	slab.centered = false
	slab.offset.y = -source.y * float(SHELF_LIP[material])
	slab.position = surface
	slab.scale = Vector2(ratio, maxf(0.26, ratio))
	slab.modulate = Color("#c1d5df")
	add_child(slab)
	return slab


func gloss(ridge: PackedVector2Array) -> void:
	var glaze := Line2D.new()
	for point in ridge:
		glaze.add_point(point + Vector2(0, 3.0))
	glaze.width = 7.0
	glaze.default_color = Color("#82c4e3d6")
	glaze.antialiased = true
	add_child(glaze)
	var shine := glaze.duplicate() as Line2D
	shine.position.y -= 1.0
	shine.width = 2.0
	shine.default_color = Color("#e0f5fff0")
	add_child(shine)


func overhang(anchor: Vector2) -> void:
	var shape := PackedVector2Array([
		Vector2(anchor.x - 159.0, -23.0), Vector2(anchor.x + 120.0, -23.0),
		anchor + Vector2(86, -212), anchor + Vector2(75, -154), anchor + Vector2(48, -117),
		anchor + Vector2(37, -34), anchor + Vector2(7, 4), anchor + Vector2(-25, 0),
		anchor + Vector2(-61, -36), anchor + Vector2(-81, -121), anchor + Vector2(-127, -153),
	])
	var face := Polygon2D.new()
	face.polygon = shape
	face.color = Color("#697c8dcf")
	_apply_material(face, "rock", Vector2(0.69, 0.43))
	_props.add_child(face)


func ground(ridge: PackedVector2Array) -> void:
	var top := PackedVector2Array()
	for i in range(1, ridge.size()):
		var a := ridge[i - 1]
		var b := ridge[i]
		var segments := ceili((b.x - a.x) / 11.0)
		for part in segments:
			top.append(a.lerp(b, float(part) / segments))
	top.append(ridge[-1])

	var snow := top.duplicate()
	var snow_colors := PackedColorArray()
	var rock_outline := top.duplicate()
	var rock_colors := PackedColorArray()
	var surface := Color("#eef3f5") if _art == "porto" else Color("#d9e4ed")
	for i in top.size():
		snow_colors.append(surface.darkened(0.045 * (1.0 + sin(top[i].x * 0.19))))
		rock_colors.append(Color("#9eacbc"))
	var side := top[-1]
	for cut in [Vector2(-3, 16), Vector2(-12, 52), Vector2(-5, 91), Vector2(-9, 126)]:
		rock_outline.append(side + cut)
		rock_colors.append(Color("#7a8f9f").darkened(cut.y * 0.0028))
	for i in range(top.size() - 1, -1, -1):
		var x := top[i].x
		var drift := 13.8 + sin(x * 0.051) * 2.7 + cos(x * 0.185) * 1.9
		snow.append(top[i] + Vector2(0.0, drift))
		snow_colors.append(Color("#8196aa"))
		rock_outline.append(Vector2(x, 793.0 + sin(x * 0.043) * 16.0))
		rock_colors.append(Color("#222b35"))
	side = top[0]
	for cut in [Vector2(10, 141), Vector2(5, 103), Vector2(13, 50), Vector2(3, 17)]:
		rock_outline.append(side + cut)
		rock_colors.append(Color("#7a8f9f").darkened(cut.y * 0.0028))
	var stone := Polygon2D.new()
	stone.polygon = rock_outline
	stone.vertex_colors = rock_colors
	_apply_material(stone, "rock", Vector2(0.72, 0.63))
	add_child(stone)
	var lip := Polygon2D.new()
	lip.polygon = snow
	lip.vertex_colors = snow_colors
	_apply_material(lip, "frost", Vector2(0.46, 0.76))
	add_child(lip)
	var edge := Line2D.new()
	edge.points = ridge
	edge.width = 1.2
	edge.default_color = Color("#e4e5e5ce")
	edge.antialiased = true
	add_child(edge)


func _apply_material(shape: Polygon2D, material: String, scale_uv: Vector2) -> void:
	shape.texture = texture(material)
	shape.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	var uv := PackedVector2Array()
	for point in shape.polygon:
		uv.append(point * scale_uv)
	shape.uv = uv


func _paint_weather() -> void:
	var motion := 0.0 if _still else _clock
	for water: Rect2 in _water:
		_weather.draw_texture_rect(_lake, water, false, Color("#647d99"))
		_weather.draw_rect(water, Color("#17314960"))
		for index in 13:
			var x := fposmod(index * 81.0 + motion * (3.0 + index % 4), water.size.x - 27.0)
			var y := 3.0 + index * 4.8
			var from := water.position + Vector2(x, y)
			_weather.draw_line(from, from + Vector2(16.0 + (index % 6) * 4.0, 0.0),
				Color(0.62, 0.76, 0.83, 0.55 - index * 0.025), 1.1, true)
		_weather.draw_line(water.position, water.position + Vector2(water.size.x, 0), Color("#b4cad6a9"), 1.7, true)
	var fog_count := 3 if _quality == 0 else 6
	for i in fog_count:
		var span := _width + 400.0
		var x := fposmod(i * 562.0 + motion * (7.0 + storm * 36.0), span) - 200.0
		if absf(x - _horizon) > _view_width * 0.5 + 380.0:
			continue
		var y := 294.0 + (i % 3) * 72.0
		var density := 0.2 + storm * 0.36
		_weather.draw_texture_rect(MIST, Rect2(x - 340.0, y, 680.0, 115.0), false,
			Color(0.67, 0.82, 0.94, density))
	if _quality == 0 or _still:
		return
	var flakes := 30 if _quality == 1 else 56
	for i in flakes:
		var drift := 7.0 + (i % 5) * 3.0 + storm * 79.0
		var x := fposmod(i * 137.0 - motion * drift, _width)
		if absf(x - _horizon) > _view_width * 0.5 + 15.0:
			continue
		var y := fposmod(i * 41.0 + motion * (16.0 + i % 6), 630.0)
		var start := Vector2(x, y)
		_weather.draw_line(start, start + Vector2(-2.0 - storm * 8.0, 2.0),
			Color(0.83, 0.9, 0.98, 0.28 + storm * 0.24), 1.25, true)
