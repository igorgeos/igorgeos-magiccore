extends StaticBody2D

const CRACK_TIME := 0.72
const THAW_TIME := 3.2
const OUTLINE := Color("#e9f6fadb")

enum State { SOLID, CRACKING, BROKEN }

var state := State.SOLID
var slab: Sprite2D
var width: float
var collision: CollisionShape2D
var _clock := 0.0


func advance(delta: float, hero: CharacterBody2D) -> void:
	var near_rim := hero.position.x > position.x and hero.position.x < position.x + width
	match state:
		State.SOLID:
			if near_rim and hero.is_on_floor() and absf(hero.position.y - position.y) < 5.0:
				state = State.CRACKING
				_clock = CRACK_TIME
				queue_redraw()
		State.CRACKING:
			_clock -= delta
			queue_redraw()
			if _clock <= 0.0:
				state = State.BROKEN
				_clock = THAW_TIME
				collision.set_deferred("disabled", true)
				slab.hide()
		State.BROKEN:
			_clock -= delta
			if _clock <= 0.0 and (not near_rim or absf(hero.position.y - position.y) > 16.0):
				state = State.SOLID
				collision.set_deferred("disabled", false)
				slab.show()
				queue_redraw()


func _draw() -> void:
	if state == State.BROKEN or width <= 0.0:
		return
	var cut := (1.0 - maxf(_clock, 0.0) / CRACK_TIME) if state == State.CRACKING else 0.0
	var ink := OUTLINE.lerp(Color("#869da8e5"), 1.0 - cut)
	var middle := width * 0.63
	draw_polyline(PackedVector2Array([
		Vector2(middle - 23, -1), Vector2(middle - 14, 4), Vector2(middle - 19, 8),
		Vector2(middle - 3, 13 + cut * 8), Vector2(middle + 14, 9),
	]), ink, 1.1 + cut * 1.6, true)
	if cut > 0.22:
		draw_line(Vector2(middle - 14, 4), Vector2(middle + 6, -2), ink, 1.6, true)
		draw_line(Vector2(middle - 3, 13 + cut * 8), Vector2(middle + 9, 24), ink, 1.4, true)
