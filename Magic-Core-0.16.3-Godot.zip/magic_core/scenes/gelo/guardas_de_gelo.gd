extends "res://scenes/forest/foe.gd"

const WinterRig := preload("res://scenes/gelo/rig_de_gelo.gd")
const LANDING := 0.23

var heavy := false


func _ready() -> void:
	heavy = kind == 1
	memory_duration = 3.8 if not heavy else 2.7
	super()


func _make_rig() -> Rig:
	return WinterRig.new()


func _body_height() -> float:
	return 203.0 if heavy else 143.0


func _body_width() -> float:
	return 38.0 if heavy else 27.0


func _hurtbox_width() -> float:
	return 77.0 if heavy else 43.0


func _configure_receiver() -> void:
	receiver.max_health = 7 if heavy else 3
	receiver.impact_resistance = 1.1 if heavy else 0.19


func _recovery_time() -> float:
	return [0.94, 1.15, 0.79][attack] if heavy else [0.61, 0.0, 0.86][attack]


func struck(hit: Impact) -> void:
	var braced := heavy and hit.strength < 0.78
	rig.impact(hit.direction, hit.strength)
	vitality.emit(receiver.health)
	if receiver.health == 0:
		velocity = Vector2.ZERO
		change(State.DEAD, 1.12 if heavy else 0.83)
		return
	armor = 0.15 if heavy else 0.11
	memory = memory_duration
	last_seen = hero.position.x
	if braced:
		return
	velocity.x = hit.direction.x * hit.strength * (68.0 if heavy else 145.0)
	change(State.HURT, 0.25 if heavy else lerpf(0.17, 0.38, smoothstep(0.45, 1.14, hit.strength)))


func _choose_action(separation: Vector2) -> void:
	match state:
		State.WINDUP:
			if time <= 0.0:
				var length: float = [0.36, 0.76, 0.36][attack] if heavy else [0.25, 0.0, 0.40][attack]
				change(State.STRIKE, length)
		State.STRIKE:
			if not heavy and attack == Move.CHARGE and age < 0.17:
				step_toward(position.x + side * 72.0, 154.0)
		State.RECOVER:
			if not heavy and age < 0.28 and absf(separation.x) < 149.0:
				var facing := side
				step_toward(position.x - side * 46.0, 93.0)
				side = facing
			if time <= 0.0:
				change(State.PURSUE)
		_:
			super(separation)


func _pursue(separation: Vector2) -> void:
	if hero.position.x < territory.x - 105.0 or hero.position.x > territory.y + 105.0:
		memory = 0.0
		spotted = false
	if not spotted:
		super(separation)
		return
	var distance := absf(separation.x)
	if absf(separation.y) < 103.0:
		if heavy:
			var pattern := [Move.RAKE, Move.CHARGE, Move.STOMP]
			var next: Move = pattern[count % pattern.size()]
			if distance <= [102.0, 111.0, 147.0][next]:
				_prepare(next, separation.x, [0.87, 0.69, 1.06][next])
				return
		elif count % 3 == 1 and distance <= 124.0:
			_prepare(Move.CHARGE, separation.x, 0.58)
			return
		elif distance <= 79.0:
			_prepare(Move.RAKE, separation.x, 0.34)
			return
	step_toward(last_seen, 55.0 if heavy else (142.0 if distance > 125.0 else 96.0))


func _wave_at(direction: float) -> Vector2:
	return wave_origin + Vector2(direction * maxf(0.0, age - LANDING) * 295.0, -14.0)


func apply_attack() -> void:
	if spent:
		return
	if attack == Move.STOMP:
		if age < LANDING:
			return
		if not _sweep_started:
			wave_origin = Vector2(rig.attack_point(8).x, global_position.y)
			_sweep_started = true
		super()
		return
	if age < (0.08 if heavy else 0.035):
		return
	var base: Vector2 = rig.attack_point(7)
	var end: Vector2 = rig.attack_point(8)
	var radius := 17.0 if heavy else 7.0
	if _touches_hero(base, end, radius) or (_sweep_started and _touches_hero(
			_last_grip.lerp(base, 0.5), _last_tip.lerp(end, 0.5), radius)):
		_hit(base, side, 19 if heavy else 11, 207.0 if heavy else 133.0)
	_last_grip = base
	_last_tip = end
	_sweep_started = true


func _draw() -> void:
	if state == State.WINDUP:
		var extent := 113.0 if heavy else (142.0 if attack == Move.CHARGE else 99.0)
		var tint := Color("#ddbc83b8")
		var line_start := -147.0 if attack == Move.STOMP else 0.0
		draw_line(Vector2(line_start, -3), Vector2(147.0 if attack == Move.STOMP else extent * side, -3),
			tint, 2.4, true)
	if state == State.STRIKE and attack == Move.STOMP and age >= LANDING:
		var opacity := 1.0 - smoothstep(0.53, 0.76, age)
		for direction in [-1.0, 1.0]:
			var foot := to_local(_wave_at(direction)) + Vector2(0.0, 12.0)
			for index in 3:
				var x := (index - 1) * 12.0
				draw_polyline(PackedVector2Array([foot + Vector2(x - 7, 0), foot + Vector2(x + 3, -13 - index * 5),
					foot + Vector2(x + 8, 0)]), Color(0.62, 0.84, 0.96, opacity), 2, true)
