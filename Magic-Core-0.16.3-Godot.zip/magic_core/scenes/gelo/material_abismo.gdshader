shader_type spatial;
render_mode unshaded, cull_disabled;

varying vec3 normal_view;
varying vec3 local_pos;

void vertex() {
	normal_view = normalize(MODEL_NORMAL_MATRIX * NORMAL);
	local_pos = VERTEX;
}

void fragment() {
	vec3 n = normalize(normal_view * (FRONT_FACING ? 1.0 : -1.0));
	float key = max(0.0, dot(n, normalize(vec3(-0.35, 0.76, 0.50))));
	float cold = max(0.0, dot(n, normalize(vec3(0.55, 0.06, 0.45))));
	float backlight = max(0.0, dot(n, normalize(vec3(0.25, 0.50, -0.68))));
	float cast = fract(sin(dot(floor(local_pos * 1.25), vec3(13.91, 71.16, 17.11))) * 15731.743);
	bool ice = UV2.x > 0.7;
	bool textile = UV2.x < 0.2;
	float patina = 0.89 + cast * 0.19;
	vec3 diffuse = COLOR.rgb * patina * (0.64 + 0.50 * key + 0.34 * cold)
		+ vec3(0.024, 0.039, 0.070) * backlight;
	float flash = pow(max(0.0, dot(n, normalize(vec3(-0.29, 0.52, 0.81)))), 13.0);
	ALBEDO = ice ? mix(diffuse, COLOR.rgb, 0.83) :
		diffuse + vec3(0.27, 0.36, 0.52) * flash * (textile ? 0.04 : 0.29);
}
