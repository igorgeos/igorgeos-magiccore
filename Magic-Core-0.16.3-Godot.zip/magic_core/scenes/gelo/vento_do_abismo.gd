extends Node2D

enum Phase { WARNING, GUST, REST }

var phase := Phase.REST
var gust := 0.0
var reduced_motion := false
var region: Rect2
var strength: float
var warning_time: float
var active_time: float
var rest_time: float
var clock: float
var _redraw_in := 0.0
var _label: Label


func setup(spec: Array) -> void:
	region = spec[0]
	strength = spec[1]
	warning_time = spec[2]
	active_time = spec[3]
	rest_time = spec[4]
	clock = spec[5]
	z_index = 1
	_label = Label.new()
	_label.position = region.position + Vector2(0, -25)
	_label.size.x = region.size.x
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 16)
	_label.add_theme_color_override("font_outline_color", Color("#14222d"))
	_label.add_theme_constant_override("outline_size", 5)
	add_child(_label)
	advance(0.0)


func advance(delta: float) -> void:
	clock = fposmod(clock + delta, warning_time + active_time + rest_time)
	if clock < warning_time:
		phase = Phase.WARNING
		gust = 0.0
	elif clock < warning_time + active_time:
		phase = Phase.GUST
		var elapsed := clock - warning_time
		gust = strength * smoothstep(0.0, 0.35, elapsed) * (1.0 - smoothstep(active_time - 0.42, active_time, elapsed))
	else:
		phase = Phase.REST
		gust = 0.0
	_redraw_in -= delta
	if _redraw_in <= 0.0:
		_redraw_in = 1.0 / 20.0
		var direction := "←" if strength < 0.0 else "→"
		_label.text = ["%s  Rajada em %.1f s" % [direction, warning_time - clock],
			"%s  Rajada" % direction, "Calmaria"][phase]
		queue_redraw()


func wind_at(point: Vector2) -> float:
	if not region.has_point(point):
		return 0.0
	var border := minf(point.x - region.position.x, region.end.x - point.x)
	return gust * smoothstep(0.0, 24.0, border)


func _draw() -> void:
	if _label == null:
		return
	var direction := signf(strength)
	var tint := Color("#e9cf9c") if phase == Phase.WARNING else Color("#c2e8ff")
	var opacity := [0.59, 0.75, 0.22][phase] as float
	for streak in 12:
		var length := 31.0 + float(streak % 4) * 7.0
		var drift := 0.0 if reduced_motion else clock * (29.0 + 2.0 * absf(gust)) * direction
		var x := region.position.x + 36.0 + fposmod(streak * 101.0 + drift, region.size.x - 71.0)
		var y := region.position.y + 15.0 + fposmod(streak * 43.0, region.size.y - 30.0)
		var tip := Vector2(x, y)
		var tail := tip - Vector2(length * direction, 2.0)
		draw_line(tail, tip, Color(tint, opacity), 1.55, true)
		if streak % 3 == 0:
			draw_polyline(PackedVector2Array([tip + Vector2(-7 * direction, -3), tip,
				tip + Vector2(-7 * direction, 4)]), Color(tint, opacity), 1.4, true)
