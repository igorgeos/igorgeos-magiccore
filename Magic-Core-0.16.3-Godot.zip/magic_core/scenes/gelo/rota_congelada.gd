extends "res://scenes/world/test_world.gd"

const Ink := preload("res://ui/ink_style.gd")
const HudArt := preload("res://ui/hud_art.gd")
const TouchButton := preload("res://ui/touch_button.gd")
const Vigor := preload("res://scenes/forest/vigor.gd")
const Objectives := preload("res://scenes/forest/objectives.gd")
const Foe := preload("res://scenes/forest/foe.gd")
const Castellan := preload("res://scenes/gelo/castelao.gd")
const Guards := preload("res://scenes/gelo/guardas_de_gelo.gd")
const Routes := preload("res://scenes/gelo/percursos.gd")
const Scenery := preload("res://scenes/gelo/cenario.gd")
const FragileIce := preload("res://scenes/gelo/gelo_fragil.gd")
const Icicle := preload("res://scenes/gelo/estalactite.gd")
const Wind := preload("res://scenes/gelo/vento_do_abismo.gd")
const Event := Objectives.Event
const FALL_LIMIT := 704.0
const GATE_HEIGHT := 244.0

@export var stage_id: String

var destination: Dictionary
var route: Dictionary
var life: Vigor
var progress: Objectives
var scenery: Scenery
var camera: Camera2D
var sites: Dictionary
var foes: Array[Foe] = []
var brittle_ice: Array[FragileIce] = []
var icicles: Array[Icicle] = []
var stable_shelves: Array[Rect2] = []
var ground_profiles: Array[PackedVector2Array] = []
var last_safe: Vector2
var ended := false
var won := false
var interact: Button

var _gate: AnimatableBody2D
var _gate_art: Sprite2D
var _sanctum_gate: AnimatableBody2D
var _sanctum_art: Sprite2D
var _bridge: Sprite2D
var _wind_lanes: Array[Wind] = []
var _slippery_patches: Array = []
var _ice_decks: Array[Rect2] = []
var _boss: Castellan
var _boss_panel: Control
var _boss_bar: ProgressBar
var _boss_title: Label
var _health: ProgressBar
var _health_text: Label
var _objective: Label
var _mission: Panel
var _stage_title: Label
var _retry_from_arena := false
var _notice_time := 0.0
var _nearest := ""
var _health_tween: Tween
var _hurt_tween: Tween
var _air: AudioStreamPlayer

@onready var _hull: CollisionShape2D = $Personagem/Colisao


func _ready() -> void:
	if Campaign.chapter != "gelo" or Campaign.stage != stage_id or not Campaign.enter_stage(stage_id):
		set_process(false)
		set_physics_process(false)
		get_tree().call_deferred("change_scene_to_file", Campaign.ATLAS)
		return
	destination = Campaign.stage_data(stage_id)
	route = Routes.STAGES[stage_id]
	progress = Objectives.new(route.tasks)
	life = Vigor.new(100)
	life.changed.connect(_refresh_health)
	_right_wall.position.x = route.width + 12.0
	last_safe = $Nascimento.position
	_move_hero(last_safe)
	_build_ui()
	_build_landscape()
	if _retry_from_arena:
		_restore_arena_checkpoint()
	_build_mission()
	_layout_view()
	get_viewport().size_changed.connect(_layout_view)
	_start_wind()
	Preferences.changed.connect(_apply_preferences)
	_apply_preferences()


func _draw() -> void:
	pass


func _exit_tree() -> void:
	if is_instance_valid(_air):
		_air.stop()
	super()


func _build_landscape() -> void:
	camera = Camera2D.new()
	camera.position.y = 360.0
	camera.process_callback = Camera2D.CAMERA2D_PROCESS_PHYSICS
	camera.limit_left = 0
	camera.limit_right = int(route.width)
	add_child(camera)
	scenery = Scenery.new()
	add_child(scenery)
	scenery.setup(route)
	for ridge in route.ground:
		_add_ground(ridge)
	_slippery_patches = route.get("slippery", [])
	for band: Vector2 in _slippery_patches:
		var glaze := PackedVector2Array()
		for i in 17:
			var x := lerpf(band.x, band.y, i / 16.0)
			glaze.append(Vector2(x, surface_at(x)))
		scenery.gloss(glaze)
	for platform in route.platforms:
		_add_shelf(platform)
	if route.has("folding_bridge"):
		var deck: Array = route.folding_bridge
		_bridge = scenery.shelf(deck[3], Vector2(deck[0], deck[1]), deck[2])
		_bridge.rotation = -1.16
	for spec in route.get("wind", []):
		var lane := Wind.new()
		add_child(lane)
		lane.setup(spec)
		_wind_lanes.append(lane)
	for spec in route.sites:
		_add_site(spec[0], Vector2(spec[1], spec[2]), spec[3], spec[4], spec[5])
	for spec in route.icicles:
		var tooth := Icicle.new()
		add_child(tooth)
		var anchor := Vector2(spec[0], spec[1])
		tooth.setup(anchor, spec[2], scenery.texture("icicle"))
		scenery.overhang(anchor)
		icicles.append(tooth)
	if route.has("spikes"):
		var danger: Rect2 = route.spikes
		scenery.prop("spikes", Vector2(danger.get_center().x, danger.end.y), danger.size.y)
	if route.has("gate") and not _retry_from_arena:
		var pair := _add_gate(route.gate)
		_gate = pair[0]
		_gate_art = pair[1]
	if route.has("sanctum_gate"):
		var pair := _add_gate(route.sanctum_gate)
		_sanctum_gate = pair[0]
		_sanctum_art = pair[1]
	for spec in route.foes:
		_spawn_foe(spec)


func _add_ground(spec: Array) -> void:
	var ridge := PackedVector2Array()
	for point in spec:
		ridge.append(Vector2(point[0], point[1]))
	ground_profiles.append(ridge)
	var body := StaticBody2D.new()
	var collision := CollisionPolygon2D.new()
	var outline := ridge.duplicate()
	outline.append(Vector2(ridge[-1].x, 815))
	outline.append(Vector2(ridge[0].x, 815))
	collision.polygon = outline
	body.add_child(collision)
	add_child(body)
	scenery.ground(ridge)


func surface_at(x: float) -> float:
	for ridge in ground_profiles:
		if x < ridge[0].x or x > ridge[-1].x:
			continue
		for i in range(1, ridge.size()):
			var right := ridge[i]
			if x <= right.x:
				var left := ridge[i - 1]
				return lerpf(left.y, right.y, inverse_lerp(left.x, right.x, x))
	return INF


func _box(size: Vector2) -> CollisionShape2D:
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	collision.shape = shape
	return collision


func _add_shelf(spec: Array) -> void:
	var surface := Vector2(spec[0], spec[1])
	var width: float = spec[2]
	var material: String = spec[3]
	var fragile := material == "brittle"
	var slab := scenery.shelf("ice" if fragile else material, surface, width)
	_place_deck(surface, width, material, slab)


func _place_deck(surface: Vector2, width: float, material: String, slab: Sprite2D) -> void:
	var fragile := material == "brittle"
	var body: StaticBody2D = FragileIce.new() if fragile else StaticBody2D.new()
	body.position = surface
	var collision := _box(Vector2(width, 14.0))
	collision.position = Vector2(width * 0.5, 7.0)
	collision.one_way_collision = true
	collision.one_way_collision_margin = 9.0
	body.add_child(collision)
	if fragile:
		var ice := body as FragileIce
		ice.slab = slab
		ice.width = width
		ice.collision = collision
		brittle_ice.append(ice)
	else:
		stable_shelves.append(Rect2(surface, Vector2(width, 14)))
	if stage_id == "gelo1" and material in ["ice", "brittle"]:
		_ice_decks.append(Rect2(surface, Vector2(width, 14)))
	add_child(body)


func _add_gate(foot: Vector2) -> Array:
	var art := scenery.prop("portcullis", foot, GATE_HEIGHT)
	art.region_enabled = true
	art.region_filter_clip_enabled = true
	art.region_rect = Rect2(Vector2.ZERO, art.texture.get_size())
	var gate := AnimatableBody2D.new()
	gate.position = foot - Vector2(0, GATE_HEIGHT * 0.5)
	gate.add_child(_box(Vector2(53, GATE_HEIGHT)))
	add_child(gate)
	return [gate, art]


func _raise_gate(gate: AnimatableBody2D, art: Sprite2D) -> void:
	if not is_instance_valid(gate):
		return
	var move := create_tween().set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	move.tween_method(_slide_gate.bind(gate, art), 0.0, 1.0, 0.84).set_trans(Tween.TRANS_SINE)
	move.tween_callback(gate.queue_free)
	move.tween_callback(art.queue_free)


func _slide_gate(fraction: float, gate: AnimatableBody2D, art: Sprite2D) -> void:
	var size := art.texture.get_size()
	var clip := size.y * fraction
	gate.position.y = art.position.y - GATE_HEIGHT * (0.5 + fraction)
	art.region_rect = Rect2(0.0, clip, size.x, maxf(size.y - clip, 0.1))


func _lower_bridge() -> void:
	var deck: Array = route.folding_bridge
	var move := create_tween().set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	move.tween_property(_bridge, "rotation", 0.0, 0.78).set_trans(Tween.TRANS_SINE)
	move.tween_callback(_place_deck.bind(_bridge.position, float(deck[2]), "bridge", _bridge))


func _spawn_foe(spec: Array) -> void:
	var foe: Foe = Castellan.new() if spec[2] == 2 else Guards.new()
	foe.name = spec[0]
	foe.kind = spec[2]
	foe.hero = _player
	foe.position = Vector2(spec[1], surface_at(spec[1]) - 0.1)
	foe.territory = Vector2(spec[3], spec[4])
	foe.z_index = 1
	foe.fallen.connect(_foe_fell)
	foe.contact.connect(_hurt)
	if foe is Castellan:
		foe.floor_at = surface_at
		foe.fault_lines = PackedFloat32Array(route.fault_lines)
	add_child(foe)
	foes.append(foe)
	if foe.kind == 2:
		_boss = foe as Castellan
		foe.vitality.connect(_refresh_boss)


func _add_site(key: String, foot: Vector2, caption: String, art: String, height: float) -> void:
	var prop := scenery.prop(art, foot, height)
	prop.modulate = Color("#adc1d3")
	if key == "braseiro":
		prop.modulate = Color("#697b8a")
	sites[key] = {"point": foot, "caption": caption, "visual": prop, "used": false}


func _pick_interaction() -> void:
	_nearest = ""
	var best := INF
	for key in sites:
		var item: Dictionary = sites[key]
		if item.used:
			continue
		var distance: Vector2 = (_player.position - item.point).abs()
		if distance.x <= 72.0 and distance.y <= 52.0 and distance.length_squared() < best:
			_nearest = key
			best = distance.length_squared()
	interact.visible = not _nearest.is_empty()
	if interact.visible:
		interact.text = sites[_nearest].caption


func activate() -> void:
	if ended or _wheel.visible:
		return
	_pick_interaction()
	if _nearest.is_empty():
		return
	var item: Dictionary = sites[_nearest]
	match _nearest:
		"rest":
			if not life.heal(33):
				_say("Sua vida já está completa.")
				return
			_say("Você se aqueceu. Este braseiro foi usado.")
		"abrigo":
			life.heal(25)
			_say("Abrigo descoberto. Um antigo batedor deixou provisões e marcas do vento.", 4.0)
		_:
			if progress.complete():
				_register_victory()
				return
			if not progress.record(Event.INTERACT, _nearest):
				_say(progress.description())
				return
			match _nearest:
				"lanterna", "farol":
					_light(item.visual, _nearest)
				"braseiro":
					_light(item.visual, _nearest)
					_raise_gate(_gate, _gate_art)
				"guincho":
					_raise_gate(_gate, _gate_art)
					_lower_bridge()
				"sino":
					_register_victory()
					return
			_notice_time = 0.0
			_objective.text = progress.description()
	item.used = true
	if _nearest in ["rest", "guincho"]:
		item.visual.modulate = Color("#849ba5")
	Preferences.navigation_feedback()
	_pick_interaction()


func _restore_arena_checkpoint() -> void:
	var hearth: Dictionary = sites.braseiro
	hearth.used = true
	progress.record(Event.INTERACT, "braseiro")
	_light(hearth.visual, "braseiro")
	var x: float = route.arena_retry_x
	last_safe = Vector2(x, surface_at(x))
	_move_hero(last_safe)


func _arena_retry_available() -> bool:
	return route.has("arena_retry_x") and sites.braseiro.used and is_instance_valid(_boss) \
		and (_retry_from_arena or _boss.encounter != Castellan.Encounter.VIGILANCIA)


func _retry(arena: bool) -> void:
	if _leaving:
		return
	_leaving = true
	if arena:
		var scene := load(scene_file_path) as PackedScene
		var rematch = scene.instantiate()
		rematch._retry_from_arena = true
		if get_tree().change_scene_to_node(rematch) == OK:
			return
		rematch.free()
	elif get_tree().reload_current_scene() == OK:
		return
	_leaving = false


func _light(source: Sprite2D, key: String) -> void:
	source.modulate = Color("#e1c696")
	var point := source.position - Vector2(0.0, 35.0 if key == "braseiro" else 111.0)
	var ember := PointLight2D.new()
	var radial := GradientTexture2D.new()
	var fade := Gradient.new()
	fade.set_color(0, Color("#ffe1a0b9"))
	fade.set_color(1, Color("#f4bd6100"))
	radial.gradient = fade
	radial.fill = GradientTexture2D.FILL_RADIAL
	radial.fill_from = Vector2(0.5, 0.5)
	radial.fill_to = Vector2(1.0, 0.5)
	radial.width = 128
	radial.height = 128
	ember.texture = radial
	ember.color = Color("#f9c788")
	ember.energy = 0.24
	ember.range_z_min = -2
	ember.range_z_max = 2
	ember.position = point
	add_child(ember)


func _foe_fell(foe: Foe) -> void:
	foes.erase(foe)
	if ended:
		return
	if progress.record(Event.DEFEAT, String(foe.name)):
		_objective.text = progress.description()
	if foe == _boss:
		_boss_panel.hide()
		_boss = null
		_raise_gate(_sanctum_gate, _sanctum_art)
		_register_victory()


func _register_victory() -> void:
	if ended or not progress.complete():
		return
	if Campaign.finish_stage() != OK:
		if stage_id == "gelo3":
			_finish(true, true)
		else:
			_say("Falha ao salvar. Interaja novamente.", 7.0)
		return
	if stage_id == "gelo3":
		var seal := sites.sino.visual as Sprite2D
		seal.modulate = Color("#eeebc9")
	Preferences.feedback(true)
	_finish(true)


func _hurt(damage: int, push: float, fall := false) -> void:
	if ended or not life.damage(damage, fall):
		return
	_player.react_to_damage(push, clampf(float(damage) / 30.0, 0.2, 1.0))
	var body := _player.get_node("Visual") as Node2D
	if _hurt_tween and _hurt_tween.is_valid():
		_hurt_tween.kill()
	body.modulate = Color("#edb9b8")
	_hurt_tween = create_tween()
	_hurt_tween.tween_property(body, "modulate", Color.WHITE, 0.24)
	if life.current == 0:
		_finish(false)


func _finish(success: bool, save_failed := false) -> void:
	ended = true
	won = success and not save_failed
	_player.controls_locked = true
	_player.set_physics_process(false)
	_player.touch_axis = 0.0
	_controls.hide()
	_wheel.hide()
	interact.hide()
	for foe in foes:
		foe.suspend(true)
	if not success and not Preferences.values.reduced_motion:
		var body := _player.get_node("Visual") as Node2D
		var fall := create_tween().set_parallel()
		fall.tween_property(body, "rotation", -1.32, 0.48).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		fall.tween_property(body, "position:x", -12.0, 0.44)
		await fall.finished
	if is_inside_tree():
		_show_result(success, save_failed)


func _show_result(success: bool, save_failed: bool) -> void:
	var veil := ColorRect.new()
	veil.color = Color("#101922e8")
	_hud.add_child(veil)
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	veil.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 17)
	center.add_child(column)
	var heading := "O Andarilho tombou"
	var arena_retry := not success and _arena_retry_available()
	var detail := "Volte à entrada da arena com a vida restaurada." if arena_retry \
		else "Recomece a fase com a vida restaurada."
	if success:
		heading = "Senhor do Abismo Gélido derrotado" if stage_id == "gelo3" else "Travessia concluída"
		detail = "O selo ancestral abriu o Reino Vulcânico." if stage_id == "gelo3" else String(destination.name)
	if save_failed:
		detail = "Não foi possível salvar o avanço. Tente novamente."
	var title := Ink.label(heading, 36, Ink.TEXT)
	title.add_theme_font_override("font", Ink.SERIF)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(title)
	var caption := Ink.label(detail, 21, Color("#c6d6e0"))
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(caption)
	if not success:
		var caption_text := "Tentar chefe de novo" if arena_retry else "Reiniciar fase"
		var retry := Ink.button(caption_text, true, TouchButton.new())
		column.add_child(retry)
		retry.pressed.connect(_retry.bind(arena_retry))
	if save_failed:
		var save_again := Ink.button("Salvar novamente", true, TouchButton.new())
		column.add_child(save_again)
		save_again.pressed.connect(func():
			save_again.disabled = true
			veil.queue_free()
			ended = false
			_register_victory()
		)
		return
	var back := Ink.button("Voltar ao mapa", success, TouchButton.new())
	column.add_child(back)
	back.pressed.connect(_go_back)
	if not Preferences.values.reduced_motion:
		veil.modulate.a = 0.0
		create_tween().tween_property(veil, "modulate:a", 1.0, 0.22)


func _say(detail: String, seconds := 2.6) -> void:
	_objective.text = detail
	_notice_time = seconds


func _bar(fill: Color) -> ProgressBar:
	var result := ProgressBar.new()
	result.show_percentage = false
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var frame := Ink.panel(Color("#202932"), Color("#8595a1"), 4)
	result.add_theme_stylebox_override("background", frame)
	result.add_theme_stylebox_override("fill", Ink.panel(fill, fill.lightened(0.2), 3))
	return result


func _build_mission() -> void:
	_health = _bar(Color("#934b55"))
	_health.max_value = life.capacity
	_health.value = life.current
	_hud.add_child(_health)
	_health_text = Ink.label("Vida   %d / %d" % [life.current, life.capacity], 17, Ink.TEXT)
	_health_text.add_theme_constant_override("shadow_offset_y", 2)
	_health_text.add_theme_color_override("font_shadow_color", Color("#141d25"))
	_hud.add_child(_health_text)
	_mission = Panel.new()
	_mission.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mission.clip_contents = true
	_mission.add_theme_stylebox_override("panel", Ink.panel(Color("#14202bee"), Color("#8ca5b4"), 5))
	_hud.add_child(_mission)
	_stage_title = Ink.label(destination.name, 17, Color("#c2d8e4"))
	_stage_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_mission.add_child(_stage_title)
	_objective = Ink.label(progress.description(), 20, Ink.TEXT)
	_objective.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_objective.max_lines_visible = 2
	_objective.clip_text = true
	_objective.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_objective.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_mission.add_child(_objective)
	interact = Ink.button("Interagir", true, TouchButton.new())
	interact.name = "Interagir"
	interact.focus_mode = Control.FOCUS_NONE
	_hud.add_child(interact)
	interact.pressed.connect(activate)
	interact.hide()
	if not is_instance_valid(_boss):
		return
	_boss_panel = Control.new()
	_boss_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(_boss_panel)
	_boss_title = Ink.label("Senhor do Abismo Gélido", 18, Ink.TEXT)
	_boss_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boss_panel.add_child(_boss_title)
	_boss_bar = _bar(Color("#726d91"))
	_boss_bar.max_value = _boss.receiver.max_health
	_boss_bar.value = _boss.receiver.health
	_boss_panel.add_child(_boss_bar)
	_boss_panel.hide()


func _layout_view() -> void:
	_extent = get_viewport_rect().size
	camera.zoom = Vector2.ONE * _extent.y / Scenery.VIEW_HEIGHT
	scenery.size_for_view(_extent.x / camera.zoom.x)
	_align_camera()
	_layout_hud.call_deferred()


func _layout_hud() -> void:
	var safe := HudArt.safe_rect(_controls)
	var unit: float = _controls._unit
	var home := safe.position + Vector2(25, 105) * unit
	_health_text.position = home
	_health_text.add_theme_font_size_override("font_size", Preferences.text_size(17))
	_health.position = home + Vector2(0, 26)
	_health.size = Vector2(177.0 * minf(unit, 1.4), 13)
	var left := safe.position.x + 362.0 * unit + 14.0
	var right := safe.end.x - 157.0 * unit - 14.0
	var width := clampf(right - left, 160.0, 550.0)
	var height := maxf(74.0, 27.0 + 2.6 * Preferences.text_size(19))
	var x := clampf(safe.get_center().x - width * 0.5, left, maxf(left, right - width))
	_mission.position = Vector2(x, safe.position.y + 14.0)
	_mission.size = Vector2(width, height)
	_stage_title.position = Vector2(8, 3)
	_stage_title.size = Vector2(width - 16, 24)
	_objective.position = Vector2(9, 26)
	_objective.add_theme_font_size_override("font_size", Preferences.text_size(19))
	var text_area := Vector2(width - 18.0, height - 28.0)
	_objective.size = text_area
	_objective.set_deferred("size", text_area)
	interact.size = Vector2(minf(safe.size.x * 0.33, 364.0), 62.0)
	interact.position = Vector2(safe.get_center().x - interact.size.x * 0.5, safe.end.y - 122.0)
	if is_instance_valid(_boss_panel):
		_boss_panel.position = _mission.position + Vector2(0, height + 5.0)
		_boss_title.size.x = width
		_boss_bar.position = Vector2(width * 0.14, 24.0)
		_boss_bar.size = Vector2(width * 0.72, 11.0)


func _refresh_health(current: int, capacity: int) -> void:
	_health_text.text = "Vida   %d / %d" % [current, capacity]
	if _health_tween and _health_tween.is_valid():
		_health_tween.kill()
	_health_tween = create_tween()
	_health_tween.tween_property(_health, "value", float(current), 0.2)


func _refresh_boss(current: int) -> void:
	_boss_bar.value = current
	if current == 0:
		for tooth in icicles:
			tooth.queue_free()
		icicles.clear()
		_player.controls_locked = true


func _align_camera() -> void:
	var half := minf(route.width * 0.5, _extent.x / camera.zoom.x * 0.5)
	camera.position.x = clampf(_player.position.x, half, route.width - half)
	scenery.align(camera.position.x)


func _move_hero(point: Vector2) -> void:
	_player.position = point
	_player.velocity = Vector2.ZERO
	_player.slippery_ground = false
	_player.wind_velocity = 0.0
	_player.reset_physics_interpolation()
	_player.reset_attack_sweep()


func _remember_safe_ground() -> void:
	if not _player.is_on_floor():
		return
	var feet := _player.position
	var ground := surface_at(feet.x)
	if absf(ground - feet.y) < 5.0 and is_finite(surface_at(feet.x - 38.0)) and is_finite(surface_at(feet.x + 38.0)):
		last_safe = feet
		return
	for deck in stable_shelves:
		if absf(deck.position.y - feet.y) < 4.0 and feet.x > deck.position.x + 12.0 and feet.x < deck.end.x - 12.0:
			last_safe = feet
			return


func _fell_in_hazard() -> bool:
	var feet := _player.position
	if route.has("spikes") and route.spikes.has_point(feet):
		return true
	for water: Rect2 in route.water:
		if water.has_point(feet - Vector2(0, 8)):
			return true
	return feet.y > FALL_LIMIT


func _update_terrain(delta: float) -> void:
	var feet := _player.position
	var on_ice := false
	if _player.is_on_floor():
		for band: Vector2 in _slippery_patches:
			if feet.x >= band.x and feet.x <= band.y and absf(surface_at(feet.x) - feet.y) < 5.0:
				on_ice = true
				break
		for deck in _ice_decks:
			if feet.x >= deck.position.x and feet.x <= deck.end.x and absf(deck.position.y - feet.y) < 4.0:
				on_ice = true
				break
	_player.slippery_ground = on_ice
	var drift := 0.0
	for lane in _wind_lanes:
		lane.advance(delta)
		drift += lane.wind_at(feet - Vector2(0, 35))
	_player.wind_velocity = drift


func _physics_process(delta: float) -> void:
	if ended or _leaving or not is_instance_valid(interact):
		return
	super(delta)
	if _wheel.visible:
		interact.hide()
		return
	life.advance(delta)
	if _notice_time > 0.0:
		_notice_time -= delta
		if _notice_time <= 0.0:
			_objective.text = progress.description()
	if _fell_in_hazard():
		_move_hero(last_safe - Vector2(0, 6))
		_hurt(21, 0.0, true)
		if ended:
			return
		_say("Você voltou ao último apoio seguro.", 2.2)
	_remember_safe_ground()
	_update_terrain(delta)
	for ice in brittle_ice:
		ice.advance(delta, _player)
	for tooth in icicles:
		if tooth.advance(delta, _player, _hull):
			_hurt(17, signf(_player.position.x - tooth.position.x) * 118.0)
			if ended:
				return
	if is_instance_valid(_boss):
		_boss_panel.visible = absf(_boss.position.x - _player.position.x) < 620.0
		if _boss.state == Foe.State.WINDUP:
			_boss_title.text = "Ruptura do Gelo" if _boss.rupture else [
				"Corte do Inverno", "Onda Glacial", "Investida Congelante"][_boss.attack]
		elif _boss.angry and _boss.state != Foe.State.DEAD:
			_boss_title.text = "Senhor do Abismo Gélido · Inverno Despertado"
		else:
			_boss_title.text = "Senhor do Abismo Gélido"
	_align_camera()
	_pick_interaction()
	scenery.advance(delta)


func _start_wind() -> void:
	var source := load("res://audio/vento_da_mata.wav") as AudioStreamWAV
	if source == null:
		return
	var stream := source.duplicate() as AudioStreamWAV
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_end = roundi(stream.get_length() * stream.mix_rate)
	_air = AudioStreamPlayer.new()
	_air.stream = stream
	_air.pitch_scale = 0.82 if stage_id == "gelo3" else 0.93
	add_child(_air)
	_air.play()


func _apply_preferences() -> void:
	if is_instance_valid(_air):
		_air.volume_linear = Preferences.values.effects * 0.0036
	for tooth in icicles:
		tooth.reduced_motion = Preferences.values.reduced_motion
	for lane in _wind_lanes:
		lane.reduced_motion = Preferences.values.reduced_motion
	scenery.apply_preferences()
	_layout_hud()


func _open_arsenal() -> void:
	super()
	interact.hide()
	for foe in foes:
		foe.suspend(true)
	_player.set_physics_process(false)


func _close_arsenal() -> void:
	super()
	_player.set_physics_process(true)
	for foe in foes:
		foe.suspend(false)


func _go_back() -> void:
	if _leaving:
		return
	_leaving = true
	Campaign.return_to_map = true
	Preferences.feedback()
	if get_tree().change_scene_to_file(Campaign.ATLAS) != OK:
		_leaving = false


func _unhandled_input(event: InputEvent) -> void:
	if ended:
		if event.is_action_pressed("menu_back", false) and (won or life.current == 0):
			_go_back()
		return
	if not is_instance_valid(interact):
		return
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_E:
		activate()
		get_viewport().set_input_as_handled()
	else:
		super(event)
