extends Control

const Ink := preload("res://ui/ink_style.gd")
const MENU := "res://scenes/menu/main_menu.tscn"
const FIELD := "res://scenes/world/test_world.tscn"
const GOLD := Color("#e6cd94")
const CREAM := Color("#f4ead5")
const MUTED := Color("#adb6a9")
const DARK := Color("#172421")
const SEA := Color("#121d1c")
const Chart := preload("res://scenes/atlas/sea_chart.gd")
var ocean: Chart
var opening := false
const SHEET := Rect2(44, 128, 550, 550)
var paper: Control
var map_open := false
var selected := 0
var site := 0
var status := ""
var atlas_texture: Texture2D

func _ready() -> void:
	paper = Control.new()
	add_child(paper)
	paper.size = Vector2(1280,720)
	paper.draw.connect(_paint)
	resized.connect(_layout)
	_layout()
	for i in Campaign.regions.size():
		if Campaign.regions[i].id == Campaign.chapter:
			selected = i
	map_open = Campaign.return_to_map
	Campaign.return_to_map = false
	ocean = Chart.new()
	ocean.name = "Oceano"
	paper.add_child(ocean)
	ocean.selected = selected
	if map_open and Campaign.chart_slot == Campaign.active_slot and Campaign.chart_region == Campaign.chapter:
		ocean.zoom = Campaign.chart_zoom
		ocean.offset = Campaign.chart_offset
	ocean.island_selected.connect(_select_island)
	_choose_current()
	_refresh()

func _layout() -> void:
	var unit := minf(size.x / 1280.0, size.y / 720.0)
	paper.scale = Vector2.ONE * unit
	paper.position = (size - paper.size * unit) * 0.5

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO,size), SEA)

func _choose_current() -> void:
	site = 0
	for i in Campaign.regions[selected].stages.size():
		var item: Dictionary = Campaign.regions[selected].stages[i]
		if Campaign.unlocked(item) and item.id not in Campaign.completed:
			site = i
			break

func _select_island(i: int) -> void:
	if opening: return
	selected = i
	var part: Dictionary = Campaign.regions[i]
	Preferences.navigation_feedback()
	status = "" if Campaign.unlocked(part) else "Selo exigido: "+str(Campaign.stage_data(part.requires[0]).name)
	ocean.focus_at(1.18,ocean.labels[i]-Vector2(0,60))
	_refresh(false)

func _open(i: int) -> void:
	if opening: return
	var part: Dictionary = Campaign.regions[i]
	if not Campaign.unlocked(part):
		selected = i
		status = "Conclua %s para abrir esta carta." % Campaign.stage_data(part.requires[0]).name
		_refresh()
		return
	if Campaign.open_chapter(part.id) != OK:
		status = "Falha ao salvar. Toque novamente."
	else:
		selected = i
		opening = true
		ocean.focus_at(1.62,ocean.labels[i]-Vector2(0,60))
		if not Preferences.values.reduced_motion:
			await get_tree().create_timer(0.21).timeout
		opening = false
		map_open = true
		status = ""
		_choose_current()
	_refresh()

func _select_site(i: int) -> void:
	site = i
	status = ""
	_refresh(false)

func _enter() -> void:
	var item: Dictionary = Campaign.regions[selected].stages[site]
	if Campaign.enter_stage(item.id):
		Campaign.chart_slot = Campaign.active_slot
		Campaign.chart_region = Campaign.chapter
		Campaign.chart_zoom = ocean.zoom
		Campaign.chart_offset = ocean.offset
		get_tree().change_scene_to_file(item.scene)

func _back() -> void:
	if opening: return
	if map_open:
		map_open = false
		status = ""
		_refresh()
	else:
		get_tree().change_scene_to_file(MENU)

func _button(id: String, rect: Rect2, caption: String, action: Callable, primary := false) -> Button:
	var b := Ink.button(caption, primary)
	b.name = id
	b.custom_minimum_size = Vector2.ZERO
	b.clip_text = true
	b.position = rect.position
	b.size = rect.size
	b.pressed.connect(func():
		Preferences.feedback()
		action.call())
	paper.add_child(b)
	return b

func _hit(id: String, rect: Rect2, caption: String, action: Callable) -> void:
	var b := _button(id,rect,"",action)
	b.flat = true
	for state in ["normal","pressed","hover","hover_pressed"]:
		b.add_theme_stylebox_override(state,StyleBoxEmpty.new())
	b.tooltip_text = caption
	b.accessibility_name = caption

func _refresh(animate := true) -> void:
	for c in paper.get_children():
		if c == ocean: continue
		paper.remove_child(c)
		c.queue_free()
	var part: Dictionary = Campaign.regions[selected]
	ocean.visible = not map_open
	if map_open:
		atlas_texture = load(part.chart)
	if not map_open:
		var header := ColorRect.new()
		header.color = Color("#192621f5")
		header.mouse_filter = Control.MOUSE_FILTER_IGNORE
		header.size = Vector2(1280,64)
		paper.add_child(header)
		_caption(Vector2(30,8),"Atlas ancestral  ·  Arquipélago",30)
		_button("Treino",Rect2(806,6,173,52),"Treino",func(): get_tree().change_scene_to_file(FIELD))
		_button("ZoomMenos",Rect2(986,6,55,52),"−",func(): ocean.focus_at(ocean.zoom-0.35,(ocean.PAGE*0.5-ocean.offset)/ocean.zoom))
		_button("ZoomMais",Rect2(1048,6,55,52),"+",func(): ocean.focus_at(ocean.zoom+0.35,(ocean.PAGE*0.5-ocean.offset)/ocean.zoom))
		_button("Voltar",Rect2(1110,6,144,52),"‹ Menu",_back)
		var footer := ColorRect.new()
		footer.color = Color("#192621fa")
		footer.position = Vector2(0,631)
		footer.size = Vector2(1280,89)
		paper.add_child(footer)
		var count := 0
		for item in part.stages:
			if item.id in Campaign.completed: count += 1
		_caption(Vector2(32,634),"Capítulo %s   ·   %s" % [part.folio,part.name],27)
		var hint: String = status if not status.is_empty() else part.biome
		_caption(Vector2(34,678),"%s    ·    %d/%d fases" % [hint,count,part.stages.size()],20)
		var available := Campaign.unlocked(part)
		var open := _button("AbrirCarta",Rect2(915,646,337,60),"Explorar ilha   ›" if available else "Ilha selada",_open.bind(selected),true)
		open.disabled = not available
	else:
		_button("Voltar",Rect2(998,33,238,62),"‹  Arquipélago",_back)
		for i in part.stages.size():
			_hit("Linha%d" % (i+1),Rect2(650,224+69*i,570,64),part.stages[i].name,_select_site.bind(i))
			var pos := _point(part.stages[i])
			_hit("Fase%d" % (i+1),Rect2(pos-Vector2(42,38),Vector2(84,76)),part.stages[i].name,_select_site.bind(i))
		var item: Dictionary = part.stages[site]
		var available := Campaign.unlocked(item)
		var caption := "Explorar demonstração  ›" if item.get("demo",false) else "Entrar na fase  ›"
		var enter := _button("Entrar",Rect2(680,610,526,68),caption if available else "Fase bloqueada",_enter,true)
		enter.disabled = not available
	paper.queue_redraw()
	if animate and not Preferences.values.reduced_motion:
		paper.modulate.a = 0.78
		create_tween().tween_property(paper,"modulate:a",1.0,0.16)

func _point(item: Dictionary) -> Vector2:
	return SHEET.position + Vector2(item.position[0],item.position[1]) * SHEET.size

func _text(at: Vector2, value: String, px: int, color: Color, serif := false) -> void:
	var font: Font = Ink.SERIF if serif else ThemeDB.fallback_font
	paper.draw_string(font, at, value,HORIZONTAL_ALIGNMENT_LEFT,-1,px,color)

func _caption(at: Vector2, caption: String, px: int) -> void:
	var label := Ink.label(caption,px,CREAM)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.position = at
	paper.add_child(label)

func _paint() -> void:
	var part: Dictionary = Campaign.regions[selected]
	paper.draw_rect(Rect2(0,0,1280,720),SEA)
	paper.draw_line(Vector2(44,110),Vector2(1236,110),Color("#687060"),1)
	_text(Vector2(44,41),"MAGIC CORE    /    CAMPANHA",18,GOLD)
	_text(Vector2(42,91),part.name if map_open else "Atlas ancestral",43,CREAM,true)
	if map_open:
		_map(part)

func _map(part: Dictionary) -> void:
	paper.draw_texture_rect(atlas_texture,SHEET,false)
	paper.draw_rect(SHEET,Color("#a2926c"),false,3)
	var positions := {}
	for item in part.stages:
		positions[item.id] = _point(item)
	for item in part.stages:
		for prev in item.requires:
			if positions.has(prev):
				var a: Vector2 = positions[prev]
				var b: Vector2 = positions[item.id]
				var bend := (b-a).orthogonal().normalized()*26.0
				var segments := maxi(4,int(a.distance_to(b)/11))
				for n in segments:
					var t := float(n)/segments
					var dot := a.lerp(b,t)+bend*sin(PI*t)
					paper.draw_circle(dot,3,Color("#f6e1ab"),true,-1,true)
					paper.draw_circle(dot,1.8,Color("#664628"),true,-1,true)
	for i in part.stages.size():
		var item: Dictionary = part.stages[i]
		var pos: Vector2 = positions[item.id]
		var done: bool = item.id in Campaign.completed
		var available := Campaign.unlocked(item)
		if i==site:
			paper.draw_arc(pos,31,0,TAU,48,Color("#fff2be"),4,true)
		paper.draw_circle(pos,24,Color("#3f3225"),true,-1,true)
		paper.draw_circle(pos,20,Color("#29625b") if done else (Color("#8c5429") if available else Color("#514e49")),true,-1,true)
		if item.kind == "Chefe":
			paper.draw_polyline(PackedVector2Array([pos+Vector2(-10,-6),pos+Vector2(-7,7),pos+Vector2(8,7),pos+Vector2(11,-6),pos+Vector2(4,0),pos+Vector2(0,-9),pos+Vector2(-4,0),pos+Vector2(-10,-6)]),GOLD,2,true)
		elif done:
			paper.draw_polyline(PackedVector2Array([pos+Vector2(-9,0),pos+Vector2(-3,7),pos+Vector2(10,-8)]),CREAM,3,true)
		elif not available:
			paper.draw_arc(pos+Vector2(0,-2),6,PI,TAU,12,CREAM,2,true)
			paper.draw_rect(Rect2(pos+Vector2(-7,-2),Vector2(14,11)),CREAM,false,2)
		else:
			_text(pos+Vector2(-7,8),str(i+1),22,CREAM,true)
	_text(Vector2(655,164),"CARTA  "+part.folio+("    /    DEMONSTRAÇÕES" if part.stages[0].get("demo", false) else "    /    ITINERÁRIO"),19,GOLD)
	_text(Vector2(653,205),part.subtitle,33,CREAM,true)
	for i in part.stages.size():
		var entry: Dictionary = part.stages[i]
		var y: int = 224+69*i
		if i==site:
			paper.draw_rect(Rect2(650,y,570,64),Color("#334437"))
		paper.draw_line(Vector2(650,y+63),Vector2(1220,y+63),Color("#586154"),1)
		_text(Vector2(669,y+40),"%02d" % (i+1),20,GOLD)
		_text(Vector2(720,y+39),entry.name,25,CREAM,true)
		var state := "Concluída" if entry.id in Campaign.completed else ("Aberta" if Campaign.unlocked(entry) else "Selada")
		_text(Vector2(1110,y+39),state,19,MUTED)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("menu_back"):
		get_viewport().set_input_as_handled()
		_back()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_node_ready():
		_back()
