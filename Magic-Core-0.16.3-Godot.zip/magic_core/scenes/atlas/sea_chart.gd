extends Control

signal island_selected(index: int)
const ART := preload("res://assets/atlas/arquipelago.webp")
const Ink := preload("res://ui/ink_style.gd")
const PAGE := Vector2(1280,720)
const PARCHMENT := Color("#f4e3b1")
const INK := Color("#30291f")
var selected := 0
var zoom := 1.0
var offset := Vector2.ZERO
var camera: Tween
var shores: Array[PackedVector2Array] = []
var labels: Array[Vector2] = []
var tag_boxes: Array[Rect2] = []
var pointer := -1
var start := Vector2.ZERO
var last := Vector2.ZERO
var dragged := false
var sailing_routes: Array[PackedVector2Array] = []

func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	size = PAGE
	for region in Campaign.regions:
		var polygon := PackedVector2Array()
		for uv in region.coast:
			polygon.append(Vector2(uv[0],uv[1])*PAGE)
		shores.append(polygon)
		var label := Vector2(region.label_pos[0],region.label_pos[1])*PAGE
		labels.append(label)
		var width := Ink.SERIF.get_string_size(region.name,HORIZONTAL_ALIGNMENT_LEFT,-1,21).x + 24
		tag_boxes.append(Rect2(label-Vector2(width/2,0),Vector2(width,32)))
	# Port-to-port sailing lanes cross open water around the engraved headlands.
	for route in [
		[Vector2(.313,.359),Vector2(.36,.381),Vector2(.39,.378),Vector2(.425,.310)],
		[Vector2(.584,.273),Vector2(.622,.327),Vector2(.656,.26),Vector2(.68,.252)],
		[Vector2(.68,.386),Vector2(.61,.448),Vector2(.562,.473),Vector2(.499,.588)],
		[Vector2(.481,.721),Vector2(.519,.771),Vector2(.55,.806),Vector2(.59,.761)]]:
		var curve := Curve2D.new()
		for i in route.size():
			var tangent: Vector2 = (route[mini(i+1,route.size()-1)]-route[maxi(0,i-1)])*PAGE*0.18
			curve.add_point(route[i]*PAGE,-tangent,tangent)
		var points := PackedVector2Array()
		for distance in range(0,int(curve.get_baked_length()),10):
			points.append(curve.sample_baked(distance))
		sailing_routes.append(points)

func _draw() -> void:
	draw_set_transform(offset,0,Vector2.ONE*zoom)
	draw_texture_rect(ART,Rect2(Vector2.ZERO,PAGE),false)
	for points in sailing_routes:
		for dot in points:
			draw_circle(dot,2.5,Color("#e4d49f"),true,-1,true)
			draw_circle(dot,1.6,INK,true,-1,true)
	if selected < shores.size():
		var shore := shores[selected]
		draw_colored_polygon(shore,Color(0.9,0.76,0.36,0.11))
		draw_polyline(shore,Color("#f2d991ba"),2.3,true)
		draw_line(shore[-1],shore[0],Color("#f2d991ba"),2.3,true)
	for i in labels.size():
		var box := tag_boxes[i]
		var active := i==selected
		draw_rect(box,Color("#28352bef") if active else Color("#342e25e5"))
		draw_line(box.position,box.position+Vector2(box.size.x,0),PARCHMENT if active else Color("#988463"),1.4)
		draw_string(Ink.SERIF,box.position+Vector2(12,24),Campaign.regions[i].name,HORIZONTAL_ALIGNMENT_LEFT,-1,21,PARCHMENT)

func _bound(at: Vector2, level: float) -> Vector2:
	return at.clamp(PAGE*(1-level),Vector2.ZERO)

func _set_camera(t: float, from: Vector2, to: Vector2, a: float, b: float) -> void:
	zoom = lerpf(a,b,t)
	offset = _bound(from.lerp(to,t),zoom)
	queue_redraw()

func focus_at(level: float, point: Vector2) -> void:
	if camera: camera.kill()
	level = clampf(level,1.0,2.0)
	var dest := _bound(PAGE*0.5-point*level,level)
	if Preferences.values.reduced_motion:
		_set_camera(1,offset,dest,zoom,level)
		return
	camera = create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	camera.tween_method(_set_camera.bind(offset,dest,zoom,level),0.0,1.0,0.20)

func _press(id: int, pos: Vector2) -> void:
	if pointer != -1: return
	if camera: camera.kill()
	pointer = id
	start = pos
	last = pos
	dragged = false

func _move(id: int, pos: Vector2) -> void:
	if id != pointer: return
	if not dragged and pos.distance_to(start)>10:
		dragged = true
	if dragged:
		offset = _bound(offset+pos-last,zoom)
		queue_redraw()
		last = pos

func _release(id: int, pos: Vector2, canceled: bool) -> void:
	if pointer != id: return
	_move(id,pos)
	pointer = -1
	if canceled or dragged: return
	var uv := (pos-offset)/zoom
	for i in labels.size():
		if tag_boxes[i].grow(4).has_point(uv) or Geometry2D.is_point_in_polygon(uv,shores[i]):
			selected = i
			queue_redraw()
			island_selected.emit(i)
			return

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed: _press(event.index,event.position)
		else: _release(event.index,event.position,event.canceled)
	elif event is InputEventScreenDrag: _move(event.index,event.position)
	elif event is InputEventMouseButton and event.device != InputEvent.DEVICE_ID_EMULATION and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed: _press(-2,event.position)
		else: _release(-2,event.position,event.canceled)
	elif event is InputEventMouseMotion and pointer == -2: _move(-2,event.position)
	else: return
	accept_event()
