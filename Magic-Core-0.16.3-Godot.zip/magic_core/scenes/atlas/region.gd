extends "res://scenes/world/test_world.gd"

const Ink := preload("res://ui/ink_style.gd")
var landscape: Texture2D
var destination: Dictionary
var caption: Label
var requires_hit := false
var error_message := false
var registered := false
var horizon_offset := 0.0

func _ready() -> void:
	destination = Campaign.stage_data(Campaign.stage)
	if destination.is_empty() or not Campaign.enter_stage(Campaign.stage):
		get_tree().call_deferred("change_scene_to_file",Campaign.ATLAS)
		return
	var stages: Array = Campaign.region(Campaign.chapter).stages
	var index := stages.find(destination)
	horizon_offset = float(index)/maxf(1,stages.size()-1)
	requires_hit = index >= 2
	landscape = load("res://assets/atlas/%s_view.webp" % Campaign.chapter)
	super()
	_player.position.x = _extent.x * 0.19
	_player.reset_physics_interpolation()
	if not requires_hit:
		_target.hide()
		_target.collision_layer = 0
	caption = Ink.label("",21,Ink.TEXT)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var backing := Ink.panel(Color("#18221eeb"),Color("#716953"),6)
	backing.set_content_margin_all(8)
	caption.add_theme_stylebox_override("normal",backing)
	_hud.add_child(caption)
	caption.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	caption.offset_left = -270
	caption.offset_right = 270
	caption.offset_top = 16
	caption.offset_bottom = 96
	if not Preferences.values.reduced_motion:
		var veil := ColorRect.new()
		veil.color = Color("#15201c")
		veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hud.add_child(veil)
		veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var fade := veil.create_tween()
		fade.tween_property(veil,"modulate:a",0.0,0.18)
		fade.tween_callback(veil.queue_free)
	_update_caption()

func _update_caption() -> void:
	var goal := "Alcance o marco à direita  ›"
	if requires_hit and not registered:
		goal = "Acerte o alvo e siga até o marco  ›"
	caption.text = destination.name+"\n"+goal

func _physics_process(delta: float) -> void:
	if not is_instance_valid(caption):
		return
	super(delta)
	if not registered and requires_hit and _target.health < _target.max_health:
		registered = true
		_update_caption()
	if _leaving or _wheel.visible or (requires_hit and not registered):
		return
	if _player.position.x < _extent.x * 0.86:
		error_message = false
		return
	if error_message:
		return
	if Campaign.finish_stage() == OK:
		_go_back()
	else:
		error_message = true
		caption.text = "Falha ao salvar. Afaste-se e toque o marco novamente."

func _draw() -> void:
	if landscape == null or _extent == Vector2.ZERO:
		return
	var tex := landscape.get_size()
	var zoom := maxf(_extent.x / tex.x,_extent.y / tex.y) * 1.12
	var crop := _extent / zoom
	draw_texture_rect_region(landscape,Rect2(Vector2.ZERO,_extent),Rect2((tex-crop)*Vector2(horizon_offset,0.52),crop))
	draw_rect(Rect2(0,_floor_y,_extent.x,_extent.y-_floor_y),Color("#19221ec9"))
	draw_line(Vector2(0,_floor_y),Vector2(_extent.x,_floor_y),Color("#b0a790"),2)
	var foot := Vector2(_extent.x * 0.86,_floor_y)
	draw_colored_polygon(PackedVector2Array([foot+Vector2(-12,0),foot+Vector2(-8,-43),foot+Vector2(0,-54),foot+Vector2(9,-44),foot+Vector2(13,0)]),Color("#36463d"))
	draw_polyline(PackedVector2Array([foot+Vector2(-4,-39),foot+Vector2(2,-43),foot+Vector2(6,-39),foot+Vector2(1,-34),foot+Vector2(-4,-39)]),Color("#dfc995"),2,true)

func _go_back() -> void:
	if _leaving:
		return
	_leaving = true
	Campaign.return_to_map = true
	Preferences.feedback()
	get_tree().change_scene_to_file(Campaign.ATLAS)
