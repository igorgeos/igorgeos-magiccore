extends PanelContainer

signal closed

const Ink := preload("res://ui/ink_style.gd")
const ART := preload("res://assets/menu/configuracoes/astrolabio.jpg")
const HANDLE := preload("res://assets/menu/configuracoes/ponteiro.svg")
const CARD_SIZE := Vector2(1030, 600)
const FRAME_EDGE := Color("#6e6251")
const CONTROL_EDGE := Color("#364c61")
const CONTROL_FILL := Color("#101c28")

var _draft: Dictionary
var _error: Label
var _capture := ""
var _key_buttons: Dictionary = {}


func _ready() -> void:
	_draft = Preferences.values.duplicate()
	var frame := Ink.panel(Color("#0b141e"), FRAME_EDGE, 5)
	frame.set_content_margin_all(2)
	frame.shadow_size = 22
	frame.shadow_color = Color(0, 0, 0, 0.58)
	add_theme_stylebox_override("panel", frame)
	set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	offset_left = -CARD_SIZE.x / 2.0
	offset_right = CARD_SIZE.x / 2.0
	offset_top = -CARD_SIZE.y / 2.0
	offset_bottom = CARD_SIZE.y / 2.0
	var layout := HBoxContainer.new()
	layout.add_theme_constant_override("separation", 0)
	add_child(layout)
	_add_illustration(layout)
	_add_controls(layout)


func _add_illustration(layout: HBoxContainer) -> void:
	var artwork := TextureRect.new()
	artwork.custom_minimum_size.x = 276.0
	artwork.texture = ART
	artwork.modulate = Preferences.art_tint()
	artwork.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	artwork.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	artwork.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(artwork)
	var edge := ColorRect.new()
	edge.custom_minimum_size.x = 1.0
	edge.color = FRAME_EDGE
	edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(edge)


func _add_controls(layout: HBoxContainer) -> void:
	var inset := MarginContainer.new()
	inset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inset.add_theme_constant_override("margin_left", 31)
	inset.add_theme_constant_override("margin_right", 31)
	inset.add_theme_constant_override("margin_top", 20)
	inset.add_theme_constant_override("margin_bottom", 20)
	layout.add_child(inset)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 13)
	inset.add_child(column)
	var title := _label("Configurações", 42, Ink.TEXT)
	title.add_theme_font_override("font", Ink.SERIF)
	column.add_child(title)
	var rule := ColorRect.new()
	rule.custom_minimum_size.y = 1
	rule.color = FRAME_EDGE
	rule.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(rule)

	var tabs := TabContainer.new()
	tabs.name = "Abas"
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.add_theme_font_size_override("font_size", Preferences.text_size(18))
	tabs.add_theme_color_override("font_selected_color", Ink.TEXT)
	tabs.add_theme_color_override("font_unselected_color", Ink.MUTED)
	for style_name in ["tab_selected", "tab_unselected", "tab_hovered"]:
		var style := Ink.panel(Color("#233d55") if style_name == "tab_selected" else CONTROL_FILL, CONTROL_EDGE, 5)
		style.content_margin_top = 11
		style.content_margin_bottom = 11
		tabs.add_theme_stylebox_override(style_name, style)
	var tab_body := Ink.panel(Color("#0e1823"), CONTROL_EDGE, 5)
	tab_body.set_content_margin_all(10)
	tabs.add_theme_stylebox_override("panel", tab_body)
	column.add_child(tabs)
	var audio := _tab(tabs, "Áudio")
	_volume(audio, "Trilha ambiente", "music")
	_volume(audio, "Navegação do menu", "navigation")
	_volume(audio, "Confirmação", "effects")
	var display := _tab(tabs, "Gráficos")
	_frame_limit(display)
	_dropdown(display, "Brilho mágico", "visual_quality", ["Econômico", "Equilibrado", "Completo"])
	_volume(display, "Luminosidade do cenário", "brightness", 60, 125, 5)
	var control := _tab(tabs, "Controles")
	var touch := _group(control, "TOQUE")
	_toggle(touch, "Girar ao arrastar", "swipe_enabled")
	_dropdown(touch, "Sensibilidade do arrasto", "swipe_sensitivity", ["Baixa", "Padrão", "Alta"])
	_toggle(touch, "Vibração no Android", "vibration")
	var keyboard := _group(control, "ATALHOS DO CARROSSEL COM TECLADO")
	_bind_key(keyboard, "Opção anterior", "menu_previous")
	_bind_key(keyboard, "Próxima opção", "menu_next")
	_bind_key(keyboard, "Confirmar selo", "menu_confirm")
	_bind_key(keyboard, "Voltar", "menu_back")
	var reset := Ink.button("Restaurar atalhos")
	reset.pressed.connect(_reset_keys)
	keyboard.add_child(reset)
	var access := _tab(tabs, "Acessibilidade")
	_volume(access, "Tamanho do HUD", "hud_size", Preferences.HUD_MIN, Preferences.HUD_MAX, 5)
	_toggle(access, "Reduzir movimento", "reduced_motion")
	_toggle(access, "Texto maior", "large_text")
	_toggle(access, "Alto contraste", "high_contrast")

	_error = _label("", 17, Color("#efb698"))
	_error.hide()
	column.add_child(_error)
	tabs.tab_changed.connect(func(_tab_index: int) -> void: _finish_capture())
	var actions := HBoxContainer.new()
	actions.alignment = BoxContainer.ALIGNMENT_END
	actions.add_theme_constant_override("separation", 12)
	column.add_child(actions)
	var cancel := Ink.button("Cancelar")
	cancel.pressed.connect(closed.emit)
	actions.add_child(cancel)
	var save := Ink.button("Salvar e voltar", true)
	save.add_theme_stylebox_override("normal", Ink.panel(Color("#294661"), Ink.BLUE, 5))
	save.pressed.connect(_save)
	actions.add_child(save)
	cancel.grab_focus()


func _tab(tabs: TabContainer, caption: String) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	scroll.name = caption
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.follow_focus = true
	tabs.add_child(scroll)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 9)
	scroll.add_child(content)
	return content


func _group(parent: VBoxContainer, caption: String) -> VBoxContainer:
	var box := PanelContainer.new()
	var style := Ink.panel(CONTROL_FILL, Color("#293746"), 5)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 10
	style.content_margin_bottom = 9
	box.add_theme_stylebox_override("panel", style)
	parent.add_child(box)
	var group := VBoxContainer.new()
	group.add_theme_constant_override("separation", 4)
	box.add_child(group)
	group.add_child(_label(caption, 16, Ink.BLUE))
	return group


func _row(parent: VBoxContainer, caption: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var label := _label(caption, 22, Ink.TEXT)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(label)
	parent.add_child(row)
	return row


func _volume(parent: VBoxContainer, caption: String, key: String,
		minimum := 0, maximum := 100, step := 1) -> void:
	var row := _row(parent, caption)
	var slider := HSlider.new()
	slider.name = key
	slider.custom_minimum_size = Vector2(184, 48)
	slider.min_value = minimum
	slider.max_value = maximum
	slider.step = step
	slider.value = _draft[key]
	slider.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	slider.add_theme_icon_override("grabber", HANDLE)
	slider.add_theme_icon_override("grabber_highlight", HANDLE)
	slider.add_theme_stylebox_override("slider", _track(Color("#213243")))
	slider.add_theme_stylebox_override("grabber_area", _track(Color("#618db0")))
	slider.add_theme_stylebox_override("grabber_area_highlight", _track(Ink.BLUE))
	row.add_child(slider)
	var value := _label("%d%%" % slider.value, 19, Ink.BLUE)
	value.custom_minimum_size = Vector2(58, 0)
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(value)
	slider.value_changed.connect(func(amount: float) -> void:
		_draft[key] = roundi(amount)
		value.text = "%d%%" % amount)


func _track(tone: Color) -> StyleBoxFlat:
	var track := StyleBoxFlat.new()
	track.bg_color = tone
	track.set_corner_radius_all(3)
	track.content_margin_top = 3
	track.content_margin_bottom = 3
	return track


func _frame_limit(parent: VBoxContainer) -> void:
	var row := _row(parent, "Limite de quadros")
	var choices := ButtonGroup.new()
	for limit in [30, 60]:
		var option := _choice("%d FPS" % limit, 98)
		option.name = "FPS%d" % limit
		option.button_group = choices
		option.button_pressed = _draft.fps == limit
		option.pressed.connect(func() -> void: _draft.fps = limit)
		row.add_child(option)


func _toggle(parent: VBoxContainer, caption: String, key: String) -> void:
	var control := _choice("Ativo" if _draft[key] else "Desativado", 140)
	control.name = key
	control.button_pressed = _draft[key]
	control.toggled.connect(func(enabled: bool) -> void:
		_draft[key] = enabled
		control.text = "Ativo" if enabled else "Desativado")
	_row(parent, caption).add_child(control)


func _dropdown(parent: VBoxContainer, caption: String, key: String, labels: Array[String]) -> void:
	var select := OptionButton.new()
	select.name = key
	select.custom_minimum_size = Vector2(174, 48)
	select.add_theme_font_size_override("font_size", Preferences.text_size(18))
	select.add_theme_stylebox_override("normal", Ink.panel(CONTROL_FILL, CONTROL_EDGE, 5))
	select.add_theme_stylebox_override("hover", Ink.panel(Color("#27425a"), Ink.BLUE, 5))
	for label in labels:
		select.add_item(label)
	select.select(_draft[key])
	select.item_selected.connect(func(index: int) -> void: _draft[key] = index)
	_row(parent, caption).add_child(select)


func _bind_key(parent: VBoxContainer, caption: String, action: String) -> void:
	var button := Ink.button(OS.get_keycode_string(_draft[action]))
	button.name = action
	button.custom_minimum_size.x = 165
	button.add_theme_font_size_override("font_size", Preferences.text_size(18))
	button.pressed.connect(func() -> void:
		if _capture == action:
			_finish_capture()
		else:
			_finish_capture()
			_capture = action
			button.text = "Pressione uma tecla")
	_key_buttons[action] = button
	_row(parent, caption).add_child(button)


func _input(event: InputEvent) -> void:
	if _capture.is_empty() or not event is InputEventKey or not event.pressed or event.echo:
		return
	get_viewport().set_input_as_handled()
	var key: Key = event.physical_keycode if event.physical_keycode != KEY_NONE else event.keycode
	if key == KEY_ESCAPE:
		_finish_capture()
		return
	if key in [KEY_SHIFT, KEY_CTRL, KEY_ALT, KEY_META, KEY_NONE]:
		return
	for action in Preferences.MENU_ACTIONS:
		if action != _capture and _draft[action] == key:
			_error.text = "Esta tecla já está em uso."
			_error.show()
			return
	_draft[_capture] = key
	_finish_capture()


func _finish_capture() -> void:
	if not _capture.is_empty():
		_key_buttons[_capture].text = OS.get_keycode_string(_draft[_capture])
		_capture = ""
	_error.hide()


func _reset_keys() -> void:
	_finish_capture()
	for action in Preferences.MENU_ACTIONS:
		_draft[action] = Preferences.DEFAULTS[action]
		_key_buttons[action].text = OS.get_keycode_string(_draft[action])


func _choice(caption: String, width: float) -> Button:
	var button := Ink.button(caption)
	button.toggle_mode = true
	button.custom_minimum_size = Vector2(width, 48)
	button.add_theme_font_size_override("font_size", Preferences.text_size(19))
	button.add_theme_stylebox_override("normal", Ink.panel(Color("#0d1925"), CONTROL_EDGE, 5))
	button.add_theme_stylebox_override("pressed", Ink.panel(Color("#27425a"), Ink.BLUE, 5))
	button.add_theme_stylebox_override("hover_pressed", Ink.panel(Color("#31516b"), Ink.BLUE, 5))
	return button


func _label(caption: String, font_size: int, color: Color) -> Label:
	return Ink.label(caption, font_size, color)


func _save() -> void:
	_finish_capture()
	var previous: Dictionary = Preferences.values
	Preferences.values = _draft
	if Preferences.save() != OK:
		Preferences.values = previous
		_error.text = "Não foi possível salvar as configurações."
		_error.show()
		return
	Preferences.apply()
	Preferences.feedback()
	closed.emit()
