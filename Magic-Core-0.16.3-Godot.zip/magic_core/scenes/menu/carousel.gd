extends Control

signal activated(index: int)

const Ink := preload("res://ui/ink_style.gd")
const TITLES := ["Novo jogo", "Configurações", "Créditos", "Sair", "Jogar"]
const PLAY_INDEX := 4
const ITEM_COUNT := 5
const SEAL_PATHS := [
	"res://assets/menu/selos/novo_jogo.res",
	"res://assets/menu/selos/configuracoes.res",
	"res://assets/menu/selos/creditos.res",
	"res://assets/menu/selos/sair.res",
	"res://assets/menu/selos/jogar.res",
]
const RADIUS := 94.0
const STEP := TAU / ITEM_COUNT
const DRAG_THRESHOLD := 16.0
const SWIPE_STEPS := [320.0, 240.0, 154.0]
const NONE := -2
const GLOW := Color("#8dccff")
const LABEL_FONT := 26

var _rotation := float(PLAY_INDEX):
	set(value):
		_rotation = value
		queue_redraw()
var _target := PLAY_INDEX
var _animation: Tween
var _press_animation: Tween
var _pointer := NONE
var _origin := Vector2.ZERO
var _drag_rotation := 0.0
var _dragging := false
var _press_visual_item := -1
var _press_amount := 0.0:
	set(value):
		_press_amount = value
		queue_redraw()
var _confirming := false
var _seals: Array[Texture2D] = []
var _halo: GradientTexture2D


func _ready() -> void:
	# Os arquivos .res trazem a imagem embutida e dispensam o cache de importação dos PNGs.
	for path: String in SEAL_PATHS:
		var texture: Texture2D
		if ResourceLoader.exists(path, "Texture2D"):
			texture = ResourceLoader.load(path, "Texture2D") as Texture2D
		_seals.append(texture)
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.66, 0.74, 0.84, 1.0])
	gradient.colors = PackedColorArray([
		Color(1, 1, 1, 0), Color(1, 1, 1, 0), Color(1, 1, 1, 0.53),
		Color(1, 1, 1, 0.19), Color(1, 1, 1, 0),
	])
	_halo = GradientTexture2D.new()
	_halo.width = 128
	_halo.height = 128
	_halo.gradient = gradient
	_halo.fill = GradientTexture2D.FILL_RADIAL
	_halo.fill_from = Vector2(0.5, 0.5)
	_halo.fill_to = Vector2(0.5, 0.0)
	mouse_default_cursor_shape = CURSOR_POINTING_HAND
	resized.connect(queue_redraw)


func advance(amount: int) -> void:
	if _pointer == NONE and not _confirming:
		_select(_target + amount)


func activate() -> void:
	if _pointer != NONE or _confirming:
		return
	_confirming = true
	var index := posmod(_target, TITLES.size())
	Preferences.feedback(true)
	if not Preferences.values.reduced_motion:
		_animate_press(index, 1.0, 0.055)
		await _press_animation.finished
		_animate_press(index, 0.0, 0.13)
		await _press_animation.finished
	_confirming = false
	activated.emit(index)


func _select(target: int) -> void:
	if _animation and _animation.is_valid():
		_animation.kill()
	if _target != target:
		Preferences.navigation_feedback()
	# Keep the accumulated angle small without disturbing the displayed seals.
	var turns := floori(float(target) / TITLES.size()) * TITLES.size()
	_rotation -= turns
	target -= turns
	_target = target
	var distance := absf(_rotation - _target)
	if Preferences.values.reduced_motion or is_zero_approx(distance):
		_rotation = _target
		return
	_animation = create_tween()
	var duration := lerpf(0.21, 0.46, clampf(distance / 2.0, 0.0, 1.0))
	_animation.tween_property(self, "_rotation", float(_target), duration) \
		.set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)


func _animate_press(index: int, amount: float, duration: float) -> void:
	if _press_animation and _press_animation.is_valid():
		_press_animation.kill()
	if _press_visual_item != index:
		_press_amount = 0.0
		_press_visual_item = index
	if index < 0 or Preferences.values.reduced_motion:
		_press_amount = amount
		return
	_press_animation = create_tween()
	_press_animation.tween_property(self, "_press_amount", amount, duration) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _gui_input(event: InputEvent) -> void:
	if event.device == InputEvent.DEVICE_ID_EMULATION:
		return
	if event is InputEventScreenTouch:
		if event.pressed and not event.canceled:
			_begin(event.position, event.index)
		elif _pointer == event.index:
			_end(event.position, event.canceled)
	elif event is InputEventScreenDrag and _pointer == event.index:
		_move(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_begin(event.position, -1)
		elif _pointer == -1:
			_end(event.position)
	elif event is InputEventMouseMotion and _pointer == -1:
		_move(event.position)


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		cancel_gesture()


func cancel_gesture() -> void:
	if _pointer != NONE:
		_end(_origin, true)


func _begin(point: Vector2, pointer: int) -> void:
	if _pointer != NONE or _confirming:
		return
	if _animation and _animation.is_valid():
		_animation.kill()
	_pointer = pointer
	_origin = point
	_drag_rotation = _rotation
	_dragging = false
	_animate_press(_hit_item(point), 1.0, 0.09)


func _move(point: Vector2) -> void:
	var delta := point - _origin
	if not _dragging and delta.length() > DRAG_THRESHOLD:
		_dragging = true
		_animate_press(_press_visual_item, 0.0, 0.10)
	if _dragging and Preferences.values.swipe_enabled and not Preferences.values.reduced_motion:
		_rotation = _drag_rotation - clampf(delta.x / SWIPE_STEPS[Preferences.values.swipe_sensitivity], -2.0, 2.0)


func _end(point: Vector2, canceled := false) -> void:
	var delta := point - _origin
	var pressed := _press_visual_item
	_pointer = NONE
	_animate_press(pressed, 0.0, 0.13)
	if canceled:
		_select(_target)
		return
	if _dragging or delta.length() > DRAG_THRESHOLD:
		var step: float = SWIPE_STEPS[Preferences.values.swipe_sensitivity]
		if Preferences.values.swipe_enabled and absf(delta.x) >= step * 0.19 and absf(delta.x) > absf(delta.y):
			_select(roundi(_drag_rotation) - signi(roundi(delta.x)) * clampi(roundi(absf(delta.x) / step), 1, 2))
		else:
			_select(_target)
		return
	var item := _hit_item(point)
	if item >= 0 and item == pressed:
		var half := ITEM_COUNT >> 1
		var difference := posmod(item - _target + half, ITEM_COUNT) - half
		if difference == 0:
			_select(_target)
			activate()
		else:
			if not Preferences.values.reduced_motion:
				_press_amount = maxf(_press_amount, 0.3)
			advance(difference)
	else:
		_select(_target)


func _wheel_center() -> Vector2:
	return Vector2(size.x * 0.5, size.y - 249.0)


func _orbit_width() -> float:
	return minf(301.0, size.x * 0.29)


func _angle(index: int) -> float:
	return (float(index) - _rotation) * STEP


func _depth(index: int) -> float:
	return (1.0 + cos(_angle(index))) * 0.5


func _position(index: int) -> Vector2:
	var angle := _angle(index)
	return _wheel_center() + Vector2(sin(angle) * _orbit_width(), cos(angle) * 44.0)


func _item_scale(index: int) -> float:
	return lerpf(0.39, 1.0, _depth(index))


func _order() -> Array[int]:
	var items: Array[int] = []
	items.assign(range(ITEM_COUNT))
	items.sort_custom(func(a: int, b: int) -> bool: return _depth(a) < _depth(b))
	return items


func _hit_item(point: Vector2) -> int:
	var items := _order()
	items.reverse()
	for index in items:
		if _depth(index) >= 0.27 and point.distance_to(_position(index)) <= RADIUS * _item_scale(index):
			return index
	return -1


func _draw() -> void:
	var middle := _wheel_center()
	# Two halves of a track on a tilted plane. Draw the seals back to front.
	for front in [false, true]:
		var points := PackedVector2Array()
		for i in range(41):
			var theta := float(i) * PI / 40.0 + (0.0 if front else PI)
			points.append(middle + Vector2(cos(theta) * (_orbit_width() + 58), sin(theta) * 65 + 17))
		var color := Color(0.48, 0.66, 0.80, 0.47 if front else 0.20)
		draw_polyline(points, color, 1.35, true)
	for index in _order():
		if _depth(index) > 0.12:
			_draw_seal(index)
	draw_set_transform(Vector2.ZERO)
	for index in range(ITEM_COUNT):
		var x := middle.x + (index - (ITEM_COUNT - 1) * 0.5) * 23.0
		var color := Color("#718194").lerp(GLOW, _focus_strength(index))
		var point := Vector2(x, size.y - 86.0)
		draw_colored_polygon(PackedVector2Array([point + Vector2(0, -4), point + Vector2(5, 0),
			point + Vector2(0, 4), point + Vector2(-5, 0)]), color)


func _draw_seal(index: int) -> void:
	var depth := _depth(index)
	var focus := _focus_strength(index)
	var pressure := _press_amount if _press_visual_item == index else 0.0
	var scale_factor := _item_scale(index)
	if not Preferences.values.reduced_motion:
		scale_factor *= lerpf(1.0, 0.92, pressure)
	draw_set_transform(_position(index), 0.0, Vector2.ONE * scale_factor)
	var light := lerpf(0.74, 1.0, depth) * lerpf(1.0, 0.86, pressure)
	var plate_size := Vector2.ONE * RADIUS * 2.0
	var show_focus := focus > 0.02 or pressure > 0.02
	if show_focus and Preferences.values.visual_quality > 0 and not Preferences.values.high_contrast:
		var intensity := 0.48 if Preferences.values.visual_quality == 1 else 1.0
		var halo_size := Vector2.ONE * 246.0
		draw_texture_rect(_halo, Rect2(-halo_size * 0.5, halo_size), false,
			Color(GLOW, (0.78 * focus + 0.22 * pressure) * intensity))
	draw_circle(Vector2(0, 6), RADIUS - 3.0, Color(0.009, 0.017, 0.029, 0.77), true, -1.0, true)
	var texture := _seals[index] if index < _seals.size() else null
	if texture != null:
		draw_texture_rect(texture, Rect2(-plate_size * 0.5, plate_size), false,
			Color(light, light, light, 1.0))
	else:
		# Um recurso incompleto não impede que a opção continue visível e clicável.
		draw_circle(Vector2.ZERO, RADIUS - 2.0, Color("#131f2c"), true, -1.0, true)
		draw_arc(Vector2.ZERO, RADIUS - 4.0, 0.0, TAU, 64, Ink.METAL, 2.5, true)
		draw_arc(Vector2.ZERO, RADIUS - 11.0, 0.0, TAU, 64, Ink.BLUE.darkened(0.34), 1.5, true)
		draw_colored_polygon(PackedVector2Array([Vector2(0, -55), Vector2(17, -30),
			Vector2(0, -5), Vector2(-17, -30)]), Ink.BLUE.darkened((1.0 - depth) * 0.44))
	if show_focus:
		draw_arc(Vector2.ZERO, RADIUS - 1.5, 0.0, TAU, 64,
			Color(GLOW, minf(0.78 * focus + 0.22 * pressure, 1.0)), 2.0, true)
	if index != PLAY_INDEX or texture == null:
		_draw_label(index, focus)


func _focus_strength(index: int) -> float:
	var front := smoothstep(0.64, 1.0, _depth(index))
	return front * front


func _draw_label(index: int, focus: float) -> void:
	var font := ThemeDB.fallback_font
	var label: String = TITLES[index]
	var font_size := Preferences.text_size(22 if index == 1 else LABEL_FONT)
	var width := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var baseline := Vector2(-width * 0.5, 46)
	var plaque := Rect2(-width * 0.5 - 7.0, 23.0, width + 14.0, 34.0)
	draw_rect(plaque, Color.BLACK if Preferences.values.high_contrast else Color(0.021, 0.035, 0.052, 0.94))
	draw_line(plaque.end - Vector2(plaque.size.x, 0), plaque.end,
		Color("#6c7b87").lerp(GLOW, focus), 1.5, true)
	draw_string(font, baseline, label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size,
		Color("#dedfe4").lerp(Color("#fff3dc"), focus))
