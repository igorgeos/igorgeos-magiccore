extends Control

const IntroArt := preload("res://assets/splash/templo_mistico_lua_cheia.png")
const BridgeArt := preload("res://assets/menu/ponte_do_sino_partido.jpg")
const CoreArt := preload("res://assets/splash/santuario_do_nucleo.jpg")
const Ink := preload("res://ui/ink_style.gd")
const Story := preload("res://systems/story.gd")
const MENU := "res://scenes/menu/main_menu.tscn"

enum Page { INTRO, NEW_SLOTS, LOAD_SLOTS, REPLACE, STORY }

var _page := Page.INTRO
var _replace_slot := 0
var _art: TextureRect
var _body: VBoxContainer
var _card: PanelContainer
var _notice: Label
var _primary: Button


func _ready() -> void:
	_art = TextureRect.new()
	_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_art.texture = IntroArt
	_art.modulate = Preferences.art_tint(0.87)
	add_child(_art)
	_art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var veil := ColorRect.new()
	veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	veil.color = Color(0.012, 0.02, 0.039, 0.23)
	add_child(veil)
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var entry := Page.LOAD_SLOTS if Campaign.show_saved_on_entry else Page.INTRO
	Campaign.show_saved_on_entry = false
	_show_page(entry)


func _show_page(page: Page) -> void:
	_page = page
	_primary = null
	if is_instance_valid(_card):
		_card.hide()
		_card.queue_free()
	var wide := page in [Page.NEW_SLOTS, Page.LOAD_SLOTS]
	_card = PanelContainer.new()
	var frame := Ink.panel(Color(0.036, 0.068, 0.103, 0.97), Ink.METAL, 9)
	frame.set_content_margin_all(28)
	frame.shadow_size = 15
	frame.shadow_color = Color(0, 0, 0, 0.54)
	_card.add_theme_stylebox_override("panel", frame)
	add_child(_card)
	_card.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_card.offset_left = -546
	_card.offset_right = 546 if wide else 133
	_card.offset_top = -251
	_card.offset_bottom = 251
	_body = VBoxContainer.new()
	_body.add_theme_constant_override("separation", 12)
	_card.add_child(_body)
	_art.texture = IntroArt
	match page:
		Page.INTRO:
			_heading("Prólogo", "O Núcleo Desperta")
			_paragraph(Story.INTRO)
		Page.NEW_SLOTS:
			_heading("Nova campanha", "Escolha um slot")
			_draw_slots()
		Page.LOAD_SLOTS:
			_heading("Continuar", "Escolha uma partida")
			_draw_slots()
		Page.REPLACE:
			_heading("Nova campanha", "Substituir o slot %d?" % _replace_slot)
			_paragraph("Uma nova campanha ocupará este slot. O progresso salvo nele será apagado.")
		Page.STORY:
			var beat: Dictionary = Story.CHECKPOINTS[Campaign.checkpoint]
			var chapter: Dictionary = Story.CHAPTERS[beat.chapter]
			_art.texture = CoreArt if Campaign.checkpoint == "santuario" else BridgeArt
			_heading(chapter.title, beat.title)
			_paragraph(beat.body)
			var saved := "Progresso salvo · Slot %d" % Campaign.active_slot
			if beat.next.is_empty():
				saved = "Fim do prólogo · " + saved
			_body.add_child(Ink.label(saved, 18, Ink.BLUE))
	_notice = Ink.label("", 18, Color("#ffc5a1"))
	_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_notice.hide()
	_body.add_child(_notice)
	_footer()
	if not Preferences.values.reduced_motion:
		_card.modulate.a = 0.0
		_card.create_tween().tween_property(_card, "modulate:a", 1.0, 0.23)


func _heading(context: String, title: String) -> void:
	_body.add_child(Ink.label(context, 19, Ink.BLUE))
	var headline := Ink.label(title, 39, Ink.TEXT)
	headline.add_theme_font_override("font", Ink.SERIF)
	headline.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body.add_child(headline)
	_body.add_child(HSeparator.new())


func _paragraph(copy: String) -> void:
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var label := Ink.label(copy, 25, Ink.TEXT)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_constant_override("line_spacing", 7)
	scroll.add_child(label)


func _draw_slots() -> void:
	var slots := HBoxContainer.new()
	slots.size_flags_vertical = Control.SIZE_EXPAND_FILL
	slots.add_theme_constant_override("separation", 12)
	_body.add_child(slots)
	for slot in range(1, Campaign.SLOT_COUNT + 1):
		var data := Campaign.read_slot(slot)
		var panel := PanelContainer.new()
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var style := Ink.panel(Color("#111f2b"), Color("#52667a"), 6)
		style.set_content_margin_all(16)
		panel.add_theme_stylebox_override("panel", style)
		slots.add_child(panel)
		var contents := VBoxContainer.new()
		contents.add_theme_constant_override("separation", 9)
		panel.add_child(contents)
		contents.add_child(Ink.label("Slot %d" % slot, 20, Ink.BLUE))
		var title := "Slot vazio"
		var details := "Disponível para uma nova campanha."
		match data.state:
			Campaign.SAVED:
				var beat: Dictionary = Story.CHECKPOINTS[data.checkpoint]
				var chapter: Dictionary = Story.CHAPTERS[beat.chapter]
				title = beat.title
				details = "%s · Trecho %d/%d\n%s" % [chapter.label, beat.page, chapter.length, data.updated]
				if data.visited_atlas and not Campaign.region(str(data.chapter)).is_empty():
					title = Campaign.region(data.chapter).name
					details = "%d marcos concluídos\n%s" % [data.completed.size(),data.updated]
			Campaign.UNREADABLE:
				title = "Salvamento indisponível"
				details = "Não foi possível carregar esta partida."
		var heading := Ink.label(title, 22, Ink.TEXT)
		heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		contents.add_child(heading)
		var info := Ink.label(details, 17, Ink.MUTED)
		info.size_flags_vertical = Control.SIZE_EXPAND_FILL
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		contents.add_child(info)
		var caption := "Continuar" if _page == Page.LOAD_SLOTS else (
			"Criar partida" if data.state == Campaign.EMPTY else "Substituir…")
		var button := _action(contents, caption, _choose_slot.bind(slot), true)
		button.name = "Slot%d" % slot
		button.disabled = _page == Page.LOAD_SLOTS and data.state != Campaign.SAVED
		if _primary == null and not button.disabled:
			_primary = button


func _footer() -> void:
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 12)
	_body.add_child(actions)
	var back_label := "Voltar ao menu" if _page in [Page.INTRO, Page.LOAD_SLOTS, Page.STORY] else "Voltar"
	var back := _action(actions, back_label, _back)
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	back.size_flags_stretch_ratio = 0.63
	match _page:
		Page.INTRO:
			_primary = _action(actions, "Iniciar campanha", _show_page.bind(Page.NEW_SLOTS), true)
		Page.REPLACE:
			_action(actions, "Substituir partida", _start.bind(_replace_slot, true), true)
			_primary = back
		Page.STORY:
			var beat: Dictionary = Story.CHECKPOINTS[Campaign.checkpoint]
			if beat.action.is_empty():
				_primary = _action(actions, "Abrir atlas", func(): get_tree().change_scene_to_file(Campaign.ATLAS), true)
			else:
				_primary = _action(actions, beat.action, _advance, true)
	if _primary:
		_primary.grab_focus()
	else:
		back.grab_focus()


func _action(parent: Container, caption: String, callback: Callable, primary := false) -> Button:
	var button := Ink.button(caption, primary)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func() -> void:
		Preferences.feedback()
		callback.call())
	parent.add_child(button)
	return button


func _choose_slot(slot: int) -> void:
	if _page == Page.LOAD_SLOTS:
		if Campaign.resume(slot) == OK:
			if Campaign.visited_atlas:
				Campaign.return_to_map = true
				get_tree().change_scene_to_file(Campaign.ATLAS)
			else:
				_show_page(Page.STORY)
		else:
			_problem("Não foi possível abrir esta partida.")
	elif Campaign.read_slot(slot).state == Campaign.EMPTY:
		_start(slot)
	else:
		_replace_slot = slot
		_show_page(Page.REPLACE)


func _start(slot: int, replace := false) -> void:
	if Campaign.start(slot, replace) == OK:
		_show_page(Page.STORY)
	else:
		_problem("Não foi possível salvar a nova partida. Tente novamente.")


func _advance() -> void:
	if Campaign.advance() == OK:
		_show_page(Page.STORY)
	else:
		_problem("Não foi possível salvar o progresso. Tente novamente.")


func _problem(message: String) -> void:
	_notice.text = message
	_notice.show()


func _back() -> void:
	match _page:
		Page.NEW_SLOTS:
			_show_page(Page.INTRO)
		Page.REPLACE:
			_show_page(Page.NEW_SLOTS)
		_:
			Campaign.leave()
			get_tree().change_scene_to_file(MENU)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("menu_back", false):
		get_viewport().set_input_as_handled()
		_back()
	elif event.is_action_pressed("menu_confirm", false) and _primary and not _primary.disabled:
		get_viewport().set_input_as_handled()
		_primary.pressed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_node_ready():
		_back()
