extends Control

const Ink := preload("res://ui/ink_style.gd")
const Carousel := preload("res://scenes/menu/carousel.gd")
const MenuPanel := preload("res://scenes/menu/menu_panel.gd")
const PROLOGUE := "res://scenes/menu/new_game.tscn"
const TEST_WORLD := "res://scenes/world/test_world.tscn"
const ARROW_SIZE := Vector2(64.0, 64.0)

var _carousel: Control
var _previous: Button
var _next: Button
var _continue: Button
var _guide: Label
var _panel: Control
var _panel_animation: Tween
var _closing_panel := false
var _changing_scene := false


func _ready() -> void:
	_carousel = Carousel.new()
	_carousel.name = "Carrossel"
	add_child(_carousel)
	_carousel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_carousel.activated.connect(_open_option)
	_previous = _arrow("‹", "Opção anterior", -1)
	_next = _arrow("›", "Próxima opção", 1)
	var guide := Label.new()
	_guide = guide
	guide.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
	guide.add_theme_font_size_override("font_size", 23)
	guide.add_theme_color_override("font_color", Ink.TEXT)
	var guide_backing := Ink.panel(Color(0.025, 0.047, 0.075, 0.88), Color("#495d70"), 10)
	guide_backing.content_margin_top = 5
	guide_backing.content_margin_bottom = 5
	guide.add_theme_stylebox_override("normal", guide_backing)
	add_child(guide)
	guide.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	guide.offset_left = -314
	guide.offset_right = 314
	guide.offset_top = -65
	guide.offset_bottom = -24
	if Campaign.has_saved():
		_continue = Ink.button("Continuar", true)
		_continue.name = "ContinuarCampanha"
		_continue.pressed.connect(_continue_campaign)
		add_child(_continue)
		_continue.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
		_continue.anchor_top = 0.31
		_continue.anchor_bottom = 0.31
		_continue.offset_left = -104
		_continue.offset_right = 104
		_continue.offset_top = 62
		_continue.offset_bottom = 118
	Preferences.changed.connect(_refresh_appearance)
	_refresh_appearance()
	resized.connect(_layout_arrows)
	_layout_arrows()
	Preferences.start_ambience()
	if not Preferences.values.reduced_motion:
		modulate.a = 0.0
		create_tween().tween_property(self, "modulate:a", 1.0, 0.36)


func _arrow(caption: String, help: String, direction: int) -> Button:
	var button := Ink.button(caption)
	button.tooltip_text = help
	button.focus_mode = Control.FOCUS_NONE
	button.custom_minimum_size = ARROW_SIZE
	button.size = ARROW_SIZE
	button.add_theme_font_size_override("font_size", 36)
	button.resized.connect(func() -> void: button.pivot_offset = button.size * 0.5)
	button.pivot_offset = button.size * 0.5
	var press_tween: Array[Tween] = [null]
	var animate := func(target_scale: float, duration: float) -> void:
		if press_tween[0] and press_tween[0].is_valid():
			press_tween[0].kill()
		if Preferences.values.reduced_motion:
			button.scale = Vector2.ONE
			return
		press_tween[0] = button.create_tween()
		press_tween[0].tween_property(button, "scale", Vector2.ONE * target_scale, duration) \
			.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	button.button_down.connect(animate.bind(0.92, 0.075))
	button.button_up.connect(animate.bind(1.0, 0.12))
	button.pressed.connect(func() -> void: _carousel.advance(direction))
	add_child(button)
	return button


func _layout_arrows() -> void:
	var distance := minf(422.0, size.x * 0.39)
	var center := Vector2(size.x * 0.5, size.y - 249)
	_previous.position = center - Vector2(distance, 0.0) - _previous.size * 0.5
	_next.position = center + Vector2(distance, 0.0) - _next.size * 0.5


func _open_option(index: int) -> void:
	if _changing_scene or is_instance_valid(_panel):
		return
	if index == 0:
		_open_scene(PROLOGUE)
		return
	if index == Carousel.PLAY_INDEX:
		if Campaign.quick_start() == OK:
			Campaign.return_to_map = false
			_open_scene(Campaign.ATLAS)
		else:
			_open_scene(PROLOGUE, true)
		return
	_panel = MenuPanel.new()
	_panel.name = "Painel"
	_panel.closed.connect(_close_panel)
	add_child(_panel)
	_panel.open(index)
	if not Preferences.values.reduced_motion:
		_panel.modulate.a = 0.0
		_panel_animation = create_tween()
		_panel_animation.tween_property(_panel, "modulate:a", 1.0, 0.22) \
			.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _refresh_appearance() -> void:
	$PonteDoSino.modulate = Preferences.art_tint()
	$Titulo.add_theme_constant_override("outline_size", 8 if Preferences.values.high_contrast else 5)
	_guide.add_theme_font_size_override("font_size", Preferences.text_size(23))
	_guide.text = ("Arraste para girar" if Preferences.values.swipe_enabled else "Gire pelas setas") \
		+ "  •  Toque no selo central"
	_carousel.queue_redraw()
	if _continue != null:
		_continue.add_theme_font_size_override("font_size", Preferences.text_size(22))


func _continue_campaign() -> void:
	if _changing_scene or is_instance_valid(_panel):
		return
	Preferences.feedback()
	_open_scene(PROLOGUE, true)


func _open_scene(path: String, continue_saved := false) -> void:
	_changing_scene = true
	_carousel.cancel_gesture()
	_carousel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_previous.disabled = true
	_next.disabled = true
	if _continue != null:
		_continue.disabled = true
	if not Preferences.values.reduced_motion:
		var curtain := ColorRect.new()
		curtain.color = Color("#060a11")
		curtain.modulate.a = 0.0
		add_child(curtain)
		curtain.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var fade := create_tween()
		fade.tween_property(curtain, "modulate:a", 1.0, 0.21)
		await fade.finished
		curtain.queue_free()
	Campaign.show_saved_on_entry = continue_saved
	var error := get_tree().change_scene_to_file(path)
	if error != OK:
		Campaign.show_saved_on_entry = false
		_changing_scene = false
		_carousel.mouse_filter = Control.MOUSE_FILTER_STOP
		_previous.disabled = false
		_next.disabled = false
		if _continue != null:
			_continue.disabled = false
		push_error("Falha ao abrir %s: %s" % [path, error_string(error)])


func _close_panel() -> void:
	if not is_instance_valid(_panel) or _closing_panel:
		return
	_closing_panel = true
	var focus_owner := get_viewport().gui_get_focus_owner()
	if focus_owner and _panel.is_ancestor_of(focus_owner):
		focus_owner.release_focus()
	_panel.process_mode = Node.PROCESS_MODE_DISABLED
	if _panel_animation and _panel_animation.is_valid():
		_panel_animation.kill()
	if not Preferences.values.reduced_motion:
		_panel_animation = create_tween()
		_panel_animation.tween_property(_panel, "modulate:a", 0.0, 0.17)
		await _panel_animation.finished
	_panel.queue_free()
	_closing_panel = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("menu_back", false):
		_back()
		get_viewport().set_input_as_handled()
		return
	if _changing_scene or is_instance_valid(_panel):
		return
	if event.is_action_pressed("menu_previous", false):
		_carousel.advance(-1)
	elif event.is_action_pressed("menu_next", false):
		_carousel.advance(1)
	elif event.is_action_pressed("menu_confirm", false):
		_carousel.activate()
	else:
		return
	get_viewport().set_input_as_handled()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_node_ready():
		_back()


func _back() -> void:
	if _changing_scene:
		return
	if is_instance_valid(_panel):
		_close_panel()
	else:
		_carousel.cancel_gesture()
		_open_option(3)
