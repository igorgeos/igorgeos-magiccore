extends ColorRect

signal closed

const Ink := preload("res://ui/ink_style.gd")
const SettingsView := preload("res://scenes/menu/settings_view.gd")

var _body: VBoxContainer
var _footer: HBoxContainer
var _focus: Button


func open(index: int) -> void:
	color = Color(0.016, 0.027, 0.043, 0.78)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	if index == 1:
		var settings := SettingsView.new()
		settings.closed.connect(closed.emit)
		add_child(settings)
		return
	var card := PanelContainer.new()
	var frame := Ink.panel(Ink.INK, Color("#7c746a"), 12)
	frame.content_margin_left = 30
	frame.content_margin_right = 30
	frame.content_margin_top = 24
	frame.content_margin_bottom = 24
	frame.shadow_size = 14
	frame.shadow_color = Color(0, 0, 0, 0.5)
	card.add_theme_stylebox_override("panel", frame)
	add_child(card)
	card.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	var half_size := Vector2(421, 276) if index == 2 else Vector2(337, 177)
	card.offset_left = -half_size.x
	card.offset_right = half_size.x
	card.offset_top = -half_size.y
	card.offset_bottom = half_size.y
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 15)
	card.add_child(column)
	var heading := Ink.label("Créditos" if index == 2 else "Sair do MAGIC CORE?", 36, Ink.TEXT)
	heading.add_theme_font_override("font", Ink.SERIF)
	column.add_child(heading)
	var separator := HSeparator.new()
	column.add_child(separator)
	var scroller := ScrollContainer.new()
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroller.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroller.follow_focus = true
	column.add_child(scroller)
	_body = VBoxContainer.new()
	_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 12)
	scroller.add_child(_body)
	_footer = HBoxContainer.new()
	_footer.alignment = BoxContainer.ALIGNMENT_END
	_footer.add_theme_constant_override("separation", 12)
	column.add_child(_footer)
	match index:
		2:
			_credit("Equipe", "Igor Geos · Criação e desenvolvimento\nJason (IA) · Direção criativa")
			_credit("Arte e interface", "Roberto (ChatGPT) · Direção artística, ilustrações e interface\nCenários do prólogo, da ponte e do santuário\nArte do personagem andarilho")
			_credit("Música e efeitos", "Roberto (ChatGPT) · Síntese da trilha e dos efeitos\nVale Noturno · Trilha ambiente\nGiro do Selo e Selo · Sons de navegação e confirmação")
			_body.add_child(Ink.label("MAGIC CORE · Versão " + str(
				ProjectSettings.get_setting("application/config/version")), 19, Ink.MUTED))
			_focus = _action("Voltar", closed.emit)
		3:
			_body.add_child(Ink.label("O aplicativo será fechado.", 23, Ink.MUTED))
			_focus = _action("Cancelar", closed.emit)
			_action("Sair", _quit, true)
	_focus.grab_focus()


func _quit() -> void:
	Preferences.stop_audio()
	# Deixa o mixer descartar a trilha antes de encerrar.
	await get_tree().create_timer(0.08).timeout
	get_tree().quit()


func _credit(section: String, description: String) -> void:
	var group := VBoxContainer.new()
	group.add_theme_constant_override("separation", 5)
	_body.add_child(group)
	group.add_child(Ink.label(section, 19, Ink.BLUE))
	var copy := Ink.label(description, 21, Ink.TEXT)
	copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	copy.add_theme_constant_override("line_spacing", 4)
	group.add_child(copy)


func _action(caption: String, callback: Callable, primary := false) -> Button:
	var button := Ink.button(caption, primary)
	button.pressed.connect(callback)
	_footer.add_child(button)
	return button
