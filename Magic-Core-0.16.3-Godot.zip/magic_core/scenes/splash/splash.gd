extends Control

const MENU := "res://scenes/menu/main_menu.tscn"
const Ink := preload("res://ui/ink_style.gd")
const MIN_PRESENTATION := 1.25
const MIN_REDUCED := 0.32
const TRACK_LENGTH := 338.0
const METAL := Color("#8b7c66")
const GLOW := Color("#a0c5e1")
const SHADOW := Color(0.01, 0.018, 0.029, 0.90)

var _elapsed := 0.0
var _progress := 0.0
var _visible_progress := 0.0
var _menu: PackedScene
var _retry: Button

@onready var _face: Control = $Composicao
@onready var _curtain: ColorRect = $Cortina

func _ready() -> void:
	$Santuario.modulate = Preferences.art_tint()
	_face.draw.connect(_draw_opening)
	_face.resized.connect(_layout_opening)
	_retry = Ink.button("Tentar novamente", true)
	_retry.custom_minimum_size.x = 250.0
	add_child(_retry)
	_retry.pressed.connect(_request_menu)
	_layout_opening()
	if not Preferences.values.reduced_motion:
		_curtain.color.a = 1.0
		create_tween().tween_property(_curtain, "color:a", 0.0, 0.22)
	_request_menu()


func _request_menu() -> void:
	_retry.hide()
	_progress = 0.0
	_visible_progress = 0.0
	_elapsed = 0.0
	_menu = null
	_face.queue_redraw()
	if ResourceLoader.load_threaded_request(MENU, "PackedScene") != OK:
		_load_failed()
		return
	set_process(true)


func _process(delta: float) -> void:
	_elapsed += delta
	if _menu == null:
		var reported: Array = []
		match ResourceLoader.load_threaded_get_status(MENU, reported):
			ResourceLoader.THREAD_LOAD_LOADED:
				_menu = ResourceLoader.load_threaded_get(MENU) as PackedScene
				if _menu == null:
					_load_failed()
					return
				_progress = 1.0
			ResourceLoader.THREAD_LOAD_FAILED:
				ResourceLoader.load_threaded_get(MENU)
				_load_failed()
				return
			ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				_load_failed()
				return
			_:
				if not reported.is_empty():
					_progress = clampf(float(reported[0]), _progress, 0.99)
	var reduced: bool = Preferences.values.reduced_motion
	var shown := _progress if reduced else move_toward(_visible_progress, _progress, delta * 2.9)
	if shown != _visible_progress:
		_visible_progress = shown
		_face.queue_redraw()
	var minimum := MIN_REDUCED if reduced else MIN_PRESENTATION
	if _menu != null and _elapsed >= minimum and _visible_progress >= 1.0:
		set_process(false)
		if reduced:
			_open_menu()
		else:
			var fade := create_tween()
			fade.tween_property(_curtain, "color:a", 1.0, 0.18)
			fade.tween_callback(_open_menu)


func _open_menu() -> void:
	if get_tree().change_scene_to_packed(_menu) != OK:
		_curtain.color.a = 0.0
		_load_failed()


func _load_failed() -> void:
	set_process(false)
	_retry.show()
	_retry.grab_focus()
	_face.queue_redraw()


func _origin() -> Vector2:
	var extent := _face.size
	return Vector2(88.0 + maxf(extent.x - 1280.0, 0.0) * 0.26, extent.y * 0.5 - 146.0)


func _layout_opening() -> void:
	if is_instance_valid(_retry):
		_retry.position = _origin() + Vector2(0, 267)
	_face.queue_redraw()


func _draw_opening() -> void:
	var start := _origin()
	var mark := start + Vector2(8, 0)
	_diamond(mark, Vector2(6, 11), GLOW)
	_face.draw_line(mark + Vector2(18, 0), mark + Vector2(133, 0), METAL, 1.0, true)
	_diamond(mark + Vector2(138, 0), Vector2(2.5, 2.5), METAL)
	_draw_text(Ink.SERIF, "MAGIC", start + Vector2(0, 87), 84, Ink.TEXT)
	_draw_text(Ink.SERIF, "CORE", start + Vector2(-1, 172), 100, Ink.TEXT)
	var body_font := ThemeDB.fallback_font
	if _retry.visible:
		_draw_text(body_font, "Falha ao abrir o menu", start + Vector2(0, 235), 22, Color("#efb698"))
		return
	_draw_text(body_font, "Despertando o Núcleo", start + Vector2(0, 229), 24, GLOW)
	var percent := "%d%%" % floori(_visible_progress * 100.0)
	var width := body_font.get_string_size(percent, HORIZONTAL_ALIGNMENT_LEFT, -1, 19).x
	_draw_text(body_font, percent, start + Vector2(TRACK_LENGTH - width, 229), 19, Ink.MUTED)
	var rail := start + Vector2(0, 253)
	var end := rail + Vector2(TRACK_LENGTH, 0)
	var marker := rail.lerp(end, _visible_progress)
	_face.draw_line(rail, end, METAL.darkened(0.27), 2.0, true)
	_face.draw_line(rail, marker, GLOW, 2.0, true)
	_diamond(rail, Vector2(3.5, 3.5), METAL)
	_diamond(end, Vector2(3.5, 3.5), METAL)
	_diamond(marker, Vector2(5, 7), GLOW)


func _diamond(at: Vector2, radius: Vector2, tone: Color) -> void:
	var points := PackedVector2Array([at + Vector2(0, -radius.y), at + Vector2(radius.x, 0),
		at + Vector2(0, radius.y), at + Vector2(-radius.x, 0)])
	_face.draw_colored_polygon(points, tone)


func _draw_text(font: Font, value: String, origin: Vector2, pixels: int, tone: Color) -> void:
	_face.draw_string_outline(font, origin + Vector2(1, 2), value, HORIZONTAL_ALIGNMENT_LEFT, -1,
		pixels, 5, SHADOW)
	_face.draw_string(font, origin, value, HORIZONTAL_ALIGNMENT_LEFT, -1, pixels, tone)
