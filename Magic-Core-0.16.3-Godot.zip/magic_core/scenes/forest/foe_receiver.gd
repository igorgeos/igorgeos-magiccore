extends "res://systems/combat/impact_receiver.gd"

func receive_strike(hit: Impact) -> bool:
	if not get_parent().vulnerable() or not super(hit):
		return false
	get_parent().struck(hit)
	if health == 0:
		collision_layer = 0
		set_physics_process(false)
	return true
