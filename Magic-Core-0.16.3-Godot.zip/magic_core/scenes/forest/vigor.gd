extends RefCounted

signal changed(current: int, capacity: int)

var capacity: int
var current: int
var invulnerability := 0.0


func _init(maximum: int) -> void:
	capacity = maxi(1, maximum)
	current = capacity


func advance(delta: float) -> void:
	invulnerability = maxf(0.0, invulnerability - delta)


func damage(amount: int, fall := false) -> bool:
	if amount <= 0 or current <= 0 or (invulnerability > 0.0 and not fall):
		return false
	current = maxi(0, current - amount)
	invulnerability = 0.75 if current > 0 else 0.0
	changed.emit(current, capacity)
	return true


func heal(amount: int) -> bool:
	if amount <= 0 or current == capacity or current <= 0:
		return false
	current = mini(capacity, current + amount)
	changed.emit(current, capacity)
	return true
