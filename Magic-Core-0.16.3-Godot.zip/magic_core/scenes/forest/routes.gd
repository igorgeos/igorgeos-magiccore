extends RefCounted

const Objectives := preload("res://scenes/forest/objectives.gd")
const Event := Objectives.Event
const FLOOR := 540
const IDS := ["mata1", "mata2", "mata3", "mata4", "mata5"]

# Floors are continuous ridges or separated banks. Each pair is x and surface y.
# Individual decks are x, width, surface y, and their painted material.
const STAGES := [
	{
		"width": 2330,
		"floors": [[[0,540],[283,540],[478,493],[622,493],[766,540],[1300,540],
			[1500,513],[1695,513],[1910,540],[2330,540]]],
		"decks": [[668,121,439,"log"], [785,132,402,"log"], [906,130,433,"shelf"], [1330,116,462,"log"]],
		"foes": [["batedor",570,0], ["vigia",1530,0]],
		"sites": [[962,433,"cache","Colher ervas do vigia","fern",100],
			[1190,540,"rest","Usar o braseiro","hearth",130],
			[2190,540,"exit","Ler o marco","marker",115]],
		"props": [[321,537,"fern",72], [124,543,"trail",173], [1890,552,"arch",205],
			[2278,540,"fern",87]],
		"tasks": [[Event.REACH, "exit", "Alcance o marco de pedra."]],
	},
	{
		"width": 2460,
		"floors": [[[0,540],[681,540]], [[757,540],[1285,540]], [[1414,540],[1780,540],[1960,504],[2102,504],[2240,540],[2460,540]]],
		"decks": [[420,180,480,"log"], [550,126,429,"log"], [665,165,397,"bridge"],
			[1045,153,468,"bridge"], [1194,115,413,"shelf"], [1290,182,385,"bridge"],
			[1573,169,460,"log"], [1737,192,428,"bridge"]],
		"foes": [["bruma",940,0], ["desfiladeiro",1870,1]],
		"sites": [[1810,428,"trail","Ler fitas da trilha","trail",113],
			[1114,468,"bridge","Soltar a ponte de serviço","wheel",72],
			[2310,540,"exit","Seguir pela passagem","marker",117]],
		"props": [[268,544,"trail",142], [599,539,"fern",83], [1604,545,"trail",111],
			[2287,547,"arch",210]],
		"tasks": [[Event.REACH, "exit", "Encontre a passagem segura pela névoa."]],
	},
	{
		"width": 2380,
		"floors": [[[0,540],[388,540],[611,570],[996,570],[1152,540],[1805,540],
			[1945,524],[2040,540],[2380,540]]],
		"decks": [[392,183,481,"log"], [548,210,429,"shelf"], [798,233,401,"log"],
			[1030,169,453,"shelf"], [1410,152,481,"log"], [1535,232,428,"shelf"], [1744,135,461,"log"]],
		"foes": [["clareira",1180,0], ["altar",1850,1]],
		"sites": [[934,401,"secret","Ler a inscrição oculta","marker",62],
			[1630,428,"echo","Escutar o altar","altar",58],
			[2160,540,"seal","Recolher o selo","marker",127]],
		"props": [[976,406,"fern",96], [707,573,"arch",189], [1320,544,"fern",110],
			[2138,541,"altar",42], [2214,541,"fern",80]],
		"tasks": [[Event.INTERACT,"echo","Visite o altar pela passagem alta."],
			[Event.COLLECT,"seal","Siga as inscrições e recolha o selo."]],
	},
	{
		"width": 2530,
		"floors": [[[0,540],[835,540]], [[921,540],[1270,540],[1440,501],[1732,501],
			[1910,540],[2530,540]]],
		"decks": [[395,149,485,"shelf"], [536,167,435,"shelf"], [708,222,387,"shelf"],
			[1083,153,482,"shelf"], [1423,152,445,"shelf"], [1551,226,396,"shelf"]],
		"foes": [["coluna",310,0], ["fortaleza",1010,1], ["ferrolho",1830,0]],
		"sites": [[805,387,"winch","Girar o contrapeso","wheel",90],
			[1690,396,"bolt","Soltar o ferrolho","wheel",77],
			[2370,540,"exit","Entrar no santuário","marker",111]],
		"props": [[274,544,"arch",255], [1190,549,"arch",174], [625,438,"arch",138],
			[1645,502,"arch",188], [2010,542,"arch",289], [2395,545,"trail",135]],
		"tasks": [[Event.INTERACT,"winch","Acione o contrapeso na primeira torre."],
			[Event.INTERACT,"bolt","Solte o ferrolho na segunda torre."],
			[Event.REACH,"exit","Atravesse a passagem do santuário."]],
	},
	{
		"width": 1880,
		"floors": [[[0,540],[434,540],[615,512],[1690,512],[1880,512]]],
		"decks": [],
		"foes": [["guardiao",1200,2]],
		"sites": [[305,540,"rest","Usar o braseiro","hearth",138]],
		"props": [[519,533,"arch",302], [1020,514,"altar",67], [1384,517,"bell",236],
			[1696,515,"arch",312], [1794,515,"fern",130]],
		"tasks": [[Event.DEFEAT,"guardiao","Derrote o Guardião do Véu."]],
	},
]
