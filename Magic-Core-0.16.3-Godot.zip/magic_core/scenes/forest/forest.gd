extends "res://scenes/world/test_world.gd"

const Ink := preload("res://ui/ink_style.gd")
const HudArt := preload("res://ui/hud_art.gd")
const TouchButton := preload("res://ui/touch_button.gd")
const Enemy := preload("res://scenes/forest/foe.gd")
const Vigor := preload("res://scenes/forest/vigor.gd")
const Scenery := preload("res://scenes/forest/scenery.gd")
const Routes := preload("res://scenes/forest/routes.gd")
const Objectives := preload("res://scenes/forest/objectives.gd")
const Event := Objectives.Event
const GROUND := Routes.FLOOR
const BRIDGE := Rect2(1266, 540, 168, 18)

@export_range(30, 200, 1) var maximum_health := 100
var life: Vigor
var hp: int:
	get: return life.current
var health_motion: Tween
var hurt_motion: Tween
var index := 0
var ended := false
var won := false
var used := {}
var sites: Array[Dictionary] = []
var ledges: Array[Rect2] = []
var ridges: Array[PackedVector2Array] = []
var gate: AnimatableBody2D
var _gate_bars: Sprite2D
var _folded_bridge: Sprite2D
var objective: Label
var interact: Button
var hp_bar: ProgressBar
var boss_bar: ProgressBar
var boss_title: Label
var health_text: Label
var nearby := -1
var camera: Camera2D
var scenery: Scenery
var foes: Array[Enemy] = []
var message_time := 0.0
var last_safe := Vector2(100, GROUND)
var progress: Objectives
var defeated := {}
var world_width := 0.0
var _safe_timer := 0.0
var _mission_name: Label
var _mission_plate: Panel
var _air: AudioStreamPlayer


func _ready() -> void:
	index = Routes.IDS.find(Campaign.stage)
	if index < 0 or Campaign.chapter != "mata" or not Campaign.enter_stage(Campaign.stage):
		set_process(false)
		set_physics_process(false)
		get_tree().call_deferred("change_scene_to_file", Campaign.ATLAS)
		return
	var route: Dictionary = Routes.STAGES[index]
	world_width = route.width
	progress = Objectives.new(route.tasks)
	life = Vigor.new(maximum_health)
	life.changed.connect(refresh_hp)
	_build_ui()
	_target.queue_free()
	_floor.disabled = true
	_left_wall.position = Vector2(-10, 350)
	_right_wall.position = Vector2(world_width + 10, 350)
	_player.collision_layer = 2
	_player.position = last_safe
	_player.reset_physics_interpolation()
	_player.reset_attack_sweep()
	camera = Camera2D.new()
	camera.process_callback = Camera2D.CAMERA2D_PROCESS_PHYSICS
	camera.limit_left = 0
	camera.limit_right = int(world_width)
	add_child(camera)
	camera.position = Vector2(_player.position.x, 360)
	scenery = Scenery.new()
	add_child(scenery)
	scenery.setup(index, world_width, _player, camera)
	_layout_view()
	get_viewport().size_changed.connect(_layout_view)
	for ridge in route.floors:
		_build_ridge(ridge)
	for deck in route.decks:
		var area := Rect2(deck[0], deck[2], deck[1], 18)
		_add_deck(area, deck[3])
	for spec in route.props:
		scenery.decoration(spec)
	for spec in route.sites:
		site(Vector2(spec[0], spec[1]), spec[2], spec[3], spec[4], spec[5])
	if index == 1:
		_folded_bridge = scenery.deck("bridge", BRIDGE)
		_folded_bridge.position += Vector2(11.0, 0.0)
		_folded_bridge.rotation = -1.14
	if index == 3:
		_build_gate()
	for spec in route.foes:
		_spawn_foe(spec)
	_player.z_index = 2
	build_mission_hud()
	if index == 0 and not Campaign.completed.has("mata1"):
		say("Para lutar, saque a Espada do Vigia em Armas.", 5.0)
	_ambience()
	Preferences.changed.connect(_apply_preferences)
	_apply_preferences()


func _exit_tree() -> void:
	if is_instance_valid(_air):
		_air.stop()
	super()


func _draw() -> void:
	pass


func _layout_view() -> void:
	_extent = get_viewport_rect().size
	camera.zoom = Vector2.ONE * (_extent.y / 720.0)
	scenery.size_for_view(_extent.x / camera.zoom.x)
	align_camera()
	if is_instance_valid(hp_bar):
		_layout_hud.call_deferred()


func align_camera() -> void:
	var half := minf(world_width * 0.5, _extent.x / camera.zoom.x * 0.5)
	camera.position.x = clampf(_player.position.x, half, world_width - half)
	scenery.position_background()


func _build_ridge(profile: Array) -> void:
	var top := PackedVector2Array()
	for point in profile:
		top.append(Vector2(point[0], point[1]))
	var body := StaticBody2D.new()
	var shape := CollisionPolygon2D.new()
	var polygon := top.duplicate()
	polygon.append(Vector2(top[-1].x, GROUND + 330))
	polygon.append(Vector2(top[0].x, GROUND + 330))
	shape.polygon = polygon
	body.add_child(shape)
	add_child(body)
	ridges.append(top)
	scenery.floor_ridge(top)


func _block(body: PhysicsBody2D, size: Vector2, one_way := false) -> void:
	var collision := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = size
	collision.shape = box
	collision.one_way_collision = one_way
	collision.one_way_collision_margin = 10.0
	body.add_child(collision)


func _add_deck(area: Rect2, material: String, paint := true) -> void:
	var body := StaticBody2D.new()
	body.position = area.get_center()
	_block(body, area.size, true)
	add_child(body)
	if paint:
		scenery.deck(material, area)
	ledges.append(area)


func surface_at(x: float) -> float:
	for ridge in ridges:
		if x < ridge[0].x or x > ridge[-1].x:
			continue
		for i in range(1, ridge.size()):
			if x <= ridge[i].x:
				return lerpf(ridge[i-1].y, ridge[i].y, inverse_lerp(ridge[i-1].x, ridge[i].x, x))
	return INF


func _build_gate() -> void:
	gate = AnimatableBody2D.new()
	gate.name = "Comporta"
	gate.position = Vector2(2010, GROUND - 122)
	_block(gate, Vector2(33, 244))
	add_child(gate)
	_gate_bars = scenery.prop("gate", Vector2(2010, GROUND), 212)
	var size := _gate_bars.texture.get_size()
	# Only the bars and crossbar move. The carved sides remain in the arch.
	_gate_bars.region_enabled = true
	_gate_bars.region_rect = Rect2(size.x * 0.21, size.y * 0.08, size.x * 0.58, size.y * 0.92)
	_gate_bars.offset = Vector2(-size.x * 0.29, -size.y * 0.92)
	_gate_bars.z_index = -1


func _raise_gate() -> void:
	var lift := create_tween()
	lift.set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	lift.tween_method(_gate_travel, 0.0, 1.0, 0.82).set_trans(Tween.TRANS_SINE)
	lift.tween_callback(_release_gate)


func _gate_travel(fraction: float) -> void:
	gate.position.y = GROUND - 122.0 - fraction * 268.0
	var size := _gate_bars.texture.get_size()
	var top := size.y * lerpf(0.08, 1.0, fraction)
	_gate_bars.region_rect.position.y = top
	_gate_bars.region_rect.size.y = maxf(0.1, size.y - top)


func _release_gate() -> void:
	_gate_bars.queue_free()
	gate.queue_free()


func _lower_bridge() -> void:
	var drop := create_tween()
	drop.tween_property(_folded_bridge, "rotation", 0.0, 0.72).set_trans(Tween.TRANS_CUBIC)
	drop.parallel().tween_property(_folded_bridge, "position:x", BRIDGE.position.x, 0.72)
	drop.tween_callback(func(): _add_deck(BRIDGE, "bridge", false))


func _spawn_foe(spec: Array) -> void:
	var foe := Enemy.new()
	foe.name = spec[0]
	foe.kind = spec[2]
	foe.hero = _player
	foe.position = Vector2(spec[1], surface_at(spec[1]) - 0.1)
	foe.sight_multiplier = scenery.visibility_at(foe.position)
	foe.contact.connect(hurt)
	foe.fallen.connect(enemy_fallen)
	if foe.kind == 2:
		foe.territory = Vector2(691.0, 1730.0)
		foe.vitality.connect(_boss_health)
	add_child(foe)
	foes.append(foe)


func site(point: Vector2, key: String, title: String, art := "marker", height := 95.0) -> void:
	var prop := scenery.prop(art, point, height)
	sites.append({"point": point, "key": key, "title": title, "prop": prop})
	if key == "secret":
		prop.modulate = Color("#9f9e82")
	elif key == "seal":
		prop.modulate = Color("#72867e")


func _ambience() -> void:
	var stream := load("res://audio/vento_da_mata.wav") as AudioStreamWAV
	if stream == null:
		return
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_end = roundi(stream.get_length() * stream.mix_rate)
	_air = AudioStreamPlayer.new()
	_air.stream = stream
	add_child(_air)
	_air.play()


func _apply_preferences() -> void:
	if is_instance_valid(_air):
		_air.volume_linear = Preferences.values.effects * 0.004
	scenery.background.modulate = Preferences.art_tint(0.94)
	_layout_hud()


func bar(color: Color) -> ProgressBar:
	var result := ProgressBar.new()
	result.show_percentage = false
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rim := Ink.panel(Color("#282220"), Color("#a49577"), 4)
	var fill := Ink.panel(color, color.lightened(0.24), 3)
	for style in [rim, fill]:
		for edge in [SIDE_TOP, SIDE_BOTTOM, SIDE_LEFT, SIDE_RIGHT]:
			style.set_content_margin(edge, 2.0)
	result.add_theme_stylebox_override("background", rim)
	result.add_theme_stylebox_override("fill", fill)
	return result


func build_mission_hud() -> void:
	hp_bar = bar(Color("#843d3b"))
	_hud.add_child(hp_bar)
	hp_bar.max_value = life.capacity
	hp_bar.value = life.current
	health_text = Ink.label("Vida   %d / %d" % [life.current, life.capacity], 17, Ink.TEXT)
	health_text.add_theme_color_override("font_shadow_color", Color("#131815"))
	health_text.add_theme_constant_override("shadow_offset_y", 2)
	_hud.add_child(health_text)

	_mission_plate = Panel.new()
	_mission_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mission_plate.clip_contents = true
	_mission_plate.add_theme_stylebox_override("panel", Ink.panel(Color("#161d1cef"), Color("#796c50"), 5))
	_hud.add_child(_mission_plate)
	_mission_name = Ink.label(Campaign.stage_data(Campaign.stage).name, 15, Color("#dbc496"))
	_mission_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_mission_plate.add_child(_mission_name)
	objective = Ink.label(progress.description(), 20, Ink.TEXT)
	objective.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective.max_lines_visible = 2
	objective.clip_text = true
	objective.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	objective.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_mission_plate.add_child(objective)

	interact = Ink.button("Interagir", true, TouchButton.new())
	interact.name = "Interagir"
	interact.focus_mode = Control.FOCUS_NONE
	_hud.add_child(interact)
	interact.pressed.connect(activate)
	interact.hide()
	if index == 4:
		boss_title = Ink.label("Guardião do Véu", 18, Ink.TEXT)
		boss_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_hud.add_child(boss_title)
		boss_bar = bar(Color("#805956"))
		boss_bar.max_value = foes[0].receiver.max_health
		boss_bar.value = boss_bar.max_value
		_hud.add_child(boss_bar)


func _layout_hud() -> void:
	var safe := HudArt.safe_rect(_controls)
	var unit: float = _controls._unit
	var health_home := safe.position + Vector2(25, 106) * unit
	health_text.position = health_home
	health_text.add_theme_font_size_override("font_size", Preferences.text_size(17))
	hp_bar.position = health_home + Vector2(0, 26)
	hp_bar.size = Vector2(200 * minf(unit, 1.34), 12.0)
	var margin_left := 365.0 * unit + 12.0
	var margin_right := 171.0 * unit + 12.0
	var width := minf(550.0, safe.size.x - margin_left - margin_right)
	var centered := safe.get_center().x - width * 0.5
	var left := clampf(centered, safe.position.x + margin_left, safe.end.x - margin_right - width)
	_mission_plate.position = Vector2(left, safe.position.y + 13.0)
	var height := maxf(69.0, 24.0 + Preferences.text_size(19) * 2.55)
	_mission_plate.size = Vector2(width, height)
	_mission_name.position = Vector2(8, 4)
	_mission_name.size = Vector2(width - 16.0, 22.0)
	objective.position = Vector2(10.0, 24.0)
	objective.add_theme_font_size_override("font_size", Preferences.text_size(19))
	var text_area := Vector2(width - 20.0, height - 26.0)
	objective.size = text_area
	# The line minimum is recalculated after the width and font change.
	objective.set_deferred("size", text_area)
	interact.size = Vector2(minf(safe.size.x * 0.30, 354.0), 59.0)
	interact.position = Vector2(safe.get_center().x - interact.size.x * 0.5, safe.end.y - 124.0)
	if index == 4:
		boss_title.position = _mission_plate.position + Vector2(0, height + 4.0)
		boss_title.size.x = width
		boss_bar.position = _mission_plate.position + Vector2(width * 0.10, height + 30.0)
		boss_bar.size = Vector2(width * 0.8, 11.0)


func _boss_health(value: int) -> void:
	boss_bar.value = value
	if value <= 9 and not foes.is_empty() and not foes[0].angry:
		boss_title.text = "Guardião do Véu · Fúria ancestral"
		say("A fúria encadeia a onda no chão com uma investida.", 4.0)


func enemy_fallen(enemy: Enemy) -> void:
	var id := String(enemy.name)
	defeated[id] = true
	foes.erase(enemy)
	if not ended and progress.record(Event.DEFEAT, id):
		victory()


func hurt(damage: int, push: float, fall := false) -> void:
	if ended or not life.damage(damage, fall):
		return
	var severity := clampf(float(damage) / 28.0, 0.2, 1.0)
	_player.react_to_damage(push, severity)
	var figure := _player.get_node("Visual") as Node2D
	if hurt_motion and hurt_motion.is_valid():
		hurt_motion.kill()
	hurt_motion = create_tween()
	figure.modulate = Color("#efb2a6")
	hurt_motion.tween_property(figure, "modulate", Color.WHITE, 0.28)
	if life.current == 0:
		finish(false)


func refresh_hp(current: int, capacity: int) -> void:
	health_text.text = "Vida   %d / %d" % [current, capacity]
	if health_motion and health_motion.is_valid():
		health_motion.kill()
	health_motion = create_tween()
	health_motion.tween_property(hp_bar, "value", float(current), 0.22).set_ease(Tween.EASE_OUT)


func say(caption: String, seconds := 3.6) -> void:
	objective.text = caption
	message_time = seconds


func activate() -> void:
	if ended or _wheel.visible or nearby < 0 or used.has(sites[nearby].key):
		return
	var item: Dictionary = sites[nearby]
	if not _within_reach(item.point):
		return
	var key: String = item.key
	match key:
		"rest", "cache":
			if key == "cache" and not defeated.has("batedor"):
				say("O batedor guarda as ervas. Derrote-o para colhê-las.")
				return
			if not life.heal(35 if key == "rest" else 24):
				say("Sua vida está completa.")
				return
			say("Você recuperou forças.")
		"trail":
			say("As fitas marcam as tábuas firmes. Abaixo, a névoa encobre a vala.", 5.3)
		"bridge":
			_lower_bridge()
			say("A ponte de serviço desce sobre a vala.")
		"secret":
			scenery.mark_echo(PackedVector2Array([item.point, item.point + Vector2(70, 0)]))
			say("Na pedra: «Tire o peso do ferrolho. Só então erga a grade.»", 6.1)
			life.heal(16)
		"echo":
			if not progress.record(Event.INTERACT, key):
				return
			scenery.mark_echo(PackedVector2Array([item.point, Vector2(1780, 461),
				Vector2(1940, 524), Vector2(2090, 540), Vector2(2160, 540)]))
			_reveal_seal()
			say("«A raiz esconde o selo. As torres ainda guardam o caminho.»", 5.6)
		"seal":
			if not progress.complete() and not progress.record(Event.COLLECT, key):
				say("O selo está selado. Busque o altar na passagem alta.")
				return
			victory()
			return
		"winch":
			if not progress.record(Event.INTERACT, key):
				return
			say("Contrapeso erguido. Siga para a segunda torre.")
		"bolt":
			if not progress.record(Event.INTERACT, key):
				say("O peso prende o ferrolho. Acione o contrapeso na primeira torre.")
				return
			_raise_gate()
			say("O ferrolho se soltou. A comporta está subindo.")
		"exit", "save":
			if progress.complete() or progress.record(Event.REACH, key):
				victory()
			else:
				say(progress.description())
			return
	used[key] = true
	var prop := item.prop as Sprite2D
	prop.modulate = Color("#a5a18b")
	Preferences.navigation_feedback()


func _reveal_seal() -> void:
	for item in sites:
		if item.key == "seal":
			var tween := create_tween()
			tween.tween_property(item.prop, "modulate", Color("#cbdbc2"), 0.42)
			return


func victory() -> void:
	if ended or not progress.complete():
		return
	if Campaign.finish_stage() != OK:
		say("Falha ao salvar. Tente registrar a vitória novamente.", 7.0)
		if index == 4 and not sites.any(func(item): return item.key == "save"):
			site(_player.position, "save", "Registrar vitória")
		return
	Preferences.feedback(true)
	finish(true)


func finish(success: bool) -> void:
	ended = true
	won = success
	_player.controls_locked = true
	_player.set_physics_process(false)
	for foe in foes:
		foe.suspend(true)
	_controls.hide()
	_wheel.hide()
	interact.hide()
	if not success:
		var body := _player.get_node("Visual") as Node2D
		var fall := create_tween()
		fall.set_parallel(true)
		fall.tween_property(body, "rotation", -1.36, 0.53).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
		fall.tween_property(body, "position:x", -13.0, 0.48).set_ease(Tween.EASE_OUT)
		await fall.finished
	if not is_inside_tree():
		return
	_show_result(success)


func _show_result(success: bool) -> void:
	var veil := ColorRect.new()
	veil.color = Color("#101815dc")
	_hud.add_child(veil)
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	veil.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 17)
	center.add_child(column)
	var heading := "O Andarilho tombou"
	var detail := "A fase recomeça com a vida restaurada."
	if success:
		heading = "Floresta Sombria concluída" if index == 4 else "Travessia concluída"
		detail = "Mapa das Terras Congeladas liberado." if index == 4 else Campaign.stage_data(Campaign.stage).name
	var title := Ink.label(heading, 36, Ink.TEXT)
	title.add_theme_font_override("font", Ink.SERIF)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(title)
	var body := Ink.label(detail, 21, Color("#c9b992"))
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(body)
	if not success:
		var retry := Ink.button("Reiniciar fase", true, TouchButton.new())
		column.add_child(retry)
		retry.pressed.connect(func(): get_tree().reload_current_scene())
	var back := Ink.button("Voltar ao mapa", success, TouchButton.new())
	column.add_child(back)
	back.pressed.connect(_go_back)
	if not Preferences.values.reduced_motion:
		veil.modulate.a = 0.0
		create_tween().tween_property(veil, "modulate:a", 1.0, 0.23)


func _open_arsenal() -> void:
	super()
	for foe in foes:
		foe.suspend(true)
	_player.set_physics_process(false)


func _close_arsenal() -> void:
	super()
	_player.set_physics_process(true)
	for foe in foes:
		foe.suspend(false)


func _go_back() -> void:
	if _leaving:
		return
	_leaving = true
	Campaign.return_to_map = true
	get_tree().change_scene_to_file(Campaign.ATLAS)


func _unhandled_input(event: InputEvent) -> void:
	if ended:
		if event.is_action_pressed("menu_back"):
			_go_back()
		return
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_E:
		activate()
	else:
		super(event)


func _within_reach(point: Vector2) -> bool:
	var offset: Vector2 = (_player.position - point).abs()
	return offset.x <= 76.0 and offset.y <= 64.0


func _physics_process(dt: float) -> void:
	if ended or not is_instance_valid(objective):
		return
	super(dt)
	if _wheel.visible:
		interact.hide()
		return
	life.advance(dt)
	if message_time > 0.0:
		message_time -= dt
		if message_time <= 0.0:
			objective.text = progress.description()
	_update_safe_ground(dt)
	if _player.position.y > GROUND + 170.0:
		_player.position = last_safe - Vector2(0, 7)
		_player.velocity = Vector2.ZERO
		_player.reset_physics_interpolation()
		_player.reset_attack_sweep()
		hurt(20, 0.0, true)
		if ended:
			return
	_pick_nearby_site()
	align_camera()
	scenery.advance(dt)


func _update_safe_ground(dt: float) -> void:
	_safe_timer -= dt
	if _safe_timer > 0.0:
		return
	_safe_timer = 0.10
	if index == 1:
		for foe in foes:
			foe.sight_multiplier = scenery.visibility_at(foe.position)
	if not _player.is_on_floor():
		return
	var feet: Vector2 = _player.position
	var ground := surface_at(feet.x)
	if absf(ground - feet.y) < 4.0 and is_finite(surface_at(feet.x - 43)) and is_finite(surface_at(feet.x + 43)):
		last_safe = feet
		return
	for ledge in ledges:
		if absf(ledge.position.y - feet.y) < 4.0 and feet.x > ledge.position.x + 32.0 and feet.x < ledge.end.x - 32.0:
			last_safe = feet
			return


func _pick_nearby_site() -> void:
	nearby = -1
	var best := INF
	for i in sites.size():
		var item := sites[i]
		if used.has(item.key) or not _within_reach(item.point):
			continue
		var distance: float = _player.position.distance_squared_to(item.point)
		if distance < best:
			nearby = i
			best = distance
	interact.visible = nearby >= 0
	if interact.visible:
		interact.text = sites[nearby].title
