extends Node2D

const INK := Color("#23332d")
var hero: CharacterBody2D
var camera: Camera2D
var width := 0.0
var fog_stage := false
var background: Sprite2D
var mist: Texture2D
var soil: Texture2D
var curtains: Node2D
var clock := 0.0
var _texture_cache := {}
var _foliage: Array[Sprite2D] = []
var _tick := 0.0
var _echo_until := -1.0
var _echo_points := PackedVector2Array()


func setup(stage_index: int, span: float, player: CharacterBody2D, view: Camera2D) -> void:
	width = span
	hero = player
	camera = view
	fog_stage = stage_index == 1
	soil = load("res://assets/forest/land5.webp")
	mist = load("res://assets/forest/cerracao.webp")
	background = Sprite2D.new()
	background.texture = load("res://assets/forest/land%d.webp" % stage_index)
	background.z_index = -9
	add_child(background)
	curtains = Node2D.new()
	curtains.z_index = -2
	add_child(curtains)
	var border := prop("trail", Vector2(10, 530), 270, curtains)
	border.modulate = Color(0.61, 0.67, 0.63, 0.9)
	var far_edge := prop("trail", Vector2(width - 5, 543), 240, curtains)
	far_edge.flip_h = true
	far_edge.modulate = border.modulate
	_foliage.append(border)
	_foliage.append(far_edge)


func size_for_view(view_width: float) -> void:
	var tex := background.texture.get_size()
	var scale_factor := maxf((view_width + 345.0) / tex.x, 756.0 / tex.y)
	background.scale = Vector2.ONE * scale_factor
	position_background()


func position_background() -> void:
	background.position = Vector2(camera.position.x - (camera.position.x - width * 0.5) * 0.115, 354.0)


func _fetch(name: String) -> Texture2D:
	if not _texture_cache.has(name):
		_texture_cache[name] = load("res://assets/forest/props/%s.webp" % name)
	return _texture_cache[name]


func prop(name: String, foot: Vector2, height: float, parent: Node2D = null) -> Sprite2D:
	var sprite := Sprite2D.new()
	sprite.texture = _fetch(name)
	sprite.centered = false
	sprite.offset = Vector2(-sprite.texture.get_width() * 0.5, -sprite.texture.get_height())
	sprite.position = foot
	sprite.scale = Vector2.ONE * height / sprite.texture.get_height()
	var holder := parent if parent else self
	holder.add_child(sprite)
	return sprite


func decoration(spec: Array) -> void:
	var leaf := prop(spec[2], Vector2(spec[0], spec[1]), spec[3], curtains)
	if spec[2] in ["fern", "trail"]:
		_foliage.append(leaf)


func floor_ridge(ridge: PackedVector2Array) -> void:
	var top := ridge
	# Keep the texture fixed in world coordinates across slope changes.
	var colors := PackedColorArray()
	var outline := PackedVector2Array()
	var surface_count := top.size()
	for i in surface_count:
		outline.append(top[i])
		colors.append(Color("#a8a693"))
	for i in range(surface_count - 1, -1, -1):
		outline.append(top[i] + Vector2(0, 252))
		colors.append(Color("#353b32"))
	var shape := Polygon2D.new()
	shape.polygon = outline
	shape.vertex_colors = colors
	shape.texture = soil
	shape.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	var tex_coords := PackedVector2Array()
	for vertex in outline:
		tex_coords.append(vertex * Vector2(0.54, 0.50))
	shape.uv = tex_coords
	shape.z_index = -1
	add_child(shape)
	var rim := Line2D.new()
	rim.points = top
	rim.width = 2.4
	rim.default_color = Color("#8d9075")
	rim.antialiased = true
	add_child(rim)


func deck(material: String, rect: Rect2) -> Sprite2D:
	var sprite := Sprite2D.new()
	var tex := _fetch(material)
	sprite.texture = tex
	sprite.centered = false
	var size := tex.get_size()
	var width_scale := rect.size.x / size.x
	var height_scale := width_scale if material != "bridge" else minf(0.62, width_scale)
	sprite.offset.y = -size.y * (0.47 if material == "bridge" else 0.29)
	sprite.position = rect.position
	sprite.scale = Vector2(width_scale, height_scale)
	add_child(sprite)
	return sprite


func mark_echo(points: PackedVector2Array) -> void:
	_echo_points = points
	_echo_until = clock + 8.0
	queue_redraw()


func visibility_at(point: Vector2) -> float:
	if not fog_stage:
		return 1.0
	var density := 0.50 + 0.30 * sin(point.x * 0.005 - clock * 0.42)
	var up := smoothstep(448.0, 544.0, point.y)
	return 1.0 - density * up * 0.50


func advance(dt: float) -> void:
	clock += dt
	_tick -= dt
	if _tick > 0.0:
		return
	_tick = 1.0 / 22.0
	var quality: int = Preferences.values.visual_quality
	var animate: bool = not Preferences.values.reduced_motion
	if animate and quality > 0:
		for leaf in _foliage:
			var proximity := 1.0 - smoothstep(0.0, 98.0, absf(hero.position.x - leaf.position.x))
			leaf.rotation = sin(clock * 1.26 + leaf.position.x * 0.02) * 0.023 + signf(hero.velocity.x) * proximity * 0.055
	queue_redraw()


func _draw() -> void:
	if not is_instance_valid(camera):
		return
	var quality: int = Preferences.values.visual_quality
	var animate: bool = not Preferences.values.reduced_motion
	var horizon := camera.position.x
	if fog_stage or quality > 0:
		var bands := (8 if quality > 0 else 4) if fog_stage else 3
		for i in bands:
			var drift := clock * (10.0 + i % 4 * 3.0) if animate else 0.0
			var x := fposmod(i * 337.0 + drift, width)
			if absf(x - horizon) > 1100.0:
				continue
			var y := 274.0 + i % 3 * 57.0
			var density := 0.72 if fog_stage else 0.28
			draw_texture_rect(mist, Rect2(x - 310.0, y, 630.0, 107.0), false,
				Color(0.80, 0.93, 0.88, density))
	if quality == 2 and animate:
		for i in 12:
			var x := fposmod(i * 219.0 + clock * (9 + i % 4), width)
			if absf(x - horizon) > 850.0:
				continue
			var p := Vector2(x, 193 + fposmod(i * 61.0 + clock * 13.5, 305))
			var tip := p + Vector2(3.3 * cos(i + clock * 2.1), 2.1)
			draw_line(p, tip, Color("#b5aa728f"), 1.4, true)
	if clock < _echo_until:
		var fade := smoothstep(0.0, 1.0, _echo_until - clock)
		var tint := Color(0.62, 0.82, 0.76, fade * 0.85)
		if not _echo_points.is_empty():
			var start := _echo_points[0]
			draw_arc(start - Vector2(0, 27), 24, PI, TAU, 18, tint, 1.8, true)
		for p in _echo_points:
			draw_line(p + Vector2(-8, -12), p + Vector2(0, -24), tint, 2.1, true)
			draw_line(p + Vector2(0, -24), p + Vector2(8, -12), tint, 2.1, true)
