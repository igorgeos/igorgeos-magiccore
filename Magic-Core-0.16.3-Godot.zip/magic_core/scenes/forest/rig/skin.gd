extends Skeleton2D

@export var bind_points: PackedVector2Array
const START := [0,1,2,3,1,5,6,7,1,9,10,11,0,13,14,15,0,17,18,19,1,21,4]
const END := [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
const PARENT := [-1,0,1,2,0,4,5,6,0,8,9,10,-1,12,13,14,-1,16,17,18,0,20,3]
var joints: Array[Bone2D] = []
var lengths := PackedFloat32Array()
var frames: Array[Transform2D] = []

func _ready() -> void:
	joints.resize(START.size())
	lengths.resize(START.size())
	frames.resize(START.size())
	for node in find_children("*","Bone2D",true,false):
		joints[node.get_meta("indice")] = node
	for i in START.size():
		lengths[i] = bind_points[END[i]].distance_to(bind_points[START[i]])

func deform(pose: PackedVector2Array) -> void:
	for i in START.size():
		var origin := pose[START[i]]
		var vector := pose[END[i]]-origin
		var axis := vector.normalized()
		var size_factor := clampf(vector.length()/lengths[i],0.58,1.6)
		var target := Transform2D(axis*size_factor,Vector2(-axis.y,axis.x),origin)
		frames[i] = target
		var parent: int = PARENT[i]
		joints[i].transform = target if parent<0 else frames[parent].affine_inverse()*target
