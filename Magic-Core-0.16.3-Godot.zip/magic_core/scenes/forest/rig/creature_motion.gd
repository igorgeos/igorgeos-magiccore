extends Node2D

const CreatureSkin := preload("res://scenes/forest/rig/skin.gd")
enum Mode { PATROL, OBSERVE, ALERT, PURSUE, WINDUP, STRIKE, RECOVER, HURT, DEAD }
var animal
var skin: CreatureSkin
var rest: PackedVector2Array
var pose: PackedVector2Array
var previous: PackedVector2Array
var mode := -1
var transition := 0.0
var phase := 0.0
var stride := 0.0
var locomotion := 0.0
var clock := 0.0
var wind := 0.0
var blow := 0.0
var follow := 0.0
var collapse := 0.0
var attention := 0.0
var yaw := 1.0
var recoil := Vector2.ZERO
var recoil_speed := Vector2.ZERO
var previous_lean := 0.0
var cloth := 0.0
var cloth_speed := 0.0
var h := 0.0

func setup(body) -> void:
	animal = body
	h = body.height
	skin = load("res://scenes/forest/rig/skin%d_0.tscn"%body.kind).instantiate()
	add_child(skin)
	rest = skin.bind_points
	pose = rest.duplicate()
	previous = rest.duplicate()
	stride = [49.0,69.0,88.0][body.kind]
	yaw = -body.side
	tick(0.0,0.0)

func impact(direction: Vector2, force: float) -> void:
	recoil_speed += Vector2(direction.x*-animal.side,direction.y)*minf(force,1.8)*115

func tick(dt: float, travel: float) -> void:
	if mode!=animal.state:
		mode = animal.state
		transition = 0
		for i in pose.size(): previous[i] = pose[i]
	transition += dt
	clock = fmod(clock+dt,1000)
	phase = fposmod(phase+travel*animal.side/stride,1.0)
	var moving: bool = mode in [Mode.PATROL,Mode.PURSUE,Mode.RECOVER] or (mode==Mode.STRIKE and animal.attack==2)
	var amount := minf(absf(travel)/maxf(dt,0.001)/35,1) if moving else 0.0
	locomotion = move_toward(locomotion,amount,6.7*dt)
	var duration := maxf(animal.age+animal.time,0.001)
	var t := clampf(animal.age/duration,0,1)
	wind = 0
	blow = 0
	follow = 0
	if mode==Mode.WINDUP:
		wind = smoothstep(0,0.71,t)*(1-smoothstep(0.74,1,t))
		blow = smoothstep(0.76,1,t)
	elif mode==Mode.STRIKE:
		blow = 1
		follow = smoothstep(0,0.79,t)
	elif mode==Mode.RECOVER:
		blow = 1-smoothstep(0.04,0.84,t)
		follow = 1-smoothstep(0.02,0.66,t)
	collapse = smoothstep(0.02,0.81,t) if mode==Mode.DEAD else 0
	attention = move_toward(attention,1.0 if mode in [Mode.OBSERVE,Mode.ALERT,Mode.PURSUE] else 0.0,dt*5)
	recoil_speed += (-115*recoil-17*recoil_speed)*dt
	recoil += recoil_speed*dt
	for i in pose.size(): pose[i] = rest[i]
	match animal.kind:
		0: errante()
		1: sentinela()
		2: guardiao()
	var lean := pose[1].x-rest[1].x
	cloth_speed += (lean-previous_lean)*0.75-(58*cloth+14*cloth_speed)*dt
	previous_lean = lean
	cloth += cloth_speed*dt
	pose[22] += Vector2(-cloth*3.5,absf(cloth)*0.6)
	pose[23] += Vector2(-cloth*1.9,0)
	var blend := smoothstep(0,0.10,transition)
	if blend<1 and dt>0:
		for i in pose.size(): pose[i] = previous[i].lerp(pose[i],blend)
	yaw = move_toward(yaw,-animal.side,dt*17)
	scale.x = yaw if absf(yaw)>0.02 else 0.02*signf(-animal.side)
	position = animal.receiver.offset
	modulate = Color.WHITE.lerp(Color("#e9b498"),minf(animal.receiver.flash*2.3,0.36))
	if mode==Mode.DEAD: modulate.a = 1-smoothstep(0.70,1,t)
	skin.deform(pose)

func torso(displacement: Vector2, tilt: float, head_angle: float) -> void:
	var pivot := rest[0]
	displacement += Vector2(-collapse*h*0.05,collapse*h*0.38)
	tilt -= collapse*0.65
	for i in pose.size():
		if i in [14,15,16,18,19,20]: continue
		pose[i] = pivot+(rest[i]-pivot).rotated(tilt)+displacement
		pose[i] += recoil*clampf((pivot.y-rest[i].y)/h+0.25,0.1,1)
	for i in [3,4,23]:
		pose[i] = pose[2]+(pose[i]-pose[2]).rotated(head_angle)

func errante() -> void:
	var beat := phase*TAU
	var limp := maxf(0.0,sin(beat))*locomotion
	torso(Vector2(4*wind-13*blow+3*limp,3.6*limp+sin(clock*2.5)-3*wind+4*blow),
		0.10*wind-0.16*blow+0.045*limp,-0.11*attention+0.05*sin(clock*2))
	foot(13,phase,0.65,7,0.94)
	foot(17,fposmod(phase+0.48,1),0.49,13,1)
	var sway := sin(beat)*locomotion
	# Shoulder draws back, elbow leads, hook rolls through after the wrist.
	arm(5, -0.18*sway-0.77*wind+0.75*blow,0.16*sway-0.66*wind+0.68*blow,
		-0.10*sway-0.92*wind+0.36*blow+0.66*follow)
	arm(9,0.29*sway+0.18*wind-0.30*blow,0.15*sway+0.47*wind-0.19*blow,0.14*sway)

func sentinela() -> void:
	var beat := phase*TAU
	var loading := absf(sin(beat))*locomotion
	torso(Vector2(-5*loading+8*wind-16*blow,2.8*loading+sin(clock*1.35)-8*wind+7*blow),
		-0.05*loading+0.13*wind-0.14*blow,0.09*wind-0.09*attention)
	foot(13,fposmod(phase+0.22,1),0.64,11,1)
	foot(17,fposmod(phase+0.72,1),0.61,9,1)
	# The long root first supports the chest, then peels off the ground into a rake.
	var left := step_offset(phase,0.60,15)*locomotion
	var right := step_offset(fposmod(phase+0.51,1),0.64,11)*locomotion
	var hook := Vector2(16*wind-37*blow,-40*wind-16*blow+17*follow)
	hand_target(5,rest[7]+left+hook,0.35*wind+0.73*blow-0.40*follow)
	hand_target(9,rest[11]+right+Vector2(-4*wind-2*blow,-3*wind),-0.10*wind)

func guardiao() -> void:
	var beat := phase*TAU
	var weight := maxf(0,sin(beat*2))*locomotion
	var pulse := float(animal.attack==1)
	var charge := float(animal.attack==2)
	var drive := 1.0-pulse-charge
	torso(Vector2(-4*weight+6*wind-(10+12*charge)*blow,
		3*weight+sin(clock*1.04)*0.8+wind*(8-17*pulse)+blow*(4+33*pulse+8*charge)),
		0.12*wind-(0.21+0.18*charge+0.11*pulse)*blow,0.07*wind-0.08*attention)
	foot(13,phase,0.66,19,1)
	foot(17,fposmod(phase+0.5,1),0.66,16,1)
	var counter := sin(beat)*locomotion
	arm(5,0.12*counter-0.58*wind+0.72*blow*drive+1.85*wind*pulse-0.2*charge*wind,
		-0.65*wind+0.67*blow*drive+2.05*wind*pulse-0.68*blow*pulse+0.48*blow*charge,
		-0.50*wind+0.64*blow*drive+1.8*wind*pulse-0.57*blow*pulse+0.3*blow*charge+follow*0.13)
	arm(9,-0.18*counter+0.25*wind+1.1*pulse*wind+0.7*charge*blow,
		-0.14*counter+1.35*pulse*wind+0.61*charge*blow,
		0.95*pulse*wind+0.52*charge*blow)
	if pulse > 0.0 and blow > 0.0:
		var bracing := smoothstep(0.56, 1.0, blow)
		hand_target(5, pose[7].lerp(Vector2(-71, -23), bracing), -0.54)
		hand_target(9, pose[11].lerp(Vector2(16, -25), bracing), 0.16)


func arm(shoulder: int, upper: float, lower: float, hand: float) -> void:
	var elbow := shoulder+1
	var wrist := shoulder+2
	var tip := shoulder+3
	pose[elbow] = pose[shoulder]+(rest[elbow]-rest[shoulder]).rotated(upper+collapse*0.30)
	pose[wrist] = pose[elbow]+(rest[wrist]-rest[elbow]).rotated(lower-collapse*0.21)
	pose[tip] = pose[wrist]+(rest[tip]-rest[wrist]).rotated(hand-collapse*0.42)

func hand_target(base: int,target: Vector2, rotation_offset: float) -> void:
	chain(base,base+1,base+2,target+Vector2(-collapse*8,0))
	pose[base+3] = pose[base+2]+(rest[base+3]-rest[base+2]).rotated(rotation_offset)

func foot(hip: int,t: float,stance: float,lift: float,stride_scale: float) -> void:
	var step := step_offset(t,stance,lift)*locomotion
	step.x *= stride_scale
	var target := rest[hip+2]+step
	chain(hip,hip+1,hip+2,target)
	pose[hip+3] = pose[hip+2]+(rest[hip+3]-rest[hip+2]).rotated(-step.y*0.017)
	pose[hip+3].y = minf(pose[hip+3].y,0)

func step_offset(t: float,stance: float,lift: float) -> Vector2:
	if t<stance: return Vector2((t-stance*0.5)*stride,0)
	var u := (t-stance)/(1-stance)
	return Vector2((0.5-smoothstep(0,1,u))*stance*stride,-sin(PI*u)*lift)

func chain(base: int,joint: int,end: int,target: Vector2) -> void:
	var a := rest[joint].distance_to(rest[base])
	var b := rest[end].distance_to(rest[joint])
	var aim := target-pose[base]
	var dir := aim.normalized()
	var d := clampf(aim.length(),absf(a-b)+0.01,a+b-0.01)
	var along := (d*d+a*a-b*b)/(2*d)
	var bend := signf((rest[end]-rest[base]).cross(rest[joint]-rest[base]))
	pose[joint] = pose[base]+dir*along+Vector2(-dir.y,dir.x)*bend*sqrt(maxf(0,a*a-along*along))
	pose[end] = pose[base]+dir*d
