extends RefCounted
## The scene sends events after real interactions. Only the last required event grants victory.

enum Event { REACH, DEFEAT, INTERACT, COLLECT }

var steps: Array
var cursor := 0


func _init(sequence: Array) -> void:
	steps = sequence


func description() -> String:
	return "" if complete() else steps[cursor][2]


func accepts(event: Event, target: String) -> bool:
	return not complete() and steps[cursor][0] == event and steps[cursor][1] == target


func record(event: Event, target: String) -> bool:
	if not accepts(event, target):
		return false
	cursor += 1
	return true


func complete() -> bool:
	return cursor == steps.size()
