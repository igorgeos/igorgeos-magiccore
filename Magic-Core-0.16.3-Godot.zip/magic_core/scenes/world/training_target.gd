extends "res://systems/combat/impact_receiver.gd"

const WOOD := Color("#59483b")
const BRUISE := Color("#aea392")
const RING := Color("#96806a")
const METAL := Color("#695d56")


func _draw() -> void:
	var reduced: bool = Preferences.values.reduced_motion
	var collapse := 0.0
	if health <= 0:
		collapse = smoothstep(0.055, 0.32, respawn_delay - respawn)
		if collapse >= 1.0:
			draw_line(Vector2(-31, -4), Vector2(32, -4), Color("#413932"), 7, true)
			draw_circle(Vector2(26, -6), 9, WOOD, true, -1.0, true)
			return
	var relief := 0.48 if reduced else 1.0
	var fall_side := -1.0 if _kick.x < 0.0 else 1.0
	draw_set_transform(Vector2.ZERO, lean * relief + collapse * 1.23 * fall_side,
		Vector2(1.0 + compression * 0.16 * relief, 1.0 - compression * relief - collapse * 0.18))
	var contact_light := flash / 0.132 * (0.23 if reduced else 0.57)
	var wood := WOOD.lerp(BRUISE, contact_light)
	draw_line(Vector2(0, -8), Vector2(0, -112), wood, 11, true)
	draw_circle(Vector2(0, -94), 26, wood, true, -1.0, true)
	draw_arc(Vector2(0, -94), 18, 0, TAU, 40, RING, 4, true)
	draw_circle(Vector2(0, -94), 6, METAL, true, -1.0, true)
	draw_set_transform(Vector2.ZERO)
	draw_line(Vector2(-23, -8), Vector2(23, -8), Color("#413932"), 7, true)
	if health > 0:
		for i in range(max_health):
			var x := (i - (max_health - 1) * 0.5) * 16.0
			draw_circle(Vector2(x, -126), 4, Color("#8b9e9d") if i < health else Color("#302e2b"),
				true, -1.0, true)
