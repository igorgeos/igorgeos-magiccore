extends Node2D

const FieldHUD := preload("res://ui/field_hud.gd")
const WeaponWheel := preload("res://ui/weapon_wheel.gd")
const MENU := "res://scenes/menu/main_menu.tscn"

const TOP := Color("#414a55")
const BOTTOM := Color("#151d26")
const FLOOR_LINE := Color("#857e6e")
const EDGE := 38.0

var _extent := Vector2.ZERO
var _floor_y := 0.0
var _controls: FieldHUD
var _wheel: Control
var _arsenal_waiting := false
var _leaving := false
var _previous_interpolation := false

@onready var _player: CharacterBody2D = $Personagem
@onready var _floor: CollisionShape2D = get_node_or_null("Limites/Piso")
@onready var _left_wall: CollisionShape2D = $Limites/Esquerda
@onready var _right_wall: CollisionShape2D = $Limites/Direita
@onready var _hud: CanvasLayer = $Interface
@onready var _target: Area2D = get_node_or_null("Alvo")


func _enter_tree() -> void:
	_previous_interpolation = get_tree().physics_interpolation
	get_tree().physics_interpolation = true


func _exit_tree() -> void:
	get_tree().physics_interpolation = _previous_interpolation


func _ready() -> void:
	_build_ui()
	_layout_room()
	get_viewport().size_changed.connect(_layout_room)


func _build_ui() -> void:
	_controls = FieldHUD.new()
	_controls.name = "Comandos"
	_hud.add_child(_controls)
	_controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_controls.chosen.connect(_control_pressed)
	_controls.direction_changed.connect(func(axis: float) -> void: _player.touch_axis = axis)
	_wheel = WeaponWheel.new()
	_wheel.name = "Arsenal"
	_hud.add_child(_wheel)
	_wheel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_wheel.selected.connect(_choose_weapon)
	_wheel.dismissed.connect(_close_arsenal)


func _control_pressed(action: StringName) -> void:
	match action:
		&"run":
			_player.run_latched = not _player.run_latched
			Preferences.navigation_feedback()
		&"jump": _player.request_jump()
		&"attack": _press_attack()
		&"arsenal": _toggle_arsenal()
		&"back": _go_back()


func _toggle_arsenal() -> void:
	if _wheel.visible:
		_close_arsenal()
	elif _arsenal_waiting:
		_arsenal_waiting = false
		_player.block_attack_input(false)
	elif _player.current_strike() != null:
		_arsenal_waiting = true
		_player.block_attack_input(true)
	else:
		_open_arsenal()


func _open_arsenal() -> void:
	_player.controls_locked = true
	_arsenal_waiting = false
	_player.block_attack_input(false)
	_controls.hide()
	_player.touch_axis = 0.0
	_wheel.open(_player.weapon_selected)


func _close_arsenal() -> void:
	_wheel.hide()
	_player.controls_locked = false
	_controls.show()


func _choose_weapon(armed: bool) -> void:
	_player.select_weapon(armed)
	_close_arsenal()


func _press_attack() -> void:
	if _player.can_attack():
		_player.request_attack()
	elif not _player.weapon_selected and not _wheel.visible:
		_toggle_arsenal()


func _layout_room() -> void:
	var first_layout := _extent == Vector2.ZERO
	var previous_floor := _floor_y
	_extent = get_viewport_rect().size
	_floor_y = _extent.y * 0.73
	_target.set_anchor(Vector2(_extent.x * 0.68, _floor_y))
	(_floor.shape as RectangleShape2D).size = Vector2(_extent.x + 100.0, 76.0)
	_floor.position = Vector2(_extent.x * 0.5, _floor_y + 38.0)
	_left_wall.position = Vector2(EDGE - 12.0, _extent.y * 0.5)
	_right_wall.position = Vector2(_extent.x - EDGE + 12.0, _extent.y * 0.5)
	if first_layout:
		_player.position = Vector2(_extent.x * 0.5, _floor_y - 0.1)
	else:
		_player.position.x = clampf(_player.position.x, EDGE + 20.0, _extent.x - EDGE - 20.0)
		_player.position.y += _floor_y - previous_floor
	_player.reset_physics_interpolation()
	_player.reset_attack_sweep()
	queue_redraw()


func _physics_process(_delta: float) -> void:
	if _arsenal_waiting and _player.current_strike() == null:
		_open_arsenal()


func _process(_delta: float) -> void:
	var progress: float = _player.weapon_progress
	var status: String
	if _player.weapon_selected:
		status = "Espada do Vigia" if progress >= 1.0 else "Sacando espada"
	else:
		status = "Espada na bainha" if progress <= 0.0 else "Guardando espada"
	var pace := clampf(absf(_player.get_real_velocity().x) / maxf(_player.run_speed, 1.0), 0.0, 1.0)
	_controls.set_status(status, progress, _player.run_latched or Input.is_action_pressed("player_run"),
		pace, _player.strike_progress(), _player.strike_link_open())


func _draw() -> void:
	if _extent == Vector2.ZERO:
		return
	draw_rect(Rect2(Vector2.ZERO, _extent), TOP)
	draw_rect(Rect2(0, _floor_y, _extent.x, _extent.y - _floor_y), BOTTOM)
	draw_line(Vector2(0.0, _floor_y), Vector2(_extent.x, _floor_y), FLOOR_LINE, 2.0)


func _go_back() -> void:
	if _leaving:
		return
	_leaving = true
	Preferences.feedback()
	var error := get_tree().change_scene_to_file(MENU)
	if error != OK:
		_leaving = false
		push_error("Falha ao voltar ao menu: %s" % error_string(error))


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("player_arsenal", false):
		get_viewport().set_input_as_handled()
		_toggle_arsenal()
	elif event.is_action_pressed("menu_back", false):
		get_viewport().set_input_as_handled()
		_back_or_close()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_node_ready():
		_back_or_close()


func _back_or_close() -> void:
	if _wheel.visible or _arsenal_waiting:
		_toggle_arsenal()
	else:
		_go_back()
