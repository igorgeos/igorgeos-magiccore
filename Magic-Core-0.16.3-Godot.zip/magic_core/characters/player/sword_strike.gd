extends Resource
## One attack profile for the Espada do Vigia. All timing fractions use 0 to 1.

@export_range(0.10, 1.50, 0.01) var duration := 0.46
@export_range(0.0, 1.0, 0.01) var active_start := 0.31
@export_range(0.0, 1.0, 0.01) var active_end := 0.68
@export_range(0.0, 1.0, 0.01) var chain_open := 0.60
@export_range(0.0, 1.0, 0.01) var chain_close := 0.98
@export_range(0.0, 1.0, 0.01) var ground_speed_scale := 0.24

@export_group("Pose")
## Time, wrist offset from the front shoulder (x, y), blade angle in degrees.
@export var wrist_keys := PackedVector4Array()
## Each envelope contains the beginning, plateau start, plateau end and release.
@export var coil_timing := Vector4(0.0, 0.23, 0.24, 0.49)
@export var drive_timing := Vector4(0.26, 0.50, 0.59, 1.0)
@export var lift_timing := Vector4(0.43, 0.66, 0.70, 1.0)
@export var step_timing := Vector4(0.13, 0.38, 0.73, 1.0)
@export var load_depth := 8.0
@export var lift_scale := 1.0
@export var step_reach := 20.0
@export var shoulder_turn := 0.0
@export_range(0.0, 0.8, 0.01) var blade_foreshortening := 0.42

@export_group("Impacto")
@export_range(1, 8, 1) var damage := 1
@export_range(0.0, 2.0, 0.01) var impact_force := 0.99
@export var impact_axis := Vector2(0.46, -1.0)
@export_range(0.0, 0.06, 0.001) var impact_pause := 0.033
@export_range(0.0, 0.3, 0.01) var impact_compression := 0.045
@export_range(0.05, 0.6, 0.01) var impact_recovery := 0.27


func weights(t: float) -> Vector4:
	return Vector4(_envelope(t, coil_timing), _envelope(t, drive_timing),
		_envelope(t, lift_timing) * lift_scale, _envelope(t, step_timing))


func wrist(t: float) -> Vector3:
	for i in range(1, wrist_keys.size()):
		var b := wrist_keys[i]
		if t > b.x:
			continue
		var a := wrist_keys[i - 1]
		var previous := wrist_keys[maxi(0, i - 2)]
		var next := wrist_keys[mini(wrist_keys.size() - 1, i + 1)]
		var span := b.x - a.x
		var u := (t - a.x) / span
		var start := Vector3(a.y, a.z, a.w)
		var end := Vector3(b.y, b.z, b.w)
		var enter := (end - Vector3(previous.y, previous.z, previous.w)) * span / (b.x - previous.x)
		var leave := (Vector3(next.y, next.z, next.w) - start) * span / (next.x - a.x)
		# Bound each tangent to the local segment. A plateau in wrist height
		# stays level even when the adjacent key begins the recovery.
		var change := end - start
		for axis in 3:
			var limit := absf(change[axis]) * 2.0
			enter[axis] = signf(change[axis]) * clampf(enter[axis] * signf(change[axis]), 0.0, limit)
			leave[axis] = signf(change[axis]) * clampf(leave[axis] * signf(change[axis]), 0.0, limit)
		return start.bezier_interpolate(start + enter / 3.0, end - leave / 3.0, end, u)
	return Vector3(12, 19, -49)


func _envelope(t: float, timing: Vector4) -> float:
	return smoothstep(timing.x, timing.y, t) * (1.0 - smoothstep(timing.z, timing.w, t))
