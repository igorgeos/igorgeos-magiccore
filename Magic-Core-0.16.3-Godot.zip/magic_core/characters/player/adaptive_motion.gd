extends RefCounted
# Physical events drive these weights. Each transition leaves input and collision free to advance.

enum Phase { GROUND, IMPULSE, ASCENT, APEX, DESCENT, LANDING }

const TURN_TIME := 0.19
const LAND_TIME := 0.26

var phase := Phase.GROUND
var air_weight := 0.0
var air_pose := Vector3.ZERO # Forward reach, knee tuck, landing extension.
var momentum := 0.0
var readiness := 0.0
var landing := 0.0
var turn := 0.0
var turn_progress := 1.0
var brace := 0.0
var turned := false
var hard_turn := false

var _grounded := true
var _flight_time := 0.0
var _turn_time := TURN_TIME
var _land_time := LAND_TIME
var _land_strength := 0.0
var _turn_strength := 0.0
var _facing := 1.0
var _velocity := Vector2.ZERO


func advance(delta: float, velocity: Vector2, grounded: bool, facing: float,
		intent: float, walk_speed: float) -> void:
	turned = facing != _facing
	hard_turn = turned and grounded and absf(_velocity.x) >= walk_speed * 0.68
	if turned:
		momentum *= -0.45
		_turn_time = 0.0
		_turn_strength = clampf(absf(_velocity.x) / maxf(walk_speed, 1.0), 0.24, 1.0)
	_turn_time += delta
	turn_progress = clampf(_turn_time / TURN_TIME, 0.0, 1.0)
	turn = _turn_strength * (1.0 - smoothstep(0.08, 1.0, turn_progress))

	if grounded:
		if not _grounded:
			_land_time = 0.0
			_land_strength = smoothstep(95.0, 610.0, _velocity.y)
		_land_time += delta
		var time := clampf(_land_time / LAND_TIME, 0.0, 1.0)
		landing = _land_strength * smoothstep(0.0, 0.19, time) * (1.0 - smoothstep(0.25, 1.0, time))
		phase = Phase.LANDING if time < 1.0 else Phase.GROUND
	else:
		_advance_air(delta, velocity)
	air_weight = lerpf(air_weight, float(not grounded), 1.0 - exp(-delta * (37.0 if grounded else 29.0)))
	var acceleration := (velocity.x - _velocity.x) * facing / maxf(delta * 2400.0, 1.0)
	momentum = lerpf(momentum, clampf(acceleration, -1.0, 1.0), 1.0 - exp(-delta * 12.0))
	var starting := absf(intent) * (1.0 - smoothstep(16.0, 105.0, absf(velocity.x)))
	readiness = lerpf(readiness, starting if grounded else 0.0, 1.0 - exp(-delta * 25.0))
	var grab := maxf(turn * smoothstep(0.36, 0.75, _turn_strength), landing * 0.75) if grounded else 0.0
	brace = lerpf(brace, grab, 1.0 - exp(-delta * (26.0 if grab > brace else 11.0)))
	_velocity = velocity
	_grounded = grounded
	_facing = facing


func _advance_air(delta: float, velocity: Vector2) -> void:
	if _grounded:
		_flight_time = 0.0
	_flight_time += delta
	landing = 0.0
	if velocity.y < -100.0:
		phase = Phase.IMPULSE if _flight_time < 0.09 else Phase.ASCENT
	elif velocity.y > 105.0:
		phase = Phase.DESCENT
	else:
		phase = Phase.APEX
	var lift := smoothstep(0.025, 0.17, _flight_time)
	var reach := smoothstep(55.0, 265.0, absf(velocity.x))
	var descend := smoothstep(115.0, 560.0, velocity.y)
	# Extend the launch leg first. Tuck through the apex, then open the stance on descent.
	air_pose = Vector3(reach * (0.45 + 0.55 * lift), lift * (1.0 - descend), descend)
