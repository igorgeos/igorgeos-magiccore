extends Node2D

const Motion := preload("res://characters/player/motion.gd")
const Strike := preload("res://characters/player/sword_strike.gd")
const Trace := preload("res://characters/player/strike_trace.gd")
const Art := preload("res://characters/player/figure_atlas.gd")
const STEEL := preload("res://characters/player/espada_vigia.res")
const SHEATH := preload("res://characters/player/bainha_vigia.res")
const FAR := Color(0.72, 0.72, 0.76)
const LEATHER := Color(0.84, 0.81, 0.79)
const CLOAK_ROWS := 6
const CLOAK_TINT := Color(0.88, 0.89, 0.93)

var pose := Motion.new()
var _trace := Trace.new()
var _weapon := 0.0
var _facing := 1.0
var _cloth_quad := PackedVector2Array([Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO])
var _cloth_uv: Array[PackedVector2Array] = []
var _cloth_colors := PackedColorArray([CLOAK_TINT])

@onready var _waist: Marker2D = $Cintura
@onready var _mouth: Marker2D = $Cintura/BocaBainha
@onready var _grip: Marker2D = $Empunhadura


func _ready() -> void:
	pose.advance(0, 0, Vector2.ZERO, true, 1, 112, 140, 0, -1)
	_sync_anchors()
	var source: Rect2 = Art.REGIONS[Art.Part.CLOAK]
	var tex_size: Vector2 = Art.TEXTURE.get_size()
	var width := Vector2(source.size.x / tex_size.x, 0.0)
	for row in range(CLOAK_ROWS):
		var uv0 := (source.position + Vector2(0.0, source.size.y * row / CLOAK_ROWS)) / tex_size
		var uv1 := (source.position + Vector2(0.0, source.size.y * (row + 1) / CLOAK_ROWS)) / tex_size
		_cloth_uv.append(PackedVector2Array([uv0, uv0 + width, uv1 + width, uv1]))


func advance(delta: float, travel: float, velocity: Vector2, grounded: bool, facing: float,
		gait_length: float, walk_speed: float, weapon: float, attack: float, running: float,
		intent: float, profile: Strike, approach: float, balance: float) -> void:
	var turned := facing != _facing
	_facing = facing
	_weapon = weapon
	if turned:
		transform = Transform2D(Vector2(_facing, 0.0), Vector2.DOWN, Vector2.ZERO)
		reset_physics_interpolation()
	pose.advance(delta, travel, velocity, grounded, facing, gait_length, walk_speed, weapon,
		attack, running, intent, profile, approach, balance)
	_sync_anchors()
	_trace.advance(delta)
	queue_redraw()


func _sync_anchors() -> void:
	_waist.position = pose.socket
	_waist.rotation = pose.axis.angle()
	_grip.position = pose.grip
	_grip.rotation = pose.blade_angle


func blade_tip() -> Vector2:
	var length := Motion.GUARD + pose.exposed * pose.blade_projection
	return pose.grip + Vector2.from_angle(pose.blade_angle) * length


func begin_strike_trace() -> void:
	_trace.begin_swing()


func trace_blade(grip: Vector2, tip: Vector2, age: float) -> void:
	_trace.blade(grip, tip, age)


func trace_impact(point: Vector2, direction: Vector2, strength: float) -> void:
	_trace.hit(point, direction, strength)


func advance_trace(delta: float) -> void:
	_trace.advance(delta)
	queue_redraw()


func recoil(direction: Vector2, strength: float) -> void:
	pose.recoil(direction, strength)


func _draw() -> void:
	var torso_angle := (pose.neck - pose.hip).angle() + PI * 0.5
	_draw_cloak()
	_leg(pose.rear_hip, pose.rear_knee, pose.rear_ankle, pose.rear_foot_angle, FAR)
	_arm(pose.rear_shoulder, pose.rear_elbow, pose.rear_hand, FAR)
	_hand(pose.rear_hand, pose.rear_elbow, 0.0, FAR)
	_leg(pose.front_hip, pose.front_knee, pose.front_ankle, pose.front_foot_angle, Color.WHITE)
	_part(Art.Part.TUNIC, pose.hip, Vector2(28.0, 44.0), Vector2(0.52, 0.73), torso_angle, Color.WHITE)
	_part(Art.Part.TABARD, pose.hip + Vector2(-5, -4), Vector2(9.0, 18.0), Vector2(0.5, 0.06),
		torso_angle + pose.tabard_angle, Color(0.80, 0.79, 0.82))
	_draw_harness()
	_part(Art.Part.HOOD, pose.neck + Vector2(0.3, 1.5), Vector2(23.5, 28), Vector2(0.48, 0.89),
		torso_angle * 0.28 + pose.head_angle, Color.WHITE)
	_trace.draw_wake(self, Preferences.values.reduced_motion)
	_segment(Art.Part.SLEEVE, pose.front_shoulder, pose.front_elbow, 10.4, 2.5, Color.WHITE)
	_part(Art.Part.MANTLE, pose.neck + Vector2(-1.0, 1.0), Vector2(31.0, 19.0), Vector2(0.60, 0.08),
		torso_angle * 0.7 + pose.mantle_angle, Color.WHITE)
	_segment(Art.Part.BRACER, pose.front_elbow, pose.front_hand, 8.5, 1.2, Color.WHITE)
	if _weapon > 0.0:
		_blade()
	_hand(pose.front_hand, pose.front_elbow, pose.closed_hand, Color.WHITE)
	_trace.draw_impacts(self, Preferences.values.reduced_motion)


func _part(index: int, position: Vector2, size: Vector2, pivot: Vector2, angle: float, tint: Color) -> void:
	draw_set_transform(position, angle)
	draw_texture_rect_region(Art.TEXTURE, Rect2(-size * pivot, size), Art.REGIONS[index], tint)


func _segment(index: int, start: Vector2, end: Vector2, width: float, overlap: float, tint: Color) -> void:
	var length := start.distance_to(end) + overlap * 2.0
	_part(index, start, Vector2(width, length), Vector2(0.5, overlap / length),
		(end - start).angle() - PI * 0.5, tint)


func _leg(base: Vector2, knee: Vector2, ankle: Vector2, angle: float, tint: Color) -> void:
	_segment(Art.Part.THIGH, base, knee, 14.2, 2.6, tint)
	_part(Art.Part.BOOT, ankle, Vector2(20.2, 9.5), Vector2(0.27, 0.37), angle, tint)
	_segment(Art.Part.SHIN, knee, ankle, 11.5, 1.7, tint)


func _arm(shoulder: Vector2, elbow: Vector2, hand: Vector2, tint: Color) -> void:
	_segment(Art.Part.SLEEVE, shoulder, elbow, 10.4, 2.5, tint)
	_segment(Art.Part.BRACER, elbow, hand, 8.5, 1.2, tint)


func _hand(wrist: Vector2, elbow: Vector2, closed: float, tint: Color) -> void:
	var angle := (wrist - elbow).angle() - PI * 0.5
	if closed < 1.0:
		_part(Art.Part.OPEN_HAND, wrist, Vector2(7.5, 10.0), Vector2(0.45, 0.18), angle * 0.85, Color(tint, 1.0 - closed))
	if closed > 0.0:
		_part(Art.Part.FIST, wrist, Vector2(9.1, 9.2), Vector2(0.47, 0.46), angle * 0.68, Color(tint, closed))


func _draw_cloak() -> void:
	draw_set_transform(Vector2.ZERO)
	var root := pose.neck + Vector2(-1.0, 3.5)
	var previous := Vector2.ZERO
	# Warp one continuous painted panel. The attachment stays at the collar.
	for row in range(CLOAK_ROWS):
		var a := float(row) / CLOAK_ROWS
		var b := float(row + 1) / CLOAK_ROWS
		var lower := Vector2(pose.cloak_drag * b * b + pose.hem_wave * b * b * b,
			pose.cloak_lift * b * b)
		var top := root + Vector2(-24.0, 55.0 * a) + previous
		var bottom := root + Vector2(-24.0, 55.0 * b) + lower
		var across := Vector2(29.0, 0)
		_cloth_quad[0] = top
		_cloth_quad[1] = top + across
		_cloth_quad[2] = bottom + across
		_cloth_quad[3] = bottom
		draw_polygon(_cloth_quad, _cloth_colors, _cloth_uv[row], Art.TEXTURE)
		previous = lower


func _draw_harness() -> void:
	draw_set_transform(Vector2.ZERO)
	var tilt := (pose.chest - pose.hip).normalized().orthogonal()
	draw_line(pose.socket - tilt * 7.6, pose.socket + tilt * 7.1, Color("#342a23"), 3.2, true)
	draw_line(pose.keeper - Vector2(5.4, -0.5), pose.keeper + Vector2(5.4, -0.5), Color("#382d27"), 2.1, true)
	var mount := _waist.transform * _mouth.transform
	draw_set_transform_matrix(mount)
	draw_texture_rect(SHEATH, Rect2(0, -2.9, 56, 5.8), false, LEATHER)
	draw_line(Vector2(5.1, -3.1), Vector2(4.4, 3.1), Color("#49392e"), 2.2, true)
	draw_set_transform(pose.keeper, pose.axis.angle())
	draw_line(Vector2(0, -3.1), Vector2(-0.7, 3.1), Color("#49392e"), 2.2, true)
	if _weapon <= 0.0:
		_blade()


func _blade() -> void:
	draw_set_transform_matrix(_grip.transform)
	var length := Motion.GUARD + pose.exposed + 7.5
	var projected := Motion.GUARD + pose.exposed * pose.blade_projection + 7.5
	var source := Rect2(0, 0, STEEL.get_width() * length / (Motion.BLADE_LENGTH + 7.5), STEEL.get_height())
	draw_texture_rect_region(STEEL, Rect2(-7.5, -6.25, projected, 12.5), source)
