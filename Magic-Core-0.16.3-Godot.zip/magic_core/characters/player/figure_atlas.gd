extends RefCounted

enum Part { HOOD, TUNIC, CLOAK, MANTLE, SLEEVE, BRACER, OPEN_HAND, FIST, THIGH, SHIN, BOOT, TABARD }

const TEXTURE := preload("res://characters/player/andarilho_articulado.res")
const REGIONS := [
	Rect2(4, 4, 139, 152),
	Rect2(164, 4, 81, 152),
	Rect2(324, 4, 118, 152),
	Rect2(484, 4, 152, 144),
	Rect2(4, 164, 74, 152),
	Rect2(164, 164, 79, 152),
	Rect2(324, 164, 75, 152),
	Rect2(484, 164, 152, 109),
	Rect2(4, 324, 85, 152),
	Rect2(164, 324, 71, 152),
	Rect2(324, 324, 152, 85),
	Rect2(484, 324, 64, 152),
]
