extends CharacterBody2D

const DRAW_TIME := 0.86
const SHEATHE_TIME := 0.78
const COYOTE_TIME := 0.085
const Strike := preload("res://characters/player/sword_strike.gd")
const Combat := preload("res://characters/player/combat_controller.gd")
const BladeSweep := preload("res://systems/combat/blade_sweep.gd")
const Impact := preload("res://systems/combat/ancestral_impact.gd")
const Receiver := preload("res://systems/combat/impact_receiver.gd")

@export var walk_speed := 140.0
@export var run_speed := 265.0
@export var air_speed := 196.0
@export var acceleration := 1950.0
@export var jump_speed := 654.0
@export var gravity := 1710.0
@export_range(48.0, 240.0, 1.0) var walk_cycle_distance := 112.0
@export_group("Combate")
@export var sword_combo: Array[Strike] = [
	preload("res://characters/player/strikes/horizontal.tres"),
	preload("res://characters/player/strikes/ascendente.tres"),
	preload("res://characters/player/strikes/descendente.tres"),
]
@export_range(0.0, 1.5, 0.05) var resonance_intensity := 1.0
@export_range(0.0, 1.5, 0.05) var hitstop_intensity := 1.0
@export_range(0.0, 1.0, 0.05) var ancestral_flow := 1.0

var touch_axis := 0.0
var slippery_ground := false
var wind_velocity := 0.0
var _ground_slip := 0.0
var run_latched := false
var controls_locked := false
var weapon_selected := false
var weapon_progress := 0.0
var _jump_buffer := 0.0
var _ground_grace := 0.0
var _combat := Combat.new()
var _attack_input_blocked := false
var _facing := 1.0
var _swing_serial := 0
var _contact_pause := 0.0
var _hurt_recovery := 0.0
var _strike_entry_speed := 0.0
var _strongest_contact: Impact
@onready var _figure := $Visual
@onready var _blade := BladeSweep.new(_figure.trace_blade, _contact)
@onready var _contact_sound: AudioStreamPlayer2D = $Contato


func select_weapon(equip: bool) -> void:
	weapon_selected = equip
	if not equip:
		_combat.cancel_pending()


func block_attack_input(blocked: bool) -> void:
	_attack_input_blocked = blocked
	if blocked:
		_combat.cancel_pending()


func can_attack() -> bool:
	return weapon_selected and weapon_progress >= 1.0 and not controls_locked and not _attack_input_blocked and _hurt_recovery <= 0.0


func strike_progress() -> float:
	return _combat.progress()


func strike_link_open() -> bool:
	return can_attack() and _combat.link_open(sword_combo)


func current_strike() -> Strike:
	return _combat.current


func reset_attack_sweep() -> void:
	_blade.reset_position()


func request_jump() -> void:
	if not controls_locked and not _changing_weapon():
		_jump_buffer = 0.13


func request_attack() -> void:
	if can_attack():
		_combat.request(sword_combo)


func react_to_damage(push: float, severity: float) -> void:
	_combat.cancel_pending()
	_combat.finish()
	_contact_pause = 0.0
	_strongest_contact = null
	reset_attack_sweep()
	_figure.recoil(Vector2(signf(push) * _facing, -0.26), severity)
	velocity.x = push
	_hurt_recovery = lerpf(0.075, 0.17, severity)
	_jump_buffer = 0.0


func _physics_process(delta: float) -> void:
	_hurt_recovery = maxf(0.0, _hurt_recovery - delta)
	if _combat.current == null:
		var duration := DRAW_TIME if weapon_selected else SHEATHE_TIME
		weapon_progress = move_toward(weapon_progress, float(weapon_selected), delta / duration)
	var changing := _changing_weapon()
	if Input.is_action_just_pressed("player_attack"):
		request_attack()
	var direction := clampf(Input.get_axis("player_left", "player_right") + touch_axis, -1.0, 1.0)
	if controls_locked or changing:
		direction = 0.0
		_jump_buffer = 0.0
	if not can_attack():
		_combat.cancel_pending()
	if Input.is_action_just_pressed("player_jump"):
		request_jump()
	if _contact_pause > 0.0:
		# Input and HUD stay active. Only this actor's motion and strike clock wait.
		_contact_pause = maxf(0.0, _contact_pause - delta)
		_figure.advance_trace(delta)
		return
	if _combat.current == null and not is_zero_approx(direction):
		_facing = signf(direction)
	if _combat.begin_pending(sword_combo):
		_swing_serial += 1
		_strike_entry_speed = maxf(0.0, get_real_velocity().x * _facing)
		_blade.begin()
		_figure.begin_strike_trace()
	var profile := _combat.current
	var run_requested := run_latched or Input.is_action_pressed("player_run")
	var sprint := run_requested and not controls_locked and not changing and profile == null and _hurt_recovery <= 0.0
	var max_horizontal_speed := maxf(air_speed, run_speed) if sprint else air_speed
	var grounded := is_on_floor()
	_ground_slip = move_toward(_ground_slip, float(grounded and slippery_ground), delta * 8.0)
	var previous := strike_progress()
	if grounded:
		max_horizontal_speed = run_speed if sprint else walk_speed
		if profile != null:
			max_horizontal_speed = walk_speed * profile.ground_speed_scale
			if direction * _facing > 0.0:
				var remaining_drive := 1.0 - smoothstep(0.0, 0.41, previous)
				max_horizontal_speed = maxf(max_horizontal_speed, _strike_entry_speed * 0.72 * remaining_drive)
	var gaining_speed := sprint and signf(velocity.x) == signf(direction) and absf(velocity.x) >= walk_speed
	var gain := acceleration * 0.48 if gaining_speed else acceleration
	if grounded and profile == null and direction * velocity.x < 0.0:
		gain = acceleration * 1.64
	var drift := 0.0
	if profile == null and not controls_locked and not changing:
		if grounded:
			var grip := 0.27 if is_zero_approx(direction) else (0.63 if direction * velocity.x < 0.0 else 0.87)
			gain *= lerpf(1.0, grip, _ground_slip)
		drift = wind_velocity * (0.42 if grounded else 1.0)
	if _hurt_recovery > 0.0:
		velocity.x = move_toward(velocity.x, 0.0, gain * delta * 0.38)
	else:
		velocity.x = move_toward(velocity.x, direction * max_horizontal_speed + drift, gain * delta)
	_ground_grace = COYOTE_TIME if grounded else maxf(0.0, _ground_grace - delta)
	if _ground_grace > 0.0 and _jump_buffer > 0.0:
		velocity.y = -jump_speed
		_jump_buffer = 0.0
		_ground_grace = 0.0
	elif not grounded:
		velocity.y += gravity * delta
	_jump_buffer = maxf(0.0, _jump_buffer - delta)
	move_and_slide()
	var travel := get_position_delta().x
	var strike := _combat.advance(delta, ancestral_flow) if profile != null else -1.0
	var actual_velocity := get_real_velocity()
	var running := smoothstep(walk_speed, maxf(walk_speed + 1.0, run_speed), absf(actual_velocity.x))
	var approach := 0.0
	if profile != null:
		approach = clampf(_strike_entry_speed / maxf(run_speed, 1.0), 0.0, 1.0)
		approach *= 1.0 - smoothstep(0.14, 0.62, strike)
	var balance := _combat.carry() * ancestral_flow
	_figure.pose.terrain_slip = _ground_slip * smoothstep(24.0, 157.0, absf(actual_velocity.x)) if grounded and profile == null and direction * actual_velocity.x <= 0.0 else 0.0
	_figure.advance(delta, travel, actual_velocity, is_on_floor(), _facing,
		walk_cycle_distance, walk_speed, weapon_progress, strike,
		running if is_on_floor() else running * 0.67, direction, profile, approach, balance)
	if profile != null:
		_blade.advance(get_world_2d().direct_space_state, profile, previous, strike,
			_figure.to_global(_figure.pose.grip), _figure.to_global(_figure.blade_tip()), delta)
		if _strongest_contact != null:
			_play_contact_reaction(_strongest_contact)
			_strongest_contact = null
		if strike >= 1.0:
			_combat.finish()


func _changing_weapon() -> bool:
	return weapon_progress > 0.0 and weapon_progress < 1.0


func _contact(target: Receiver, point: Vector2, contact_velocity: Vector2) -> bool:
	var hit := Impact.new(_combat.current, contact_velocity, _facing, target.impact_resistance,
		resonance_intensity, is_on_floor(), get_real_velocity())
	hit.source_id = get_instance_id()
	hit.sequence = _swing_serial
	hit.point = point
	hit.pause = minf(hit.pause * hitstop_intensity, 0.059)
	if not target.receive_strike(hit):
		return false
	_contact_pause = maxf(_contact_pause, hit.pause)
	_figure.trace_impact(hit.point, hit.direction, hit.strength)
	if _strongest_contact == null or hit.strength > _strongest_contact.strength:
		_strongest_contact = hit
	return true


func _play_contact_reaction(hit: Impact) -> void:
	_figure.recoil(Vector2(hit.direction.x * _facing, hit.direction.y), hit.strength)
	if Preferences.values.effects > 0:
		_contact_sound.volume_linear = Preferences.values.effects / 100.0 * lerpf(0.37, 0.72, minf(hit.strength, 1.0))
		_contact_sound.pitch_scale = lerpf(1.17, 0.82, smoothstep(0.45, 1.45, hit.strength))
		_contact_sound.play()
