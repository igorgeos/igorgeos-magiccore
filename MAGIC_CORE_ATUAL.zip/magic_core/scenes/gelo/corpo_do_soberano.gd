extends "res://scenes/gelo/corpos_de_gelo.gd"

# The sovereign is rendered once as a low-cost articulated 3D silhouette inside
# the existing 2D SubViewport pipeline. No additional realtime world or lights.
const PARTS := ["hip", "ribcage", "neck", "head", "shoulder_a", "shoulder_b",
    "upper_a", "upper_b", "elbow_a", "elbow_b", "lower_a", "lower_b",
    "hand_a", "hand_b", "thigh_a", "thigh_b", "knee_a", "knee_b",
    "shin_a", "shin_b", "boot_a", "boot_b", "mantle", "hem"]

func build(_is_colossus: bool) -> void:
    heavy = true
    for key in PARTS:
        var joint := Node3D.new()
        joint.name = key
        bones[key] = joint
        add_child(joint)
    _sculpt_sovereign()
    var material := ShaderMaterial.new()
    material.shader = preload("res://scenes/gelo/material_de_gelo.gdshader")
    for key in _surfaces:
        var st: SurfaceTool = _surfaces[key]
        st.index()
        var piece := MeshInstance3D.new()
        piece.mesh = st.commit()
        piece.material_override = material
        piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        (bones[key] as Node3D).add_child(piece)
    _surfaces.clear()

func _sculpt_sovereign() -> void:
    var iron := Color("#424c59")
    var dark := Color("#222832")
    var plate := Color("#66747f")
    var silver := Color("#8c9aa2")
    var frost := Color("#829ca9")
    var crown := Color("#988b70")
    var cloak := Color("#303f53")
    # All armor elements attach to moving joints; no cut-out PNG is rotated.
    _part("hip", "cuirass", Vector3(28, 31, 39), Vector3(0, -6, 0), dark)
    _part("hip", "band", Vector3(27, 8, 41), Vector3(0, 6, 0), iron)
    for z in [-15.0, 15.0]:
        _part("hip", "lame", Vector3(19, 24, 9), Vector3(1, -14, z), plate)
    _part("ribcage", "cuirass", Vector3(44, 56, 57), Vector3(-1, -7, 0), iron)
    _part("ribcage", "cuirass", Vector3(32, 43, 43), Vector3(10, -5, 0), plate)
    _part("ribcage", "band", Vector3(32, 7, 53), Vector3(4, 13, 0), silver)
    for z in [-16.0, 16.0]:
        _part("ribcage", "lame", Vector3(21, 22, 9), Vector3(6, -14, z), dark)
        _part("ribcage", "bevel", Vector3(2.5, 15, 3), Vector3(24, -3, z), frost)
    _part("neck", "mail", Vector3(17, 1.2, 20), Vector3(0, 0.45, 0), dark)
    _part("head", "helm", Vector3(26, 32, 26), Vector3(0, 6, 0), iron)
    _part("head", "helm", Vector3(19, 27, 26), Vector3(8, 0, 0), dark)
    _part("head", "bevel", Vector3(4, 4, 18), Vector3(19, 0, 0), frost)
    _part("head", "band", Vector3(30, 9, 32), Vector3(1, 22, 0), crown)
    # Distinct crown peaks, asymmetrically worn and intentionally restrained.
    for z in [-12.0, 0.0, 12.0]:
        var y := 33.0 if absf(z) < 1.0 else 28.0
        _part("head", "blade", Vector3(7, 22 if z == 0 else 16, 7),
            Vector3(0, y, z), crown.darkened(0.12 if z > 0 else 0.0),
            Vector3(0, 0, 0.17 * signf(z)))
    _part("head", "bevel", Vector3(2.4, 5.5, 17), Vector3(21, 8, 0), Color("#a0c2d0"))
    for limb in ["a", "b"]:
        var front: bool = String(limb) == "a"
        var asym: float = 1.0 if front else 0.93
        _part("shoulder_" + limb, "pauldron", Vector3(33, 29, 28) * asym,
            Vector3(-2, 0, 0), plate)
        _part("shoulder_" + limb, "lame", Vector3(28, 11, 28) * asym,
            Vector3(-3, -12, 0), iron)
        _part("upper_" + limb, "mail", Vector3(17, 1.13, 16), Vector3(0, 0.48, 0), dark)
        _part("upper_" + limb, "lame", Vector3(17, 0.78, 16), Vector3(0, 0.53, 0), iron)
        _part("elbow_" + limb, "pauldron", Vector3(15, 13, 16), Vector3.ZERO, plate)
        _part("lower_" + limb, "lame", Vector3(17, 1.18, 16), Vector3(0, 0.5, 0), iron)
        _part("hand_" + limb, "bevel", Vector3(13, 16, 13), Vector3(0, 0, 0), dark)
        _part("thigh_" + limb, "mail", Vector3(22, 1.1, 21), Vector3(0, 0.46, 0), dark)
        _part("thigh_" + limb, "lame", Vector3(22, 0.75, 21), Vector3(0, 0.44, 0), iron)
        _part("knee_" + limb, "pauldron", Vector3(21, 17, 21), Vector3(2, 0, 0), plate)
        _part("shin_" + limb, "lame", Vector3(19, 1.14, 18), Vector3(0, 0.52, 0), iron)
        _part("boot_" + limb, "boot", Vector3(29, 19, 23), Vector3(7, -4, 0), dark)
        _part("boot_" + limb, "lame", Vector3(23, 8, 23), Vector3(11, -4, 0), plate)
    # Large but balanced heavy sword follows the right hand's orientation.
    _part("hand_a", "bevel", Vector3(7, 19, 7), Vector3(0, 10, 0), dark)
    _part("hand_a", "band", Vector3(10, 5, 12), Vector3(0, 20, 0), crown)
    _part("hand_a", "bevel", Vector3(36, 5, 9), Vector3(0, 23, 0), iron)
    _part("hand_a", "blade", Vector3(12, 78, 7), Vector3(0, 62, 0), silver)
    _part("hand_a", "blade", Vector3(3, 68, 8), Vector3(0, 64, 0), frost)
    # Two loose cloth pieces deform separately with acceleration and recovery.
    _part("mantle", "cloth", Vector3(9, 66, 60), Vector3(-17, -27, 0), cloak)
    for z in [-21.0, -7.0, 7.0, 21.0]:
        _part("mantle", "cloth", Vector3(7, 61, 16), Vector3(-20, -29, z),
            cloak.lightened((z + 21.0) * 0.0018), Vector3(0, 0, -0.08))
        _part("hem", "cloth", Vector3(6, 58 + 0.5 * z, 16), Vector3(-20, -28, z),
            cloak.darkened(0.09), Vector3(0, 0, -0.18))
