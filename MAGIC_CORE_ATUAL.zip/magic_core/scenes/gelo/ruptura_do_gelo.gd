extends Area2D

signal contact(damage: int, push: float)

const WARNING := 1.15
const ACTIVE := 0.58
const FADE := 0.32
var width := 136.0
var elapsed := 0.0
var heading := 1.0
var struck := false
var active := false
var finished := false

func setup(location: Vector2, lane_width: float, face: float) -> void:
    position = location
    width = lane_width
    heading = face
    collision_layer = 0
    collision_mask = 2
    monitoring = false
    monitorable = false
    var hit_area := CollisionShape2D.new()
    var box := RectangleShape2D.new()
    box.size = Vector2(width, 43.0)
    hit_area.shape = box
    hit_area.position = Vector2(0, -22)
    add_child(hit_area)
    body_entered.connect(_on_enter)

func _physics_process(dt: float) -> void:
    elapsed += dt
    if not active and elapsed >= WARNING:
        active = true
        set_deferred("monitoring", true)
    if active and not struck:
        for body in get_overlapping_bodies():
            _on_enter(body)
    if elapsed >= WARNING + ACTIVE and active:
        active = false
        set_deferred("monitoring", false)
    if elapsed >= WARNING + ACTIVE + FADE:
        finished = true
        queue_free()
    queue_redraw()

func _on_enter(body: Node2D) -> void:
    if struck or not active or not (body is CharacterBody2D):
        return
    struck = true
    contact.emit(21, heading * 155.0)

func _draw() -> void:
    if finished:
        return
    var intensity := 0.45 + 0.40 * sin(elapsed * 16.0)
    var warn_color := Color(0.57, 0.76, 0.86, intensity)
    var strike_color := Color(0.75, 0.92, 0.98, 0.90)
    var tint := strike_color if active else warn_color
    var half_width := width * 0.5
    if active:
        draw_rect(Rect2(-half_width, -5, width, 6), Color(0.32, 0.56, 0.69, 0.46))
    for i in 5:
        var start_x := -half_width + 10 + i * (width - 20) / 4.0
        var crack := PackedVector2Array([
            Vector2(start_x - 10, 1), Vector2(start_x - 2, -4),
            Vector2(start_x + 3, -11 if active else -5), Vector2(start_x + 9, -2),
            Vector2(start_x + 16, -7 if active else -2)
        ])
        draw_polyline(crack, tint, 2.7 if active else 1.8, true)
    if active:
        for i in 7:
            var x := -half_width + (float(i) + 0.5) * width / 7.0
            var height := 28.0 + 14.0 * sin(float(i) * 2.1)
            draw_colored_polygon(PackedVector2Array([
                Vector2(x - 11, 0), Vector2(x + 2, -height), Vector2(x + 12, 0)
            ]), Color(0.39, 0.62, 0.75, 0.66))
            draw_line(Vector2(x + 2, -height), Vector2(x + 12, 0), strike_color, 1.7, true)
