extends Area2D

signal contact(damage: int, push: float)

var direction := 1.0
var pace := 350.0
var lifetime := 0.84
var time := 0.0
var extra := false
var terrain: Callable
var struck := false

func setup(origin: Vector2, heading: float, awakened: bool, ground: Callable) -> void:
    position = origin
    direction = 1.0 if heading >= 0.0 else -1.0
    extra = awakened
    terrain = ground
    pace = 385.0 if extra else 335.0
    lifetime = 0.91 if extra else 0.77
    collision_layer = 0
    collision_mask = 2
    monitoring = true
    monitorable = false
    var collision := CollisionShape2D.new()
    var box := RectangleShape2D.new()
    box.size = Vector2(47.0, 31.0)
    collision.shape = box
    collision.position.y = -15.0
    add_child(collision)
    body_entered.connect(_on_hit)

func _physics_process(dt: float) -> void:
    time += dt
    position.x += pace * direction * dt
    var floor_y: float = terrain.call(position.x)
    if not is_finite(floor_y) or time >= lifetime:
        queue_free()
        return
    position.y = floor_y - 2.0
    queue_redraw()

func _on_hit(body: Node2D) -> void:
    if struck or not (body is CharacterBody2D):
        return
    struck = true
    contact.emit(17 if extra else 14, direction * 195.0)
    queue_free()

func _draw() -> void:
    var opacity := (1.0 - smoothstep(lifetime * 0.66, lifetime, time))
    var light := Color(0.67, 0.83, 0.90, opacity * 0.88)
    var dark := Color(0.29, 0.48, 0.59, opacity * 0.75)
    for i in 4:
        var root := Vector2(-22 + i * 14.0, 0)
        var peak := root + Vector2(direction * (6 + i % 2 * 3), -23 - i % 2 * 9)
        draw_colored_polygon(PackedVector2Array([root + Vector2(-7, 0), peak, root + Vector2(10, 0)]), dark)
        draw_line(root + Vector2(-7, 0), peak, light, 2.1, true)
        draw_line(peak, root + Vector2(10, 0), light, 1.8, true)
