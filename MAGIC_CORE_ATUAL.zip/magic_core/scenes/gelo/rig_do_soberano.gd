extends "res://scenes/forest/rig/creature_motion.gd"

# Soberano da Geada 2.5D: peças ilustradas independentes, juntas reais
# e animação procedural contínua. Nenhuma troca de quadro/PNG de poses.
# Mantém a API esperada pelo inimigo: setup, tick, impact e attack_point.
const BASE := "res://assets/gelo/soberano/pecas/"
const UPPER_LEG := 48.0
const LOWER_LEG := 43.0
const BLADE_LENGTH := 110.0
const BREATH_FREQUENCY := 1.48

var visual_root: Node2D
var bones: Dictionary = {}
var _images: Dictionary = {}
var _hips: Node2D
var _torso: Node2D
var _head: Node2D
var _cape: Node2D
var _cape_end_a: Node2D
var _cape_end_b: Node2D
var _cape_end_c: Node2D
var _shoulder_a: Node2D
var _elbow_a: Node2D
var _hand_a: Node2D
var _shoulder_b: Node2D
var _elbow_b: Node2D
var _hand_b: Node2D
var _weapon: Node2D
var _leg_a: Node2D
var _knee_a: Node2D
var _foot_a: Node2D
var _leg_b: Node2D
var _knee_b: Node2D
var _foot_b: Node2D
var _cloak_angle := 0.0
var _cloak_speed := 0.0
var _tail_angle := 0.0
var _tail_speed := 0.0
var _hit_reaction := 0.0
var _hit_velocity := 0.0
var _turn := 0.0
var _motion := 0.0


func setup(body) -> void:
	animal = body
	h = body.height
	pose.resize(24)
	previous.resize(24)
	for index in pose.size():
		pose[index] = Vector2.ZERO
	_build_skeleton()
	tick(0.0, 0.0)


func _joint(parent: Node2D, key: String, at: Vector2 = Vector2.ZERO) -> Node2D:
	var node := Node2D.new()
	node.name = key
	node.position = at
	parent.add_child(node)
	bones[key] = node
	return node


func _piece(parent: Node2D, asset: String, pivot: Vector2, factor: float, layer: int) -> Sprite2D:
	var sprite := Sprite2D.new()
	sprite.name = asset
	var tex: Texture2D = load(BASE + asset + ".png") as Texture2D
	assert(tex != null, "Peça do Soberano não encontrada: " + asset)
	sprite.texture = tex
	sprite.centered = false
	sprite.offset = -pivot
	sprite.scale = Vector2.ONE * factor
	sprite.z_as_relative = false
	sprite.z_index = layer
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	parent.add_child(sprite)
	_images[asset] = sprite
	return sprite


func _build_skeleton() -> void:
	visual_root = _joint(self, "RaizVisual")
	# Cada camada de tecido tem pivô próprio e atraso de movimento.
	_cape = _joint(visual_root, "CapaSuperior", Vector2(-9, -184))
	_piece(_cape, "capa_principal", Vector2(225, 34), 0.38, -16)
	_cape_end_a = _joint(_cape, "CapaCaudaA", Vector2(-41, 61))
	_piece(_cape_end_a, "capa_cauda_a", Vector2(62, 17), 0.32, -15)
	_cape_end_b = _joint(_cape, "CapaCaudaB", Vector2(-5, 76))
	_piece(_cape_end_b, "capa_cauda_b", Vector2(79, 19), 0.29, -14)
	_cape_end_c = _joint(_cape, "CapaCaudaC", Vector2(27, 67))
	_piece(_cape_end_c, "capa_cauda_c", Vector2(76, 17), 0.25, -13)

	_hips = _joint(visual_root, "Quadril", Vector2(0, -94))
	_piece(_hips, "abdomen", Vector2(92, 123), 0.34, -1)
	_piece(_hips, "quadril", Vector2(105, 88), 0.37, 0)
	var front_cloth := _joint(_hips, "TecidoFrontal", Vector2(0, 14))
	_piece(front_cloth, "saia_longe", Vector2(100, 18), 0.23, 1)
	_piece(front_cloth, "saia_perto", Vector2(37, 17), 0.24, 5)
	_piece(front_cloth, "tabardo", Vector2(49, 16), 0.26, 6)
	_piece(_hips, "cinto", Vector2(108, 43), 0.35, 7)

	_torso = _joint(_hips, "Torax", Vector2(0, -46))
	_piece(_torso, "torax", Vector2(113, 125), 0.40, 8)
	var cape_collar := _joint(_torso, "Gola", Vector2(-8, -33))
	_piece(cape_collar, "gola_pelo", Vector2(225, 114), 0.29, 15)
	_piece(cape_collar, "capa_ombro", Vector2(76, 25), 0.22, -11)

	_head = _joint(_torso, "Cabeca", Vector2(6, -57))
	_piece(_head, "cabeca", Vector2(171, 176), 0.35, 16)

	# Braço distante sempre atrás do peito, braço dominante por cima.
	_shoulder_b = _joint(_torso, "OmbroDistante", Vector2(-29, -30))
	_piece(_shoulder_b, "braco_longe", Vector2(56, 13), 0.28, 2)
	_piece(_shoulder_b, "ombreira_longe", Vector2(115, 52), 0.22, 9)
	_elbow_b = _joint(_shoulder_b, "CotoveloDistante", Vector2(0, 38))
	_piece(_elbow_b, "antebraco_longe", Vector2(59, 9), 0.31, 3)
	_hand_b = _joint(_elbow_b, "MaoDistante", Vector2(0, 35))
	_piece(_hand_b, "mao_longe", Vector2(50, 31), 0.30, 4)

	_shoulder_a = _joint(_torso, "OmbroDaEspada", Vector2(33, -31))
	_piece(_shoulder_a, "braco_perto", Vector2(56, 10), 0.29, 10)
	_piece(_shoulder_a, "ombreira_perto", Vector2(107, 50), 0.22, 12)
	_elbow_a = _joint(_shoulder_a, "CotoveloDaEspada", Vector2(0, 38))
	_piece(_elbow_a, "antebraco_perto", Vector2(64, 10), 0.32, 11)
	_hand_a = _joint(_elbow_a, "MaoDaEspada", Vector2(0, 24))
	_piece(_hand_a, "mao_perto", Vector2(44, 45), 0.31, 13)
	_weapon = _joint(_hand_a, "EspadaEmpunhada", Vector2(-1, 5))
	_piece(_weapon, "espada", Vector2(86, 94), 0.26, 12)

	_leg_b = _joint(_hips, "CoxaDistante", Vector2(-20, 5))
	_piece(_leg_b, "coxa_longe", Vector2(65, 16), 0.28, -3)
	_knee_b = _joint(_leg_b, "JoelhoDistante", Vector2(0, UPPER_LEG))
	_piece(_knee_b, "canela_longe", Vector2(46, 15), 0.22, -2)
	_foot_b = _joint(_knee_b, "PeDistante", Vector2(0, LOWER_LEG))
	_piece(_foot_b, "bota_longe", Vector2(69, 113), 0.30, 0)
	_leg_a = _joint(_hips, "CoxaProxima", Vector2(20, 5))
	_piece(_leg_a, "coxa_perto", Vector2(66, 17), 0.28, 3)
	_knee_a = _joint(_leg_a, "JoelhoProximo", Vector2(0, UPPER_LEG))
	_piece(_knee_a, "canela_perto", Vector2(50, 14), 0.22, 4)
	_foot_a = _joint(_knee_a, "PeProximo", Vector2(0, LOWER_LEG))
	_piece(_foot_a, "bota_perto", Vector2(54, 116), 0.30, 6)


func impact(direction: Vector2, force: float) -> void:
	_hit_velocity += clampf(force, 0.0, 2.3) * (1.0 if direction.x >= 0.0 else -1.0) * 0.76


func _progress() -> float:
	return clampf(float(animal.age) / maxf(float(animal.age + animal.time), 0.001), 0.0, 1.0)


func _approach(value: float, goal: float, dt: float, rate: float) -> float:
	return lerpf(value, goal, 1.0 - exp(-rate * dt))


func _leg_ik(thigh: Node2D, knee: Node2D, foot: Node2D, target: Vector2, bend: float) -> void:
	# Duas articulações conservam comprimento fixo; a bota acompanha a canela.
	var local_target: Vector2 = _hips.to_local(visual_root.to_global(target)) - thigh.position
	var reach: float = clampf(local_target.length(), 9.0, UPPER_LEG + LOWER_LEG - 0.2)
	var base_angle: float = local_target.angle()
	var q: float = clampf((reach * reach + UPPER_LEG * UPPER_LEG - LOWER_LEG * LOWER_LEG) /
		(2.0 * reach * UPPER_LEG), -1.0, 1.0)
	var upper_dir: float = base_angle - bend * acos(q)
	var knee_from: Vector2 = Vector2.RIGHT.rotated(upper_dir) * UPPER_LEG
	var end_dir: float = (local_target - knee_from).angle()
	thigh.rotation = upper_dir - PI * 0.5
	knee.rotation = end_dir - upper_dir
	foot.rotation = -thigh.rotation - knee.rotation


func _walking_step(beat: float, stride_size: float) -> Vector2:
	var cycle: float = fposmod(beat, 1.0)
	var support := 0.63
	if cycle < support:
		return Vector2(stride_size * (0.5 - cycle / support), 0.0)
	var swing: float = inverse_lerp(support, 1.0, cycle)
	return Vector2(lerpf(-stride_size * 0.5, stride_size * 0.5,
		smoothstep(0.0, 1.0, swing)), -sin(PI * swing) * 14.0)


func tick(dt: float, travel: float) -> void:
	clock = fposmod(clock + dt, 1000.0)
	var new_mode: int = int(animal.state)
	if mode != new_mode:
		mode = new_mode
		transition = 0.0
	transition += dt
	var moving: bool = mode in [Mode.PATROL, Mode.PURSUE] or (
		mode == Mode.STRIKE and int(animal.special) == 2)
	var speed: float = absf(travel) / maxf(dt, 0.001)
	_motion = move_toward(_motion, 1.0 if moving and speed > 6.0 else 0.0, dt * 5.1)
	if moving and speed > 4.0:
		phase = fposmod(phase + absf(travel) / 93.0, 1.0)
	var target_turn: float = 1.0 if float(animal.side) >= 0.0 else -1.0
	_turn = _approach(_turn, target_turn, dt, 12.0) if _turn != 0.0 else target_turn
	# O lado muda sem pausar a máquina de estados: nenhuma animação em frames alternados.
	visual_root.scale = Vector2(target_turn, 1.0)
	var t: float = _progress()
	var preparation: float = smoothstep(0.08, 0.94, t) if mode == Mode.WINDUP else 0.0
	var impact_time: float = smoothstep(0.06, 0.73, t) if mode == Mode.STRIKE else 0.0
	var follow_through: float = (1.0 - smoothstep(0.0, 0.92, t)) if mode == Mode.RECOVER else 0.0
	var death: float = smoothstep(0.02, 0.95, t) if mode == Mode.DEAD else 0.0
	var stun: float = sin(t * PI) if mode == Mode.HURT else 0.0
	var transition_phase: float = sin(minf(float(animal.age) / 1.48, 1.0) * PI) if bool(animal.transitioning) else 0.0
	var beat: float = sin(phase * TAU)
	var inhale: float = sin(clock * BREATH_FREQUENCY) * (1.0 - death)
	var skill: int = int(animal.special)
	var torso_bend: float = 0.0
	var sword_direction: float = 0.07
	var attack_shoulder: float = -0.18
	var attack_elbow: float = -0.19
	var guard_shoulder: float = 0.08
	var guard_elbow: float = -0.08
	var crouch: float = 0.0
	if mode in [Mode.WINDUP, Mode.STRIKE, Mode.RECOVER]:
		match skill:
			0: # Corte do Inverno: quadril, torax, ombro e punho num arco.
				torso_bend = -0.16 * preparation + 0.43 * impact_time + 0.16 * follow_through
				attack_shoulder = lerpf(-0.18, -1.05, preparation)
				attack_shoulder = lerpf(attack_shoulder, -0.76, impact_time)
				attack_elbow = lerpf(-0.19, -0.58, preparation)
				attack_elbow = lerpf(attack_elbow, -0.10, impact_time)
				sword_direction = lerpf(0.07, -2.21, preparation)
				sword_direction = lerpf(sword_direction, -1.14, impact_time)
				guard_shoulder += preparation * 0.23 - impact_time * 0.31
				crouch = 4.5 * preparation + 2.5 * impact_time
			1: # Onda: corpo recolhe, espada sobe e desce com o pulso.
				torso_bend = -0.22 * preparation + 0.32 * impact_time
				attack_shoulder = lerpf(-0.18, -2.15, preparation)
				attack_shoulder = lerpf(attack_shoulder, -0.23, impact_time)
				attack_elbow = lerpf(-0.19, 0.23, preparation)
				attack_elbow = lerpf(attack_elbow, -0.55, impact_time)
				sword_direction = lerpf(0.07, -2.72, preparation)
				sword_direction = lerpf(sword_direction, -0.05, impact_time)
				guard_shoulder -= preparation * 0.54
				crouch = 8.0 * preparation + 13.0 * impact_time
			2: # Investida: espada apontada, apoio baixo antes do deslocamento.
				torso_bend = -0.22 * preparation + 0.48 * impact_time
				attack_shoulder = lerpf(-0.18, -0.67, preparation)
				attack_shoulder = lerpf(attack_shoulder, -1.12, impact_time)
				attack_elbow = lerpf(-0.19, -0.50, preparation)
				attack_elbow = lerpf(attack_elbow, -0.05, impact_time)
				sword_direction = lerpf(0.07, -1.25, preparation)
				sword_direction = lerpf(sword_direction, -1.52, impact_time)
				crouch = 14.0 * preparation - 11.0 * impact_time
			3: # Ruptura: duas fases, erguer e fincar o fio no solo.
				torso_bend = -0.29 * preparation + 0.41 * impact_time
				attack_shoulder = lerpf(-0.18, -2.32, preparation)
				attack_shoulder = lerpf(attack_shoulder, -0.32, impact_time)
				attack_elbow = lerpf(-0.19, 0.16, preparation)
				attack_elbow = lerpf(attack_elbow, -0.64, impact_time)
				sword_direction = lerpf(0.07, -2.68, preparation)
				sword_direction = lerpf(sword_direction, -0.18, impact_time)
				crouch = 7.0 * preparation + 13.0 * impact_time
	_hit_velocity -= _hit_reaction * dt * 23.0
	_hit_velocity *= exp(-8.5 * dt)
	_hit_reaction = clampf(_hit_reaction + _hit_velocity * dt, -0.30, 0.30)
	torso_bend += _hit_reaction + stun * 0.11
	var bounce: float = absf(beat) * _motion * 3.2
	_hips.position = Vector2(beat * _motion * 1.8 - death * 13.0, -94.0 + bounce + crouch + death * 34.0 - transition_phase * 7.0)
	_hips.rotation = torso_bend * 0.22 - 0.10 * death
	_torso.rotation = torso_bend + beat * _motion * 0.027 + inhale * 0.009 - death * 0.84
	_torso.scale = Vector2(1.0 + inhale * 0.005, 1.0 + inhale * 0.010)
	_head.rotation = -_torso.rotation * 0.24 + inhale * 0.013 + transition_phase * 0.08
	_shoulder_a.rotation = attack_shoulder + beat * _motion * 0.13
	_elbow_a.rotation = attack_elbow
	_shoulder_b.rotation = guard_shoulder - beat * _motion * 0.15
	_elbow_b.rotation = guard_elbow + 0.12 * preparation
	# A lâmina pertence à mão; giro local compensado pela cadeia de ombro/cotovelo.
	_weapon.rotation = sword_direction - (_hips.rotation + _torso.rotation + _shoulder_a.rotation + _elbow_a.rotation)
	var walking_a := _walking_step(phase, 34.0) * _motion
	var walking_b := _walking_step(phase + 0.5, 34.0) * _motion
	_leg_ik(_leg_a, _knee_a, _foot_a, Vector2(25, -6) + walking_a + Vector2(0, 10.0 * death), 1.0)
	_leg_ik(_leg_b, _knee_b, _foot_b, Vector2(-21, -6) + walking_b + Vector2(0, 10.0 * death), -1.0)
	var velocity_sign: float = clampf(travel / maxf(dt, 0.001) / 155.0, -1.0, 1.0)
	var cloth_target: float = velocity_sign * 0.24 + impact_time * 0.29 - preparation * 0.15 + transition_phase * 0.16
	_cloak_speed += (cloth_target - _cloak_angle) * 15.0 * dt
	_cloak_speed *= exp(-6.3 * dt)
	_cloak_angle = clampf(_cloak_angle + _cloak_speed * dt, -0.38, 0.48)
	_tail_speed += (_cloak_angle * 1.27 - _tail_angle) * 13.5 * dt
	_tail_speed *= exp(-5.4 * dt)
	_tail_angle = clampf(_tail_angle + _tail_speed * dt, -0.65, 0.75)
	_cape.rotation = _cloak_angle + _torso.rotation * 0.26 - death * 0.47
	_cape_end_a.rotation = _tail_angle * 0.9 + inhale * 0.014
	_cape_end_b.rotation = _tail_angle * 1.10 - inhale * 0.012
	_cape_end_c.rotation = _tail_angle * 0.66
	if bool(animal.awakened):
		(_images["torax"] as Sprite2D).modulate = Color(0.84, 0.93, 1.0)
	else:
		(_images["torax"] as Sprite2D).modulate = Color.WHITE
	visual_root.modulate = Color.WHITE.lerp(Color("#de9f9f"), minf(float(animal.receiver.flash) * 0.36, 0.30))
	visual_root.modulate.a = 1.0 - smoothstep(0.78, 1.0, death)
	# A classe base dos inimigos consulta esses índices durante a preparação da onda.
	pose[7] = to_local(_hand_a.global_position)
	pose[8] = to_local(attack_point(8))
	pose[12] = to_local(_hand_b.global_position)
	position = animal.receiver.offset * 0.40


func attack_point(index: int) -> Vector2:
	if index == 8:
		return _weapon.to_global(Vector2(0.0, BLADE_LENGTH))
	return _weapon.global_position
