extends "res://scenes/forest/foe.gd"

signal rupture_requested(center: float, awakened: bool)
signal glacial_wave_requested(origin: Vector2, facing: float, awakened: bool)
signal winter_awakened
signal boss_defeated

const SovereignRig := preload("res://scenes/gelo/rig_do_soberano.gd")
const AWAKEN_THRESHOLD := 13
const ARENA_MIN := 2180.0
const ARENA_MAX := 2600.0

enum Skill { WINTER_CUT, GLACIAL_WAVE, FROST_DASH, ICE_RUPTURE }
var heavy := true
var special := Skill.WINTER_CUT
var awakened := false
var transitioning := false
var _attack_fired := false
var _sequence := 0
var _combo_queued := false
var _blocked_damage := false
var _warning_duration := 0.0

func _ready() -> void:
    memory_duration = 5.0
    super()

func _make_rig() -> Rig:
    return SovereignRig.new()

func _body_height() -> float:
    return 227.0

func _body_width() -> float:
    return 45.0

func _hurtbox_width() -> float:
    return 80.0

func _configure_receiver() -> void:
    receiver.max_health = 26
    receiver.impact_resistance = 1.45

func _recovery_time() -> float:
    return 0.83 if awakened else 1.07

func vulnerable() -> bool:
    return not transitioning and super()

func struck(hit: Impact) -> void:
    rig.impact(hit.direction, hit.strength)
    vitality.emit(receiver.health)
    if receiver.health <= 0:
        velocity = Vector2.ZERO
        transitioning = false
        change(State.DEAD, 1.75)
        boss_defeated.emit()
        return
    armor = 0.15
    memory = memory_duration
    last_seen = hero.position.x
    if receiver.health <= AWAKEN_THRESHOLD and not awakened:
        awakened = true
        transitioning = true
        velocity = Vector2.ZERO
        change(State.ALERT, 1.48)
        winter_awakened.emit()
        return
    if state not in [State.WINDUP, State.STRIKE] and hit.strength > 1.01:
        velocity.x = hit.direction.x * hit.strength * 44.0
        change(State.HURT, 0.24)

func _pursue(separation: Vector2) -> void:
    if not spotted and memory <= 0.0:
        if not step_toward(home, 58.0):
            change(State.PATROL)
        return
    var distance := absf(separation.x)
    if absf(separation.y) < 118.0 and distance < 570.0:
        var pattern := [Skill.WINTER_CUT, Skill.GLACIAL_WAVE, Skill.FROST_DASH, Skill.ICE_RUPTURE]
        if awakened:
            pattern = [Skill.FROST_DASH, Skill.ICE_RUPTURE, Skill.WINTER_CUT,
                Skill.GLACIAL_WAVE, Skill.ICE_RUPTURE, Skill.WINTER_CUT]
        var next_skill: int = int(pattern[_sequence % pattern.size()])
        var reach: float = [128.0, 440.0, 296.0, 456.0][next_skill]
        if distance <= reach:
            _start_skill(next_skill, separation.x)
            return
    if distance > 80.0:
        step_toward(last_seen, 83.0 if awakened else 65.0)

func _start_skill(skill: int, separation: float) -> void:
    special = skill
    attack = [Move.RAKE, Move.STOMP, Move.CHARGE, Move.STOMP][skill]
    side = 1.0 if separation >= 0.0 else -1.0
    spent = false
    _attack_fired = false
    _sweep_started = false
    _combo_queued = false
    _sequence += 1
    _warning_duration = float([0.77, 0.97, 0.90, 1.05][skill])
    if awakened:
        _warning_duration *= 0.91
    change(State.WINDUP, _warning_duration)

func _choose_action(separation: Vector2) -> void:
    if transitioning:
        if time <= 0.0:
            transitioning = false
            change(State.PURSUE)
        return
    match state:
        State.PATROL:
            if spotted or memory > 0.0:
                side = 1.0 if separation.x >= 0.0 else -1.0
                change(State.OBSERVE, 0.38)
        State.OBSERVE:
            if time <= 0.0:
                change(State.ALERT, 0.32)
        State.ALERT, State.HURT:
            if time <= 0.0:
                change(State.PURSUE)
        State.PURSUE:
            _pursue(separation)
        State.WINDUP:
            if time <= 0.0:
                change(State.STRIKE, [0.39, 0.72, 0.63, 0.64][special])
        State.STRIKE:
            if special == Skill.FROST_DASH and age < 0.52:
                step_toward(position.x + side * 168.0, 345.0 if awakened else 292.0)
        State.RECOVER:
            if time <= 0.0:
                if awakened and _combo_queued and absf(separation.x) < 165.0:
                    _start_skill(Skill.WINTER_CUT, separation.x)
                else:
                    change(State.PURSUE)

func apply_attack() -> void:
    if spent or transitioning:
        return
    match special:
        Skill.GLACIAL_WAVE:
            if not _attack_fired and age >= 0.23:
                _attack_fired = true
                var origin := Vector2(global_position.x + side * 60.0, global_position.y)
                glacial_wave_requested.emit(origin, side, awakened)
                if awakened:
                    glacial_wave_requested.emit(Vector2(global_position.x - side * 39.0, global_position.y), -side, true)
            return
        Skill.ICE_RUPTURE:
            if not _attack_fired and age >= 0.24:
                _attack_fired = true
                rupture_requested.emit(clampf(hero.global_position.x, ARENA_MIN + 75, ARENA_MAX - 75), awakened)
            return
        Skill.WINTER_CUT:
            if age < 0.07 or age > 0.32:
                return
            var from: Vector2 = (rig as SovereignRig).attack_point(7)
            var tip: Vector2 = (rig as SovereignRig).attack_point(8)
            if _touches_hero(from, tip, 17.0) or (_sweep_started and
                    _touches_hero(_last_grip.lerp(from, 0.5), _last_tip.lerp(tip, 0.5), 17.0)):
                _hit(from, side, 23, 230.0)
            _last_grip = from
            _last_tip = tip
            _sweep_started = true
        Skill.FROST_DASH:
            if age >= 0.10 and age < 0.58:
                var from: Vector2 = (rig as SovereignRig).attack_point(7)
                var tip: Vector2 = (rig as SovereignRig).attack_point(8)
                if _touches_hero(from, tip, 28.0) or _touches_hero(
                        global_position + Vector2(side * 5, -75),
                        global_position + Vector2(side * 75, -75), 28.0):
                    _hit(from, side, 20, 270.0)

func _physics_process(dt: float) -> void:
    var before: int = int(state)
    super(dt)
    if before == State.STRIKE and state == State.RECOVER:
        time = _recovery_time()
        _combo_queued = awakened and special == Skill.ICE_RUPTURE

func _draw() -> void:
    if transitioning:
        var glow := 0.35 + 0.18 * sin(age * 10.0)
        draw_arc(Vector2(0, -121), 85.0, PI, TAU, 28,
            Color(0.55, 0.76, 0.88, glow), 2.1, true)
    if state == State.WINDUP:
        var tint := Color(0.68, 0.84, 0.93, minf(age / 0.25, 1.0) * 0.87)
        var distance: float = [135.0, 440.0, 280.0, 170.0][special]
        if special == Skill.ICE_RUPTURE:
            draw_arc(Vector2(side * 90, -4), 63.0, PI, TAU, 20, tint, 2.7, true)
        else:
            draw_line(Vector2(0, -4), Vector2(side * distance, -4), tint, 2.5, true)
    if state == State.STRIKE and special == Skill.WINTER_CUT:
        var alpha := 1.0 - smoothstep(0.19, 0.39, age)
        var grip: Vector2 = to_local((rig as SovereignRig).attack_point(7))
        var tip: Vector2 = to_local((rig as SovereignRig).attack_point(8))
        draw_line(grip, tip, Color(0.56, 0.75, 0.85, 0.42 * alpha), 3.3, true)
