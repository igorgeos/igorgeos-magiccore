extends SceneTree

# Headless scene-independent boss regression: does not touch campaign saves.
const Foe := preload("res://scenes/forest/foe.gd")
const Soberano := preload("res://scenes/gelo/castelao.gd")
const Hero := preload("res://characters/player/player.tscn")
const ReceiverHit := preload("res://systems/combat/ancestral_impact.gd")
const HeavyStrike := preload("res://characters/player/strikes/descendente.tres")

func _initialize() -> void:
    _verify.call_deferred()
    create_timer(16.0).timeout.connect(func(): quit(2))

func _verify() -> void:
    var hero: CharacterBody2D = Hero.instantiate()
    hero.position = Vector2(380, 480)
    root.add_child(hero)
    hero.set_physics_process(false)
    var boss := Soberano.new()
    boss.name = "SoberanoDaGeada"
    boss.kind = 2
    boss.hero = hero
    boss.position = Vector2(255, 480)
    root.add_child(boss)
    boss.set_physics_process(false)
    var articulated: Variant = boss.rig
    assert(boss.receiver.max_health == 26)
    assert(boss.heavy and articulated.visual_root is Node2D)
    assert(articulated.bones.size() >= 20)
    assert(articulated.bones.has("MaoDaEspada"))
    assert(articulated.bones.has("CapaCaudaA"))
    assert(articulated._images.has("espada"))
    assert(articulated._images.has("torax"))
    var counts := {"waves": 0, "cracks": 0, "awakenings": 0}
    boss.glacial_wave_requested.connect(func(_a, _b, _c): counts["waves"] += 1)
    boss.rupture_requested.connect(func(_a, _b): counts["cracks"] += 1)
    boss.winter_awakened.connect(func(): counts["awakenings"] += 1)
    for skill in 4:
        boss._start_skill(skill, 125.0)
        assert(boss.state == Foe.State.WINDUP)
        assert(boss._warning_duration >= 0.7)
        boss.age = boss._warning_duration
        boss.time = 0.0
        boss._choose_action(Vector2(110, 0))
        assert(boss.state == Foe.State.STRIKE)
        boss.rig.tick(1.0 / 60.0, 0.0)
        assert(articulated.attack_point(8).distance_to(articulated.attack_point(7)) > 65.0)
        boss.age = 0.27
        boss.apply_attack()
    assert(counts["waves"] == 1)
    assert(counts["cracks"] == 1)
    boss.receiver.health = Soberano.AWAKEN_THRESHOLD
    var hit = ReceiverHit.new(HeavyStrike, Vector2(290, -28), 1.0, 1.45,
        1.3, true, Vector2.ZERO)
    boss.struck(hit)
    assert(boss.awakened and boss.transitioning and counts["awakenings"] == 1)
    boss.time = 0.0
    boss._choose_action(Vector2(110, 0))
    assert(not boss.transitioning)
    boss.receiver.health = 0
    boss.struck(hit)
    assert(boss.state == Foe.State.DEAD)
    assert(not boss.transitioning)
    print("PASS SOBERANO: sprites articulados em tempo real, espada acoplada, manto fisico, quatro ataques, avisos, inverno desperto e morte.")
    boss.queue_free()
    hero.queue_free()
    await process_frame
    quit()
