extends SceneTree

# Verifica as camadas ARTICULADAS, não uma folha de sprites de poses trocadas.
const Boss := preload("res://scenes/gelo/castelao.gd")
const Foe := preload("res://scenes/forest/foe.gd")
const Hero := preload("res://characters/player/player.tscn")

func _initialize() -> void:
	_run.call_deferred()
	create_timer(15.0).timeout.connect(func(): quit(2))

func _run() -> void:
	var hero: CharacterBody2D = Hero.instantiate()
	root.add_child(hero)
	hero.set_physics_process(false)
	var boss := Boss.new()
	boss.kind = 2
	boss.hero = hero
	root.add_child(boss)
	boss.set_physics_process(false)
	var art: Variant = boss.rig
	assert(art.bones.has("Torax") and art.bones.has("Cabeca"))
	assert(art.bones.has("CotoveloDaEspada") and art.bones.has("MaoDaEspada"))
	assert(art.bones.has("JoelhoProximo") and art.bones.has("PeProximo"))
	assert(art.bones.has("CapaCaudaA") and art.bones.has("CapaCaudaC"))
	assert(art.bones["EspadaEmpunhada"].get_parent() == art.bones["MaoDaEspada"])
	assert(art._images.size() >= 20)
	var breathing_start: float = art._torso.scale.y
	for frame in 75:
		art.tick(1.0 / 60.0, 0.0)
	assert(absf(breathing_start - art._torso.scale.y) > 0.001)
	for frame in 40:
		art.tick(1.0 / 60.0, 3.8)
	assert(absf(art._cloak_angle) > 0.001)
	assert(absf(art._tail_angle) > 0.001)
	assert(art.attack_point(8).distance_to(art.attack_point(7)) > 90.0)
	boss.side = -1.0
	art.tick(1.0 / 60.0, 0.0)
	assert(art.visual_root.scale.x < 0.0)
	for skill in 4:
		boss._start_skill(skill, 80.0)
		boss.age = boss._warning_duration * 0.8
		boss.time = boss._warning_duration * 0.2
		art.tick(1.0 / 60.0, 0.0)
		assert(art.attack_point(7).distance_to(art.attack_point(8)) > 90.0)
		boss.change(Foe.State.STRIKE, 0.6)
		boss.age = 0.3
		boss.time = 0.3
		art.tick(1.0 / 60.0, 0.0)
		assert(art.attack_point(7).distance_to(art.attack_point(8)) > 90.0)
	boss.change(Foe.State.DEAD, 1.2)
	boss.age = 1.0
	boss.time = 0.2
	art.tick(1.0 / 60.0, 0.0)
	assert(art.visual_root.modulate.a <= 1.0)
	print("PASS SOBERANO ARTE: 2D articulado, respiracao, capa com atraso, espada fixa na mao, espelhamento e quatro poses de ataque.")
	boss.queue_free()
	hero.queue_free()
	await process_frame
	quit()
